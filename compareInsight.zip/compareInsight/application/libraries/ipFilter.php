<?php 
class ipFilter{

	

}