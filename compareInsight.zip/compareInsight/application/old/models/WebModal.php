<?php 
class WebModal extends CI_Model{

	
	function getNavData(){
		$get = $this->db->select('*')
						->from('skills')
						->get();
		return $get->result_array();
	}

	function getAllSliderData(){
		$get = $this->db->select('*')
						->from('report')
						->get();
		return $get->result_array();
	}

	function cartCount($ip){
		$get = $this->db->select('*')
						->from('cartitem')
						->where('systemIP',$ip)
						->get();
		return $get->result_array();
	}

	function GetAllIdRelatedSkillData($id){
		$get = $this->db->select('*')
						->from('skills')
						->where('id',$id)
						->get();
		return $get->result_array();
	}

	function getIdRelatedReportData($id){
		$get = $this->db->select('*')
						->from('report')
						//->where('id',$id)
						->where('category',$id)
						->where('status','Approve')
						->get();
		return $get->result_array();
	}
	function getIdRelatedReportDataForReport($id){
		$get = $this->db->select('*')
						->from('report')
						->where('id',$id)
						->where('status','Approve')
						->get();
		return $get->result_array();
	}

	

	function getNavDataByTXT($txt){
		$get = $this->db->select('*')
						->from('report')
						->like('reportname',$txt)
						->where('status','Approve')
						->get();
		return $get->result_array();
	}

	function getSearchReletedDataByIdOrTXT($id,$txt){
		$get = $this->db->select('*')
						->from('report')
						->where('id',$id)
						->or_where('reportdesc',$txt)
						->where('status','Approve')
						->get();
		return $get->result_array();
	}

	function get_reportDetail_byID($r_id){
		$get = $this->db->select('*')
						->from('report')
						->where('id',$r_id)						
						->get();
		return $get->result_array();
	}

	function getCartItems($ip){
		$get = $this->db->select('*')
						->from('report')
						->where('cartitem.systemIP',$ip)
						->join('cartitem','cartitem.reportId = report.id','left')						
						->get();
		return $get->result_array();
	}

	function getAllPublisherName(){
		
        $query = $this->db->select("*")
        				  ->from('report')
        				  ->order_by('publisher_name','ASC')
        				  ->get();
 
        return $query->result_array();
	}

	function getAllPublisherReportsBYBuplisherName($name){
		$query = $this->db->select("*")
        				  ->from('report')
        				  ->where('publisher_name',$name)
        				  ->get();
 
        return $query->result_array();
	}

	function addCartByIp($id,$ip){
		$arr  = array(
						'reportId'   =>  $id,
						'systemIP'   => $ip
					 ) ;
		$save = $this->db->insert('cartitem',$arr);
	    return $this->db->insert_id();
	}

	function getCartItemCount($ip){
		$get = $this->db->select('*')
						->from('cartitem')
						->where('systemIP',$ip)
						->get();
		return $get->result_array();
	}

	function deleteCart($ip){
		$del = $this->db->where('systemIP',$ip)
						->delete('cartitem');
		return $this->db->affected_rows();
	}
    
    function getReportById($id){
        $get = $this->db->select('report.*,skills.title')
						->from('report')
						->where('report.id',$id)
						->join('skills','skills.id = report.category','left')
						->get();
		return $get->result_array();
    }
    function allReports(){
        $get = $this->db->select('*')
                        ->from('report')
                        ->get();
        return $get->result_array();
    }
    
    function successReports(){
        $get = $this->db->select('*')
                        ->from('report')
                        ->where('status','Approve')
                        ->get();
        return $get->result_array();
    }
    
    function warningReports(){
        $get = $this->db->select('*')
                        ->from('report')
                        ->where('status','Inprogress')
                        ->get();
        return $get->result_array();
    }
    
    function dangerReports(){
        $get = $this->db->select('*')
                        ->from('report')
                        ->where('status','Unapproved')
                        ->get();
        return $get->result_array();
    }
}