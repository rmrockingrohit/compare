<?php  include('includedItems/headers.php');?>
	
    <!-- BODY WORK START -->
        <?php include('includedItems/navigation.php');?>
        <?php // include('includedItems/slides.php');?>

       <div class="container-fluid">
            <div class="row">
                <div class="about-bg-section">
                    <div class="headigs">
                        <h3 class="testimonials-heading">About</h3>
                    </div>
                </div>
            </div>
        </div>

        <div class="container-fluid">
        	<div class="row from-group">
        		<div class="col-md-6">
        			<div class="row">
        				<div class="about-bg"></div>
        			</div>
        		</div>
        		<div class="col-md-6 about">
        			<p>Accessibility to multiple things from one source is the need of the world today and we intend to provide the same. </p>

        			
			        
			        <p>With a combine experience of decade in the market research industry we realize that the market research market is too big to hunt for the perfect report that fits you like a glove.</p>

		            <p>We make it possible. With over 20 renowned market study publishers and growing, we are set on a mission to consolidate the market research industry to become your one stop shop for all your market research insight</p>
		            
		            

		          <p>With a simple objective of helping you achieve your goals, we bring you thousands of reports across industry like Healthcare, Semiconductor, Information and Communication, Automotive, Energy and Power, Medical Device, Advanced Materials, Chemicals, Food and Beverage, Biotechnology, Aerospace and defence, Transportation, Agriculture, Mining, Materials, Construction, etc. to showcase the industry trends and assist you identify new opportunity, and top news across various markets. We are focusing on building a single platform for providing you our assistance to build tomorrow's future. </p>
        		</div>
        	</div>
        </div>
<?php include('includedItems/footer.php');?>