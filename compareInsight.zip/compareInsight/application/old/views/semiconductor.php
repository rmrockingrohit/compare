<?php include('includedItems/headers.php');?>
	
    <!-- BODY WORK START -->
        <?php include('includedItems/navigation.php');?>
        <?php //include('includedItems/slides.php');?>

        <div class="container-fluid">
        	<div class="row">
        		<div class="science-bg-section">
        			<div class="headigs">
        				<h3 class="testimonials-heading">Life & Science</h3>
        			</div>
        		</div>
        	</div>
        </div>


        <div class="container">
        	<div class="row form-group">
        		<div class="col-md-12 " id="pages">
	        		<h5 class="heading">
						<span class='black-heads'>Semi</span><span class="gold-head">Conductor</span>
					</h5>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12 science" style="">
					<div class="row form-group">
						<div class="col-md-6">
							<img src="<?php echo base_url();?>/vender/images/pine5.jpg" width="100%">							
						</div>
						<div class="col-md-6">
							<h3>Study examines colonoscopy, endoscopy infection risks</h3>
							<h6>Published on June 1, 2018 by Douglas Clark</h6>
          					<p>The International Energy Agency (IEA) reported that the global solar photovoltaic (PV) installed capacity is expected to increase beyond 1,600 Gigawatts (GW) by 2030.
          					</p>
						</div>
					</div>

					<div class="row form-group">
						<div class="col-md-6">
							<img src="<?php echo base_url();?>/vender/images/pine6.jpg" width="100%">							
						</div>
						<div class="col-md-6">
							<h3>International job offers shoot up in IITs</h3>
					        <h6>Published on May 30, 2018 by Douglas Clark</h6>
					        <p>IITs including Delhi, Roorkee, Bombay and Hyderabad have reported a surge in international offers in the first couple of days of the final placements that started on December 1.
					        </p>
						</div>
					</div>
				</div>
        	</div>
        </div>
    <!-- BODY CLOSE -->
<?php include('includedItems/footer.php');?>