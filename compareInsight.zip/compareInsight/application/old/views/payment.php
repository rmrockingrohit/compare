<?php include('includedItems/headers.php');?>
	
    <!-- BODY WORK START -->
        <?php include('includedItems/navigation.php');?>
        <?php //include('includedItems/slides.php');?>

        <div class="container-fluid">
        	<div class="row">
        		<div class="pay-bg-section">
        			<div class="headigs">
        				<h3 class="testimonials-heading"><?php echo ucfirst($title); ;?></h3>
        			</div>
        		</div>
        	</div>
        </div>


        <div class="container">
        	<div class="row form-group">
        		<div class="col-md-12 " id="pages">
	        		<h5 class="heading text-center">
						<span class='black-heads'>Payment </span><span class="gold-head">Corner</span>
					</h5>
				</div>
			</div>



			<div class="row">
				<div class="col-md-12" style="">
					<form action="/action_page.php">

						<div class="row form-group">						
							<div class="col-md-12">
				                <h3 class="text-center">Billing Address</h3>
				            </div>	
				        
			        
				        	<div class="col-md-12">								    								      
								<div class="row form-group">
									<div class="col-md-4">
							            <label for="fname" class="col-md-12">Full Name</label>
							            <input type="text" id="fname" name="firstname" placeholder="John M. Doe" class="form-control" required="required">
							        </div>
							        <div class="col-md-4">
							            <label for="email" class="col-md-12">Email</label>
							            <input type="text" id="email" name="email" placeholder="john@example.com" class="form-control" required="required">
							        </div>
							        <div class="col-md-4">
							            <label for="adr" class="col-md-12">Address</label>
							            <input type="text" id="adr" name="address" placeholder="542 W. 15th Street" class="form-control" required="required">						            
							        </div>
							    </div>

							    <div class="row form-group">
									<div class="col-md-4">
							            <label for="city" class="col-md-12">City</label>
							       		<input type="text" id="city" name="city" placeholder="New York" class="form-control" required="required">
					                </div>
							         
							        <div class="col-md-4">
							            <label for="state" class="col-md-12">State</label>
					               		<input type="text" id="state" name="state" placeholder="NY" class="form-control" required="required">
							        </div>
							        <div class="col-md-4">
							            <label for="zip" class="col-md-12">Zip</label>
					                	<input type="text" id="zip" name="zip" placeholder="10001" class="form-control" required="required">						            
							        </div>
							    </div>
							</div>
						</div>

						
					    <div class="row form-group">						
							<div class="col-md-12">
				                <h3 class="text-center">Payment</h3>
				            </div>				        

					        <div class="col-md-12">								    								      
								<div class="row form-group">
									<div class="col-md-4">
							            <label for="fname" class="col-md-12">Accepted Cards</label>
							            <div class="icon-container text-center">
							              <i class="fab fa-cc-visa" style="color:navy;font-size: 45px;"></i>
							              <i class="fab fa-cc-amex" style="color:blue;font-size: 45px;"></i>
							              <i class="fab fa-cc-mastercard" style="color:red;font-size: 45px;"></i>
							              <i class="fab fa-cc-discover" style="color:orange;font-size: 45px;"></i>
							            </div>
							        </div>
							        <div class="col-md-4">
							            <label for="cname" class="col-md-12">Name on Card</label>
							            <input type="text" id="cname" name="cardname" class="form-control" placeholder="John More Doe" required="required">
							        </div>
							        <div class="col-md-4">
							            <label for="ccnum" class="col-md-12">Credit card number</label>
							            <input type="text" class="form-control" id="ccnum" name="cardnumber" placeholder="1111-2222-3333-4444" required="required">					            
							        </div>
							    </div>

							    <div class="row form-group">
									<div class="col-md-4">
							            <label for="expmonth" class="col-md-12">Exp Month</label>
						            	<input type="text" id="expmonth" name="expmonth" class="form-control" placeholder="September" required="required">
							        </div>
							        <div class="col-md-4">
							            <label for="expyear" class="col-md-12">Exp Year</label>
						                <input type="text" class="form-control" id="expyear" name="expyear" placeholder="2018" required="required">
							        </div>
							        <div class="col-md-4">
							            <label for="cvv" class="col-md-12">CVV</label>
						                <input type="text" id="cvv" class="form-control" name="cvv" placeholder="352" required="required">				            
							        </div>
							    </div>
							    <input type="hidden" id="product" name="reportId" value="<?php echo $reportId;?>">
				            </div>
						</div>


						<div class="row form-group">						
							<div class="col-md-12">				               
				                <a id="checkOutBTN" class="btn btn-success" data-toggle="modal" >   
				                	Continue to checkout
				                </a>
				            </div>	
				        </div>				     
					</form>						    					
				</div>
        	</div>
        </div>
    <!-- BODY CLOSE -->
<?php include('includedItems/footer.php');?>
<div id="myModal" class="modal fade">
	<div class="modal-dialog modal-confirm">
		<div class="modal-content">
			<div class="modal-header">
				<div class="icon-box">
					<i class="material-icons">&#xE876;</i>
				</div>				
		<h4 class="modal-title">Thank You!</h4>
			</div>
			<div class="modal-body">
				<p class="text-center">Your payment has been confirmed. Check your email for reports detials.</p>
			</div>
			<div class="modal-footer">
				<button class="btn btn-success btn-block" data-dismiss="modal">OK</button>
			</div>
		</div>
	</div>
</div>     
 