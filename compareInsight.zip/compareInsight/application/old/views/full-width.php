<?php include('includedItems/headers.php');?>
	
    <!-- BODY WORK START -->
        <?php include('includedItems/navigation.php');?>
        <?php // include('includedItems/slides.php');?>

       <div class="container-fluid">
            <div class="row">
                <div class="cus-res-bg-section">
                    <div class="headigs">
                        <h3 class="testimonials-heading">Custom Research</h3>
                    </div>
                </div>
            </div>
        </div>

        <div class="container-fluid">
        	<div class="row from-group">
        		<div class="col-md-6">
        			<div class="row">
        				<div class="custom-bg"></div>
        			</div>
        		</div>
        		<div class="col-md-6 about">
        			<p><strong>Custom Research</strong> is a unique research which is tailored and optimized for our customers' specific needs. Sometimes the information people are looking for is not available in an off the shelf market research publication. If this is the case for you, then you should consider a custom research job. Just tell us what data you need (please be as specific as possible) and we will get to work. Upon submitting your request, a member of our research team will process the information supplied and contact all appropriate research analysts. Once we have located an expert who will conduct the research, the terms and conditions of the project will be discussed and agreed upon. </p>
        		</div>
        	</div>
        </div>
<?php include('includedItems/footer.php');?>