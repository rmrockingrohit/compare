<?php include('includedItems/headers.php');?>

    <!-- BODY WORK START -->

        <?php include('includedItems/navigation.php');?>

        <?php //include('includedItems/slides.php');?>


        <style>
            .img-box img,.profile-image img {
                width: auto;
                box-shadow: none !important;
                max-width: 100%;
                max-height: 142px;
            }
            .proile-tag{
                font-size: 12px !important;
                color: #f5c200 !important;
            }
        </style>
        <div class="container-fluid">

        	<div class="row">

        		<div class="research-bg-section">

        			<div class="headigs">

        				<h3 class="testimonials-heading"><?php if(isset($data[0]['title'])){echo ucfirst($data[0]['title']);}else{ echo $title;}?></h3>

        			</div>

        		</div>

        	</div>

        </div>





        <div class="container">
        	
			<div class="row">

				<div class="col-md-12 science" style="">

					<div class="row form-group">						

						<div class="col-md-8">

							<?php if(!isset($reportInfo)){
							         if (count($reports) > 0) {
                  					   foreach($reports as $row) {?>

										<div class="display-box">							

											<div class="row" id="">

												<div class="col-md-4">

													<div class="img-box text-center">

														<?php if(!empty($row['reportdoc']) || $row['reportdoc'] != ''){?>

															<!--<img src="<?php //echo base_url();?>vender/uploads/<?php //echo $row['reportdoc'];?>">-->
                                                           <img src="http://sakaimon.info/wp-content/uploads/2019/01/microsoft-word-title-page-templates-20-report-cover-page-templates-for-ms-word-word-excel-templates-template.jpg">
														<?php }else{?>

															<img src="<?php echo base_url();?>vender/images/database-connection-error.jpg">

														<?php }?>

													</div>

												</div>

												<div class="col-md-8">

													<div class="heading-box">

														<div class="form-group">

															<a href="<?php echo base_url('website/');?>report_info/<?php echo $row['id'];?>">

																<h5><?php echo $row['reportname'];?></h5>

															</a>

														</div>

														<div class="row form-group">

															<div class="col-md-4">

																<div class="row head">

																	<label class="col-md-12 text-center">Publisher Name </label>

																</div>

																<div class="row top-row ">

																	<label class="col-md-12 tiny">

																		<?php echo $row['publisher_name'];?>

																	</label>

																</div>

															</div>

															

															<div class="col-md-4">

																<div class="row head">

																	<label class="col-md-12 text-center">Publishing Date  </label>

																</div>

																<div class="row top-row">

																	<label class="col-md-12 tiny">

																		<?php echo $row['publisher_date'];?>

																	</label>

																</div>

															</div>



															<div class="col-md-4">

																<div class="row head">

																	<label class="col-md-12 text-center">Price </label>

																</div>

																<div class="row top-row">

																	<label class="col-md-12 tiny">

																		<?php echo $row['price'];?>

																	</label>

																</div>

															</div>											

															

														</div>

													</div>

												</div>

											</div>	

											<div class="row">

												<div class="form-group">

													<p> <?php echo $row['reportdesc'];?> </p>

												</div>

											</div>

											<div class="row">

												<div class="col-md-12">

													<a href="<?php echo base_url('website/');?>enquery/<?php echo $row['id']; ?>" class="btn btn-info">

														Sample Report

													</a>
                                                   
    													<a class="btn btn-warning" id="cart<?php echo $row['id'];?>" style="cursor: pointer;" data-value="$row['id'];?>">
    
    														Add to Cart
    
    													</a>
    												
													<script type="text/javascript">

														$('#cart<?php echo $row['id'];?>').on('click',function(){

															$.ajax({

														            type: "POST",

														            data: {id:'<?php echo $row["id"];?>'},

														            url: "<?php echo base_url('website/')."addcart";?>",

														            success: function(data){											               

														                if(data == 'error'){

														                	/*$(".cart-item").text('data');*/

														                	console.log('error')

														                }else{

														                	$('.cart-item').text(data);

														                }											              

														            }

														     })

														})
													</script>

													<label class="btn btn-compair">	

														<input type="checkbox" class="btn-get-id" value="<?php echo $row['id'] ?>" name="id[]" id="btn<?php echo $row['id'];?>">add to compare														

													</label>

													<script type="text/javascript">															
															 $('#btn<?php echo $row['id'];?>').on('click',function () {
														        
														        var id = [];
														        if($(this). prop("checked") == true){
														            var id = $(this).val();
														            $("#hide").removeClass('hide');												           
														        }else{
														            $("#hide a").addClass('hide');
														        }
														    });

															  $("#hide a").on('click',function(){
														        var ids = [];
														            $.each($("input[name='id[]']:checked"), function(){  
														                ids.push($(this).val()+'_');
														            });
														            var joins = (ids.join());
														        window.location.href ='<?php echo base_url('website/')."compare/";?>'+joins; 
														    });
														</script>

													

													<a href="<?php echo base_url('website/');?>buyNow/<?php echo $row['id']; ?>" class="btn btn-danger">

														Buy Now

													</a>

												</div>

											</div>						

										</div>
							<?php   }

	                  			}else{

	                  				echo "<h2> NO ANY RECORD</h2>";

	                  			}
							}else{?>
							<div class="row form-group">
                                <div class="col-md-4  text-center">
                                    <div class="profile-image">
                                         <img src="http://sakaimon.info/wp-content/uploads/2019/01/microsoft-word-title-page-templates-20-report-cover-page-templates-for-ms-word-word-excel-templates-template.jpg">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="profile-head">
                                        <h5>
                                            <b><?php echo ucwords($reportInfo[0]['reportname']);?></b>
                                        </h5>
                                        <h6>
                                            <?php   $pos=strpos($reportInfo[0]['reportdesc'], ' ', 60);
                                                    echo substr($reportInfo[0]['reportdesc'],0,$pos ) ."....";?>
                                        </h6>
                                        <p class="proile-tag"> Publish On: <span><?php echo $reportInfo[0]['publisher_date'];?></span> | Publisher Name: <span><?php echo $reportInfo[0]['publisher_name'];?></span></p>
                                
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <ul class="nav nav-tabs" id="myTab" role="tablist">
                                    <li class="nav-item active">
                                        <a class="nav-link " id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Description</a></a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Report CAGR</a>
                                    </li>
                                </ul>
                                 <div class="tab-content profile-tab" id="myTabContent">
                                    <div class="tab-pane fade in active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <p style="padding-top:15px;border: 1px solid lightgrey; border-top:none; color:#000;min-height:100px;"><?php echo $reportInfo[0]['reportdesc'];?></p>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="tab-pane fade in" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <p style="padding-top:15px;border: 1px solid lightgrey; border-top:none;color:#000;min-height:100px;"><?php echo $reportInfo[0]['report_cagr'];?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
							    
					<?php   }
							

	                  	?>



						</div><!-- COL_MD_8 CLOSED -->



						<div class="col-md-4">

							<div class="card">

								<article class="card-group-item">

									<header class="card-header">

										<h5 class="title">KEY BENEFITS </h5>

									</header>

									<div class="filter-content">

										<div class="card-body">

										<form>

											<label class="form-check">

											  

											  <span class="form-check-label">

											 <b>  24 * 7 Access to Analyst</b> :

											  </span><br>

											  <p>Get your pre and post sales queries resolved by our Subject matter experts.</p><hr>

											</label> <!-- form-check.// -->

											<label class="form-check">

											  

											  <span class="form-check-label">

											   <b> Customization </b>:

											  </span><br>

											  <p>We will assist you to customize the report to fit your research needs.</p><hr>

											</label>  <!-- form-check.// -->

											<label class="form-check">

											  

											  <span class="form-check-label">

											  <b> Security </b>:

											  </span><br>

											  <p>Your personal and confidential information is safe and secured.</p><hr>

											</label> 

											

												<label class="form-check">

											  

											  <span class="form-check-label">

											  <b> Assured Quality  </b>:

											  </span><br>

											  <p>Our prime focus is to provide qualitative and accurate data.</p><hr>

											</label> 

											

											<label class="form-check">

											  

											  <span class="form-check-label">

											  <b> Free sample report  </b>:

											  </span><br>

											  <p>Feel free to order a sample report before purchase.</p><hr>

											</label> 

											

										</form>



										</div> <!-- card-body.// -->

									</div>

								</article> <!-- card-group-item.// -->

	

								<article class="card-group-item">

									<header class="card-header">

										<h4 class="title">Require Customization?? </h4>

									</header>

									<div class="filter-content">

										<div class="card-body">

										<label class="form-check">

										 

										  <span class="form-check-label">

										    Let us know your customized needs and our Subject matter experts will work directly with you to provide you with data as per your needs.

										  </span>

										</label>

									

									

										</div> 

									</div>

								</article> 

							</div> 



						</div>

					</div>



					

				</div>

        	</div>

        </div>

    <!-- BODY CLOSE -->

<?php include('includedItems/footer.php');?>

<script>  

    







</script>