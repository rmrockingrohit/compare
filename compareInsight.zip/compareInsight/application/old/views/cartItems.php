<?php include('includedItems/headers.php');?>

    <!-- BODY WORK START -->

        <?php include('includedItems/navigation.php');?>

        <?php //include('includedItems/slides.php');?>



        <div class="container-fluid">

        	<div class="row">

        		<div class="research-bg-section">

        			<div class="headigs">

        				<h3 class="testimonials-heading"><?php echo ucfirst($title); ;?></h3>

        			</div>

        		</div>

        	</div>

        </div>





        <div class="container">
        	
			<div class="row">

				<div class="col-md-12" style="">

					
						<div class="table-responsive">

						  	<table class="table table-bordered table-striped ">

						    	<thead>

								    <tr>

								        <th>Sr No.</th>
 										
 										<th>Report Name</th>

									    <th>Publisher Name</th>

								        <th>Price</th>								        

								    </tr>

						        </thead>

						       <tbody>

						       	<?php $i=1;
						       		  $total = array();
						       	      foreach ($cartItem as $row){ ?>

						      			<tr>

						      				<td><?php echo $i;?></td>									       

									        <td><?php echo $row['reportname'];?></td>

									        <td><?php echo $row['publisher_name'];?></td>

									        <td><?php echo $row['price'];?></td>

						      			</tr>


								<?php 
									 array_push($total,$row['price']);
								      $i++;}?>
								      <tr class="info">
								      		<td></td>
								      		<td></td>
								      		<td>Net Amount = </td>
								      		<td ><?php echo array_sum($total);?></td>
								      </tr>
								</tbody>

							</table>

						</div>
						<div class="row form-group text-center">
							<button type="button" class="btn btn-info" data-toggle="modal" data-target="#cartModal">Request For Report Buy</button>		
							<a class="btn btn-danger" id='cancle'>Reset Cart</a>
						</div>
				</div>

        	</div>

        </div>

    <!-- BODY CLOSE -->
    <!-- Modal -->
<div id="cartModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Buyer Info</h4>
      </div>
      <div class="modal-body">
      	<p class="alert-p" id="alert-p"></p>
        <p><input type="email" name="email" id="emailCart" required="required" class="form-control" placeholder="Enter Your Email Id."></p>
        <p><input type="number" name="number" id="phoneCart" required="required" class="form-control" placeholder="Enter Your Contact No. With Country Code"></p>
      </div>
      <div class="modal-footer">
      	<a class="btn btn-success" id="sale" >Purchase Request</a>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<?php include('includedItems/footer.php');?>

