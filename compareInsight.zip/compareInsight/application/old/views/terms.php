<?php  include('includedItems/headers.php');?>
	
    <!-- BODY WORK START -->
        <?php include('includedItems/navigation.php');?>
        <?php // include('includedItems/slides.php');?>

       <div class="container-fluid">
            <div class="row">
                <div class="about-bg-section">
                    <div class="headigs">
                        <h3 class="testimonials-heading">Terms And Condition</h3>
                    </div>
                </div>
            </div>
        </div>

      <div class="row" >
       
        <div class="col-lg-11" style="
    margin-left: 55px;
">
         
         
          
<h4><b>1) Shipping:</b></h4>
<p >All of our industry reports are sent via email as a PDF/ Word/ Excel documents.</p>
<hr>
<h4><b>2)Delivery Time:</b></h4>
<p>When you place an order with COMPARE INSIGHTS, we endeavor to deliver as soon as possible. Published and ready reports will be generally delivered generally within 24 -48 hours of purchase and pre-booked reports are delivered on the date of report release. Delivery of Customized and consult projects will be informed to you at the time of purchase via email or voice call.</p>
<hr>
<h4><b>3) Return/Refund Policy:</b></h4>
<hr>
<p>Due to the nature of the information being sold, we unfortunately cannot accept returns of products once they have been delivered. </p>
<p>Please be sure to read all available information about a report before you place your order. </p>
<p>If you have any questions about a report's coverage or relevance, simply contact us for expert assistance from a Research Specialist.</p>
<hr>
<h4><b>4) Links to Third Party Sites:</b></h4>
<p>Various links on Our Service will take you out of Our Service. These linked sites are not necessarily under our control. We are not responsible for the contents of any linked page or any other page not under our control. We provide these links only as a convenience; the inclusion of a link does not imply endorsement of that linked site.</p>
<hr>
<h4><b>5) Disclaimer:</b></h4>
<p>COMPARE INSIGHTSis not responsible for any loss or damage suffered by you directly or indirectly, as a result of our delay in/failure to deliver the data/report due to circumstances beyond our control, including but not limited to natural disasters, labor strikes, war, riot, civil disorder, embargo and government regulations or restrictions of any and all kinds. Delivery time shall be extended in such conditions, allowing us reasonable time to fulfill your requirements.</p>
<p>COMPARE INSIGHTSand its affiliates and sponsors are neither responsible nor liable for any direct, indirect, incidental, consequential, special, exemplary, punitive, or other damages arising out of or relating in any way to your use of our research.</p>
<hr>
<h4><b>6) Copyright:</b></h4>
<p>You agree not to resell any part of the data/report you receive from us in a manner that competes with our products and services, without the express written permission of COMPARE INSIGHTS.</p>
<hr>
<h4><b>7) Terms & Conditions for use of the content on the Site:</b></h4>

<p>The Copyright in all of the Copyright works contained within these pages is either owned by COMPARE INSIGHTSor licensed to it. Any part or all of the contents of any of these pages may not be used, distributed or copied for any commercial purpose unless otherwise noted.</p>

<p>The information on this Site has been included in good faith for general informational purposes only. The information should not be relied upon for any specific purpose and no representation or warranty is given as to its accuracy or completeness.</p>

<p>We shall not be liable to you for any loss that you suffer (including, without limitation, damages for any consequential loss or loss of business opportunities or projects, or loss of profits) howsoever arising, whether in contract, tort or otherwise from your use or inability to use this Site, or any of its contents, or from any action or omission taken as a result of using this Site provided that nothing in these terms shall exclude or limit our liability for personal injury or death caused by our negligence.</p>


<p>By submitting personal information via any of the online forms on the site, you consent to being contacted (either by phone or email) by a representative of COMPARE INSIGHTS.</p>


<p>COMPARE INSIGHTSprovides their services to you subject to the following conditions. If you visit or order market research at COMPAREINSIGHTS.COM, you accept these conditions. Please read them carefully. We reserve the right to make changes to these terms and conditions at our absolute discretion at any time. Any such amendment shall be effective once the revised terms have been posted on the Site. Please contact the site administrator at info@compareinsights.com with any queries / comments / concerns.</p>
          
          
          
        </div>
      </div>
<?php include('includedItems/footer.php');?>