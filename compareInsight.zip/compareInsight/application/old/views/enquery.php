<?php include('includedItems/headers.php');?>
  
    <!-- BODY WORK START -->
        <?php include('includedItems/navigation.php');?>

        <div class="container-fluid">
          <div class="row">
            <div class="research-bg-section">
              <div class="headigs">
                <h3 class="testimonials-heading"><?php echo ucfirst($title)."<br/>(Sample Report Request)";?></h3>
              </div>
            </div>
          </div>
        </div>

<section class="contact py-5 bg-light" id="contact">
  <div class="container">
  	<div class="row">
  	    <div class="col-md-12" >
  	        <h4 style="margin-left: 25px;">Enquery</h4>
  		    <hr>
  	    </div>
	<!--	<div class="col-md-6">
		    
		</div>-->
		<div class="col-md-10" style=" margin-left: 25px; " id="enq">
		    <div class="card">
		      <div class="card-body">
		        <div style="margin-top: 25px;" id="enq-form">
              
              <div class="row form-group">
                <div class="col-md-4 sm-middle">
                  <input name="fullname" placeholder="Full Name" class="form-control" type="text" required="required" id="name">
                </div>

                <div class="col-md-4 sm-middle">
                  <input  name="companyname" placeholder="Company Name" class="form-control" type="text" required="required" id="companyname">
                </div>

                <div class="col-md-4 sm-middle">
                  <input type="email" name="email" class="form-control" placeholder="Email" required="required" id="email">
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-4 sm-middle">
                  <select name="country" class="form-control" required="required" id="country">
                    <option value="" style="color:#888;">Country</option>
                    <option value="USA">USA</option> <option value="UK">UK</option>
                    <option value="CANADA">Canada</option> 
                    <option value="INDIA">India</option>  <option value="PAKISTAN">Pakistan</option>
                    <option value="UAE">UAE</option> 
                    <optgroup label="- - - - - - - - - - - - - - - - -">
                    <option value="AUSTRALIA">Australia</option>
                    <option value="AUSTRIA">Austria</option>
                    <option value="BAHRAIN">Bahrain</option>
                    <option value="BANGLADESH">Bangladesh</option>
                    <option value="BELGIUM">Belgium</option>
                    <option value="Brazil">Brazil</option>
                    <option value="China">China</option>
                    <option value="Cuba">Cuba</option>
                    <option value="Cyprus">Cyprus</option>
                    <option value="Denmark">Denmark</option>
                    <option value="Fiji">Fiji</option>
                    <option value="Finland">Finland</option>
                    <option value="France">France</option>
                    <option value="Georgia">Georgia</option>
                    <option value="Germany">Germany</option>
                    <option value="Greece">Greece</option>
                    <option value="Hong Kong">Hong Kong</option>
                    
                  </select>
                </div>  

                <div class="col-md-4 sm-middle">
                  <input name="mobileno" placeholder="Mobile No." class="form-control" required="required" type="number" id="numbers">
                </div>                           
                <div class="col-md-4 sm-middle">
                    <textarea name="comment" cols="40" rows="5" placeholder="Your Message"class="form-control" id="msg"></textarea>
                </div>
              </div>
              <input type="hidden" name="report" value="<?php echo $report_id;?>" id="r_id">
              
              <div class="from-group text-right">
                <button name="button" class="btn btn-warning" id='enqMail'> Submit</button>
              </div>
          </div>
		    </div>
		  </div>
		</div>
	</div>
</div>
</section>
       
       
       
   <?php include('includedItems/footer.php');?>