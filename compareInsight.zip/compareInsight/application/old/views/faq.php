<?php  include('includedItems/headers.php');?>
	
    <!-- BODY WORK START -->
        <?php include('includedItems/navigation.php');?>
        <?php // include('includedItems/slides.php');?>

       <div class="container-fluid">
            <div class="row">
                <div class="about-bg-section">
                    <div class="headigs">
                        <h3 class="testimonials-heading">Frequently Asked Question</h3>
                    </div>
                </div>
            </div>
        </div>

     
   <div class="container">
  <!--<h3>What types of research reports do we offer?</h3>-->
   <div class="panel-group" id="accordion">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">What types of research reports do we offer?</a>
        </h4>
      </div>
      <div id="collapse1" class="panel-collapse collapse in">
        <div class="panel-body">We offer comprehensive syndicated market research reports on latest trends for 11 industries verticals and more than 150 sub segments. These research reports have unique features of quantitative and qualitative research on markets, industries and companies. We have more than 15,000 market research reports from over 20 leading global publishers. Our research analyst and Subject matter expert have in-depth knowledge of the publishers and the various types of reports in their respective industries. They save your time and money by personally assisting you in finding the right report.</div>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">What services are been offered?</a>
        </h4>
      </div>
      <div id="collapse2" class="panel-collapse collapse">
        <div class="panel-body">We offer syndicated and customized research reports. Apart from research reports we also offer consulting and subscription services.</div>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">How are reports priced?</a>
        </h4>
      </div>
      <div id="collapse3" class="panel-collapse collapse">
        <div class="panel-body">Each report has its own value based on its publisher and industry trends. We offer special discounts and offers through various publishers which is best in the industry.. </div>
      </div>
    </div>
    
     <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse4">What is registration for?</a>
        </h4>
      </div>
      <div id="collapse4" class="panel-collapse collapse">
        <div class="panel-body">If you register with us you will be able to avail of our free "Latest Arrivals" Notification Service. The "Latest Arrivals" service allows you to be the first to know about new products in your market. Upon registration you are provided with an account which will enable you to access all your recently viewed categories and products for easy reference, as well as place orders online.. </div>
      </div>
    </div>
    
     <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse5">How do I pace an order?</a>
        </h4>
      </div>
      <div id="collapse5" class="panel-collapse collapse">
        <div class="panel-body">First choose an order form option for your chosen report, after that select the option for payment , then select your payment option which are through credit card, purchase order or bank wire or else you can directly order from buy now option by selecting payment method i.e. 1 visa master card, 2. CC Avenue (visa, Master card, Amex). For more information please go through our order process page.. </div>
      </div>
    </div>
    
     <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse6">What types of payments are accepted?</a>
        </h4>
      </div>
      <div id="collapse6" class="panel-collapse collapse">
        <div class="panel-body"> <p>Payment by credit card:</p>
              <p>We accept VISA, MASTERCARD and AMERICAN EXPRESS.
Our website is SSL secured but if you prefer to handle credit card details over the phone you can select 'payment by credit card by Phone/Fax'.</p>

        <p>Wire Transfer:</p>

          <p>Arrangements for payment by wire transfer or invoice can be made by contacting customer service -+1 800 (US), +1800 (UK), +1800(INDIA) or write us an email at info@.</p>
          
           <p>Payment by PayPal:</p>
           <p>Arrangements for payment by, wire transfer or invoice can be made by contacting customer service.</p> </div>
      </div>
    </div>
    
     <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse7">How long does delivery take?</a>
        </h4>
      </div>
      <div id="collapse7" class="panel-collapse collapse">
        <div class="panel-body">Items purchased for online delivery are normally delivered within 1-2 business days. If there is any customized requirement on the report then the delivery time will be conveyed to you at the time of purchase..ipisicing elit,
        sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </div>
      </div>
    </div>
    
     <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse8">Does COMPARE INSIGHTS require payment before order dispatch?</a>
        </h4>
      </div>
      <div id="collapse8" class="panel-collapse collapse">
        <div class="panel-body">Due to the nature of the products we sell we're afraid that we are not able to arrange for dispatch of an order until payment has been received in full against that order.
 </div>
      </div>
    </div>
    
     <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse9">What is our refund/return policy?</a>
        </h4>
      </div>
      <div id="collapse9" class="panel-collapse collapse">
        <div class="panel-body">Due to the nature of the products we sell (being information based they are essentially consumed as they are purchased and cannot easily be returned) we do not provide refunds for orders, or accept returns. Try to read all available information about a product and if you have any questions please feel free to click on the "Email Us" at the right hand side of each product page to submit a query to us. A member of our Customer Service Dept. would be more than happy to revert back to you with more information, or refer your query as necessary.</div>
      </div>
    </div>
    
     <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse10">What is COMPARE INSIGHTS cancellation policy?</a>
        </h4>
      </div>
      <div id="collapse10" class="panel-collapse collapse">
        <div class="panel-body">In general Research, COMPARE INSIGHTS cannot accept the cancellation of an order once it has been placed. When placing an order with Research and Markets, you agree to our Terms and Conditions </div>
      </div>
    </div>
    
     <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse11">What will be the format of the deliverable or report?</a>
        </h4>
      </div>
      <div id="collapse11" class="panel-collapse collapse">
        <div class="panel-body">The reports will be delivered in PDF formats. </div>
      </div>
    </div>
    
     <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse12">Are discounts available?</a>
        </h4>
      </div>
      <div id="collapse12" class="panel-collapse collapse">
        <div class="panel-body">Yes we do offer timely discounts on regular intervals. We also support students, academicians, NGOs, startups and our regular clients with their research & consulting needs. In order to do so, we have designed a special pricing policy based on discounts and payment plans. Please contact our sales representative at phone: +1800 or email: sales@.com to gain access to our special pricing. </div>
      </div>
    </div>
    
     <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse13">What are the available ordering methods?</a>
        </h4>
      </div>
      <div id="collapse13" class="panel-collapse collapse">
        <div class="panel-body"> <p>If you are placing an order on a company’s behalf, you should be authorized to make the purchase decision. You can place your order using following channels:</p>
              
              <p>Ordering by Telephone:</p>
              <p>Call us on USA/Canada Toll Free 1-800 (For International Clients Dial 1-800) and speak with our customer service representative to place an order</p>
              <p>Ordering by Email:</p>
              <p>Send all your requirements and questions to sales@compareinsights.com. Remember to include all your details including billing & delivery address along with the preferred mode of payment. Our executives will get in touch with you within 1 business day.</p> </div>
      </div>
    </div>
    
     <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse14">What are single user, multiple user, and enterprise user license?</a>
        </h4>
      </div>
      <div id="collapse14" class="panel-collapse collapse">
        <div class="panel-body"> <p>Product licenses are designed to regulate readership and distribution rights.
The purchase of a 'Single User License' grants access to a specific report for one person only and must not be shared with other employees within the same company.
The purchase of a 'Multi User License’ grants access to a specific report for two to five users only within the same department and company.
The purchase of an 'Enterprise License’ grants access to a specific report to a company wide audience. This includes subsidiary companies or other companies within a group.
</p></div>
      </div>
    </div>
    
     <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse15">Can I buy chapters/segments from a study?</a>
        </h4>
      </div>
      <div id="collapse15" class="panel-collapse collapse">
        <div class="panel-body"> <p>We generally do not promote the sale of separate or individual segments from within a study, as it might fail to relay the actual meaning of the study or provide a holistic picture of the market. However, in special cases, selected chapters are provided based on the client requirement.
For more information, please contact our sales representative at phone: +1800 or email: sales@.com.
</p> </div>
      </div>
    </div>
    
     <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse16">What are the payment terms?</a>
        </h4>
      </div>
      <div id="collapse16" class="panel-collapse collapse">
        <div class="panel-body">Payments once made are non-refundable. This is a standard company and industry policy. The use of our products or reports are based on the concept of knowledge transfer and therefore, a refund cannot be issued post the client has read the study. In an attempt to avoid such situations, COMPARE INSIGHTS provides comprehensive and transparent pre-purchase facilities to all its clients. </div>
      </div>
    </div>
    
     <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse17">Are discounts available?</a>
        </h4>
      </div>
      <div id="collapse17" class="panel-collapse collapse">
        <div class="panel-body">Yes we do offer timely discounts on regular intervals. We also support students, academicians, NGOs, startups and our regular clients with their research & consulting needs. In order to do so, we have designed a special pricing policy based on discounts and payment plans. Please contact our sales representative at phone: +1800 or email: sales@.com to gain access to our special pricing. </div>
      </div>
    </div>
    
     <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse18">I have a problem with processing the payment?</a>
        </h4>
      </div>
      <div id="collapse18" class="panel-collapse collapse">
        <div class="panel-body">These problems are rare. You will however, receive a notification while filling the payment form, in case the gateway fails to verify your credit card information. In our experience, billing address mismatch is the most common payment related issue. However, in case you experience any other issue, please contact us and we will look into it straightaway. </div>
      </div>
    </div>
    
     <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse19">How can I contact COMPARE INSIGHTS?</a>
        </h4>
      </div>
      <div id="collapse19" class="panel-collapse collapse">
        <div class="panel-body"> <p>You may reach us at:
Email: sales@
Phone: +1-800 (U.S.)
.</p> </div>
      </div>
    </div>
    
    
    
    
    
  </div> 
</div>
   
   
<?php include('includedItems/footer.php');?>