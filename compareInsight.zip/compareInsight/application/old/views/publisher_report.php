<?php include('includedItems/headers.php');?>
			
    <!-- BODY WORK START -->
        <?php include('includedItems/navigation.php');?>
        <?php   /*
                $sql="SELECT * FROM report WHERE publisher_name='$publisher_name'";
                $result=mysqli_query($conn,$sql);
                $data = array();
                if ($result->num_rows > 0) {
	                while($row = $result->fetch_assoc()) {
	                	array_push($data, $row);
	                }
	              }  */            
		?>

        <div class="container-fluid">
        	<div class="row">
        		<div class="research-bg-section">
        			<div class="headigs">
        				<h3 class="testimonials-heading"><?php echo "All ".ucfirst($title); ;?></h3>
        			</div>
        		</div>
        	</div>
        </div>


        <div class="container">                
			    <div class="row form-group">
            <div class="col-md-12 " id="pages">
              <h5 class="heading text-center">
                <span class='black-heads'>Publisher's </span><span class="gold-head">Reports</span>
              </h5>
            </div>
          </div>

          <div class="row form-group">    
            <div class="table-responsive">
              <table class="table table-striped table-borderd">
                <thead>
                    <tr>
                      <th>Report Id </th>
                      <th>Publisher Name </th>
                      <th>Publisher Date </th>
                       <th>Report Title </th>
                      <th>Report Price</th>
                      <!-- <th>Report View</th> -->
                    </tr>
                </thead>
                <tbody>
                  <?php 
                  	$i = 1;
                  	foreach($data as $val){	   			                 	
		        ?>
                    <tr>
                      <td><?php echo $i;?></td>
                      <td><?php echo $val['publisher_name'];?> </td>
                      <td><?php echo $val['publisher_date'];?> </td>
                      <td><?php echo $val['reportname'];?> </td>
                      <td><?php echo $val['price'];?></td>                    
                      <td> <a class="nav-link" href="<?php echo base_url('website/');?>enquery/<?php echo $val['id'];?>">sample available </a></td>
                  </tr>
                  <?php $i++;} ?>
                </tbody>
              </table>
            </div>

          </div>
      </div>
    <!-- BODY CLOSE -->
<?php include('includedItems/footer.php');?>
