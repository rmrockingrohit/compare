

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Edit Report
   
      </h1>
    
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title"> Edit Report</h3>
            </div>
            
            
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" action="<?php echo base_url();?>index.php/admin/report/updateReport" method="post" enctype="multipart/form-data">
              <div class="box-body">
                  
				<input type="hidden" class="form-control" name="id" id="" value="<?php echo $report[0]['id']?>">
				<div class="form-group">
                  <label for="exampleInputEmail1">Report Title</label>
                  <input type="text" class="form-control" name="report_name" id="" value="<?php echo $report[0]['reportname']?>">
                </div>
                
                <div class="form-group">
                  <label for="exampleInputEmail1">Report Description</label>
                  <textarea type="text" class="form-control" name="report_desc" id="" ><?php echo $report[0]['reportdesc']?></textarea>
                </div>
				
				<div class="form-group">
                  <label for="exampleInputEmail1">Report Price</label>
                  <input type="number" class="form-control" name="report_price" id="" placeholder="Report Price" value="<?php echo $report[0]['price']?>">
                </div>
                
                	
                
				<div class="form-group">
                  <label for="exampleInputEmail1">Select Report Category</label>
                  <select name="category" class="form-control">
					<?php foreach( $category as $cat ) {?>
						<option <?php if($cat['title'] == $report[0]['category']) echo "selected";?>  value="<?php echo $cat['title']?>"><?php echo $cat['title']?></option>
					<?php }?>
                  </select>
                </div>
                
                
                
                <div class="form-group">
                  <label for="exampleInputEmail1">Publisher Date</label>
                  <input type="date" class="form-control" name="publisher_date" id="" placeholder="" value="<?php echo $report[0]['publisher_date']?>">
                </div>
                
                <div class="form-group">
                  <label for="exampleInputEmail1">Update Report Document</label>
                  <input type="file"  name="image" id="">
                </div>

                <div class="form-group">
                  <a style="height:100px;width:100px;" href="<?php echo base_url();?>report_uploads/<?php echo $report[0]["reportdoc"] ; ?>" >Report Document</a>
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <input type="submit" name="submit"  class="btn btn-primary" value="Submit"/>
              </div>
            </form>
          </div>
          <!-- /.box -->
          <!-- Input addon -->
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
        <!-- right column -->
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>