

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
		Add Report   
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title"> Add Report</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" action="<?php echo base_url();?>index.php/admin/report/insertreport" method="post" enctype="multipart/form-data">
              <div class="box-body">
                  
                  	<div class="form-group">
                  <label for="exampleInputEmail1">Publisher Name</label>
                  <input type="text" class="form-control" name="Publisher_name" id="" placeholder="publisher name">
                </div>
                
                
				<div class="form-group">
                  <label for="exampleInputEmail1">Report Title</label>
                  <input type="text" class="form-control" name="report_name" id="" placeholder="Report Title">
                </div>
                
                <div class="form-group">
                  <label for="exampleInputEmail1">Report Description</label>
                  <textarea type="text" class="form-control" name="report_desc" id="" placeholder="Report Description"></textarea>
                </div>
				
				<div class="form-group">
                  <label for="exampleInputEmail1">Report Price</label>
                  <input type="number" class="form-control" name="report_price" id="" placeholder="Report Price">
                </div>
                
                
                <div class="form-group">
                  <label for="exampleInputEmail1">Publisher_date</label>
                  <input type="date" class="form-control" name="Publisher_date" id="" placeholder="Publisher date">
                </div>
                
                
				<div class="form-group">
                  <label for="exampleInputEmail1">Select Report Category</label>
                  <select class="form-control" name="category">                
          					<?php foreach( $category as $cat ) {?>
          					<option value="<?php echo $cat['id']?>"><?php echo $cat['title']?></option>
          					<?php }?>
                  </select>
                </div>
                
                <div class="form-group">
                  <label for="exampleInputEmail1">Report SubCategory</label>
                  <input type="text" class="form-control" name="report_subcategory" id="" placeholder="Report Subcategory">
                </div>
                
                 <div class="form-group">
                  <label for="exampleInputEmail1">Report Id</label>
                  <input type="text" class="form-control" name="report_id" id="" placeholder="Report Id">
                </div>
                
                <div class="form-group">
                  <label for="exampleInputEmail1">CAGR</label>
                  <input type="text" class="form-control" name="report_cagr" id="" placeholder="Report Cagr number">
                </div>
                
                <div class="form-group">
                  <label for="exampleInputEmail1">TOC Report</label>
                  <input type="text" class="form-control" name="report_toc" id="" placeholder="Report toc">
                </div>
                
               <!-- <div class="form-group">
                  <label for="exampleInputEmail1">Forcast</label>
                  <input type="text" class="form-control" name="report_toc" id="" placeholder="">
                </div>-->
                
                <div class="form-group">
                  <label for="exampleInputEmail1">Choose Doc </label>
                  <input type="file"  name="image" id="">
                </div>  
                
                 
                
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <input type="submit" name="submit"  class="btn btn-primary" value="Submit"/>
              </div>
            </form>
          </div>
          <!-- /.box -->
          <!-- Input addon -->
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
        <!-- right column -->
        
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>