<section class="content-wrapper">
    <div class="">
        <!-- left column -->
        <div class="col-md-12">
    		<div class="box box-primary">
	          <!-- general form elements -->           
				<img src="<?php echo base_url('vender/images/a.png');?>" width="100%">
	        </div>
		</div>
    </div>
</section>