<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<style>
table{
    width:100%;
}
#example_filter{
    float:right;
}
#example_paginate{
    float:right;
}
label {
    display: inline-flex;
    margin-bottom: .5rem;
    margin-top: .5rem;
   
}


</style>  

<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>


<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Manage Vendor 
   
      </h1>
    
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            
            <div class="box-header">

              <h3 class="box-title">Manage Vendor</h3>
                <div class="clearfix" style="padding:10px;"></div>

                 <?php if($this->session->flashdata("success")){?>
                      <div class="alert alert-success">
                          <?php echo $this->session->flashdata("success") ?>
                      </div>
                <?php  }?>
                <?php if($this->session->flashdata("error")){?>
                      <div class="alert alert-danger">
                        <?php echo $this->session->flashdata("error") ?>
                      </div>
                <?php  }?>
                <?php if($this->session->flashdata("error")){?>
                      <div class="alert alert-danger">
                        <?php echo $this->session->flashdata("error") ?>
                      </div>
                <?php  }?> 

              
              <div class="box-tools">
                  <a href='<?php echo base_url(); ?>index.php/admin/vendor/addvendor' class="btn btn-primary pull-left" style='margin-right: 10px;margin-bottom:5px;'>Add Vendor</a>               
              </div>

            </div>
            <!-- /.box-header -->
            
            <div class="box-body">

             <table id="example" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th><input type="checkbox" onclick="checkAll(this)"></th>
                       <th>Vendor Name</th>
                          <th>Email</th>
                          <th>Type</th>
                          <th>Password</th>
                          <th>Action</th>      
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($experience as $allexperience){?>
                        <tr>
                          <td><input type="checkbox" onclick="checkAll(this)"></td>
                          <td><?php echo $allexperience["name"] ; ?></td>
                          <td><?php echo $allexperience["email"] ; ?></td>
                          <td><?php echo $allexperience["type"] ; ?></td>
                          <td><?php echo $allexperience["password"] ; ?></td>
                  
                  
                          <td><a href="<?php echo base_url();?>index.php/admin/vendor/edit/<?php echo $allexperience["id"] ; ?>" > Edit</a>|<a href="<?php echo base_url();?>index.php/admin/vendor/delete/<?php echo $allexperience["id"] ; ?>" > Delete</a>|<a href="<?php echo base_url();?>index.php/admin/vendor/vendorinfo/<?php echo $allexperience["id"] ; ?>" > see detail</a></td>               
                       </tr>                        
                    <?php  }?>
                </tbody>       
            </table>
          <!--   </div> -->
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>
      </section>
      </div>
       <script>
        $(document).ready(function() {
    $('#example').DataTable(
        
         {     

      "aLengthMenu": [[5, 10, 25, -1], [5, 10, 25, "All"]],
        "iDisplayLength": 5
       } 
        );
} );


function checkAll(bx) {
  var cbs = document.getElementsByTagName('input');
  for(var i=0; i < cbs.length; i++) {
    if(cbs[i].type == 'checkbox') {
      cbs[i].checked = bx.checked;
    }
  }
}
</script>