<!DOCTYPE html>
                        <html>
                        <head>
                        	<title>Email alert</title>
                        
                        	<style type="text/css">
                        		@import url("https://fonts.googleapis.com/css?family=Montserrat");
                        		html,body{
                        			font-family: "Montserrat", sans-serif;
                        			font-size: 10px;
                        			margin: 0px;
                        			background-color: #f5f5f5;
                        		}
                        		.header{
                        			width: 100%;
                        			margin: 0 auto;
                        			position: relative;
                            		top: 100px;
                        		}
                        		.company-name {
                            		color: #ffffff;
                            		margin-top: 10px;
                            		font-size: 14px;
                            		margin: 0px 0px;
                            	    line-height: 45px;
                            		text-align: center;
                        		}
                        		.topbar {
                        		    background-color: #2c547b;
                        		    width: 100%;
                        		    border-top-left-radius: 25px;
                        		    border-top-right-radius: 25px;
                        		}
                        		.company-name{
                        			line-height: 100px;
                        		}
                        		.company-name .largefont {
                        		    font-size: 35px;
                        		    font-weight: 600;
                        		    color: #fedd6c;
                        		}
                        		.body{
                        			min-height: 300px;
                        			background: #fff;
                        			border: 1px solid #ececec;
                        			padding: 15px;
                        		}
                        		.foot{
                        			background-color: #2c547b;
                        		    width: 100%;
                        		    border-bottom-left-radius: 25px;
                        		    border-bottom-right-radius: 25px;
                        		    min-height: 50px;
                        		}
                        		.foot p{
                        			padding: 20px 15px;
                        			color: #fff;
                        			font-size: 14px;
                            		line-height: 25px;
                            		text-align:center;
                        		}
                        		.foot a{
                        			text-align: center;
                        			color: orange;
                        			font-weight: 600;
                        			display: block;
                        		}
                        	</style>
                        </head>
                        <body>
                        	<section class="header">
                        		<div class="topbar">
                        			<h3 class="company-name">
                        				<span class="largefont">C</span>ompare <span class="largefont">I</span>nsight
                        			</h3>
                        		</div>
                        		<div class="body">
                        			<?php echo $data;?>
                        		</div>
                        		<div class="foot">
                        			<p style="margin-top: 0px;">Phone No: +91-72197 52121 <br> Email Address: (i) help@compareinsight.com <br> <span style="margin-left:105px;">(ii) sales@compareinsight.com </span><br>
                        				<a href="https:// www.coscode.com/market">Compare Insight</a></p>
                        		</div>
                        	</section>
                        </body>
                        </html>