<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Vendor Information
   
      </h1>
    
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Vendor</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <div class="box-body table-responsive no-padding">
  
              <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th><input type="checkbox" onclick="checkAll(this)"></th>
               <th>Report Id </th>
                  <th>Report Title </th>
                  <th>Report Doc</th>
                  <th>Category</th>
          <th>Price</th>
                  <th>Status</th>
                  <th>Correction</th>
                
            </tr>
        </thead>
        <tbody>
            <?php foreach($report as $allportfolio){
  ?>
                <tr>
                  <td><input type="checkbox" onclick="checkAll(this)"></td>
                <td><?php echo $allportfolio["id"] ; ?></td>
          <td><?php echo $allportfolio["reportname"] ; ?></td>
          <td><a target="_blank" style="width:300px ; height:300px ; " href="<?php echo base_url();?>report_uploads/<?php echo $allportfolio["reportdoc"] ; ?>" /><?php echo $allportfolio['reportname']?></a></td>
     <td><?php echo $allportfolio["category"] ; ?></td>
          <td><?php echo $allportfolio["price"] ; ?></td>
          <td><?php echo $allportfolio["status"] ; ?></td>
           <td><?php echo $allportfolio["report_corr"] ; ?></td>



                   </tr>
                
                <?php
}?>
        </tbody>   
       
    </table>
            </div>
          </div>
          <!-- /.box -->

       

          <!-- Input addon -->
          
          <!-- /.box -->

        </div>
        <!--/.col (left) -->
        <!-- right column -->
        
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  