<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Manage Portfolio
   
      </h1>
    
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title"> Manage Portfolio</h3>
                        <div class="clearfix" style="padding:10px;"></div>
                            
                        <?php if($this->session->flashdata("success")){?>
                            <div class="alert alert-success">
                              <?php echo $this->session->flashdata("success"); ?>
                            </div>  
                        <?php  }?>
                        <?php if($this->session->flashdata("error")){?>
                            <div class="alert alert-danger">
                                <?php echo $this->session->flashdata("error"); ?>
                            </div>
                        <?php  }?>
                        
                    </div>
                    <!-- /.box-header -->
                    
                    <!-- form start -->
                        <form role="form" action="<?php echo base_url();?>index.php/admin/Profile/updateUser" method="post" enctype="multipart/form-data">
                          <div class="box-body">
                              <input type="hidden" name="id" value="<?php //echo $userInfo[0]["id"] ?>" />
            				
            				<div class="form-group">
                              <label for="exampleInputEmail1">Vendor Name</label>
                              <input type="text" class="form-control" name="name" id="" value="<?php echo $userInfo[0]["name"] ?>">
                            </div>
                            
            				  <div class="form-group">
                              <label for="exampleInputEmail1">Vendor Email</label>
                              <input type="text" class="form-control" name="email" disabled="disabled" id="" value="<?php echo $userInfo[0]["email"] ?>">
                            </div>
            
                              <input type="hidden"  class="form-control" name="userId" id="" value="<?php echo $userInfo[0]["id"] ?>"/>
            
                            <div class="form-group">
                              <label for="exampleInputEmail1">Password</label>
                              <input type="text" class="form-control" name="password" id="" value="<?php echo $userInfo[0]["password"] ?>">
                            </div>
                           
                          </div>
                          <!-- /.box-body -->
            
                          <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Submit</button>
                          </div>
                        </form>
                      </div>
                      <!-- /.box -->
                      
                </div>
            </div>
        </div>
    </section>
</div>