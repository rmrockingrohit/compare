<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<style>table{
    width:100%;
}
#example_filter{
    float:right;
}
#example_paginate{
    float:right;
}
label {
    display: inline-flex;
    margin-bottom: .5rem;
    margin-top: .5rem;
   
}
/* .add-cat{
      position: absolute;
    right: 0px;
    top: 15px;
} */
</style>    


<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Manage Category 
   
      </h1> 
   
    </section>

    <!-- Main content -->
    <section class="content">
<div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Manage Category</h3>
                  <div class="clearfix" style="padding:10px;"></div>
                 <?php if($this->session->flashdata("success")){?>
                <div class="alert alert-success">
                  <?php echo $this->session->flashdata("success"); ?>
                  </div>
          <?php  }?>
          <?php if($this->session->flashdata("error")){?>
                <div class="alert alert-danger">
                  <?php echo $this->session->flashdata("error"); ?>
                  </div>
          <?php  }?> 
             
             <div class="box-tools add-cat">
                  <a href='<?php echo base_url(); ?>index.php/admin/category/add' class="btn btn-primary pull-left" style='margin-right: 10px;margin-bottom:5px;'>Add Category</a>
               
              </div>

            </div>
            <!-- /.box-header -->
  <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th><input type="checkbox" onclick="checkAll(this)"></th>
               <th>Manage Title</th>
                  <th>Manage Description</th>
                  <th>Action</th>      
            </tr>
        </thead>
        <tbody>
            <?php foreach ($skill as $allskill){
  ?>
                <tr>
                  <td><input type="checkbox" onclick="checkAll(this)"></td>
                <td><?php echo $allskill["title"] ; ?></td>
                <td><?php echo $allskill["short_description"] ; ?></td>
        
        
                <td><a href="<?php echo base_url();?>index.php/admin/category/edit/<?php echo $allskill["id"] ; ?>" > Edit</a>|<a href="<?php echo base_url();?>index.php/admin/category/delete/<?php echo $allskill["id"] ; ?>" > Delete</a></td>                </tr>
                
                <?php
}?>
        </tbody>   
       
    </table>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>
      </section>
      </div>
      <script >$(document).ready(function() {
    $('#example').DataTable(
        
         {     

      "aLengthMenu": [[5, 10, 25, -1], [5, 10, 25, "All"]],
        "iDisplayLength": 5
       } 
        );
} );


function checkAll(bx) {
  var cbs = document.getElementsByTagName('input');
  for(var i=0; i < cbs.length; i++) {
    if(cbs[i].type == 'checkbox') {
      cbs[i].checked = bx.checked;
    }
  }
}</script>