


<section class="">

	<div class="">

		<div class="sliders-wraper">

		    <div class="sliders">

		    	<div class="slide">

		    		<div class="container">

		    			<div class="row">

		    				<div class="col-md-8 col-md-offset-2 margintop30">

		    					<div class="row form-group" id="slide">

		    						<?php   if(!empty($skillNav)){			    								
			    						    
		    						      		foreach($skillNav as $value){ ?>

						    						<div class="right-box-md-2">

						    							<a href="<?php echo base_url('website/');?>research/<?php echo $value['id'];?>">

						    								<div class="smooth-zoom">

						    									<p><?php echo ucfirst($value['title']);?></p>

						    								</div>

						    							</a>

						    						</div>

		    						<?php   	 }
		    								}?>
								</div>



		    					<div class="row">

		    						<div class="slide-form">

		    							<div class="row form-group">

		    								<div class="col-md-12">

			    								

			    									<form class="form-index-input" id="slide-form">

			    										<div class="input-group">
			    											<span class="errMsg"></span>
			    											<input type="text" name="name" class="form-control" id="slide-txt">

			    											<input type="button" name="submit" value="Search" class="btn btn-primary" id="searchBtn">

			    										</div>
			    										<div class="input-group">
			    											<div class="search-item"></div>
			    										</div>
			    										<input type="hidden" name="id" id='valId'>
			    									</form>

			    								

			    							</div>

		    							</div>

		    						</div>
		    					</div>

		    				</div><!-- COL-MD-8 -->

		    			</div>

		    		</div><!-- CONTAINER -->

		    	</div>

		    </div>

		</div>

	</div>

</section>



