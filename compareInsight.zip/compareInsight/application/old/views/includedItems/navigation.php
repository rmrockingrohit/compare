		<?php $a = $b = $c = $d = $e = $f = $g = $def = '';
		switch ($title) {
		    case "Service":
		        $a = 'active';
		        break;
		    case "About":
		        $b = 'active';
		        break;
		    case "Industries news":
		        $c = 'active';
		        break;
		    case "Research Industries":
		        $d = 'active';
		        break;
		    case "Publisher list":
		        $e = 'active';
		        break;
		    case "Custom Research":
		        $f= 'active';
		        break;
		    case "Contact":
		        $g= 'active';
		        break;
		   
		    default:
		         $def = 'active';
		}
?>
		<!--	TOP NAVIGATION BAR -->
			<section class="top-nav">
			    <div class="container-fluid">
			    	<div class="row">
			    		<div class="topbar">
			    			<div class="container">
			    				<div class="row">
			    					<div class="col-md-4">
			    						<div class="contact-info-wraper">
			    							<ul class="contact-info">
			    								<li>
			    									<i class="fas fa-phone-volume"></i>			    									
			    									+91 XXX-XXXX-XXX
			    								</li>
			    								<li>
			    									<i class="far fa-envelope-open"></i>
			    									akshaym8677@gmail.com
			    								</li>
			    							</ul>
			    						</div>			    						
			    					</div>
			    					<div class="col-md-4">
			    						<h3 class="company-name">
			    							<span class="largefont">C</span>ompare <span class="largefont">I</span>nsight
			    						</h3>
			    					</div>
			    					<div class="col-md-4">			    						
			    						<div class="contact-info-wraper2">
			    							<ul class="contact-info">
			    								<li>
			    									<a href="<?php echo base_url('login');?>">
			    										<i class="fas fa-user"></i> Login | SignUp
			    									</a>
			    								</li>			    								
			    							</ul>

			    							<ul class="contact-info">
			    								<li class="social"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
		    									<li class="social"><a href="#"><i class="fab fa-twitter"></i></a></li>
		    									<li class="social"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>							
			    							</ul>
			    						</div>
			    					</div>
			    				</div>
			    			</div>
			    		</div>
			    	</div>
			    </div>
			</section>
		<!-- TOP NAVIGATION BAR CLOSED -->

		

		<!-- NAVIGATION BAR START -->
		<section class="navigation">
			<nav class="navbar navbar-default">
				<div class="container">
				    <div class="navbar-header">
				    	<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
					        <span class="icon-bar"></span>
					        <span class="icon-bar"></span>
					        <span class="icon-bar"></span> 
				        </button>
				      <a class="navbar-brand" href="<?php echo base_url('website');?>">
				      	<img src="<?php echo base_url();?>vender/images/default/logo1.png">
				      	<h1 class="hidden-xs-h">Compare Insight</h1>
				      </a>
				    </div>
			    	<div class="collapse navbar-collapse" id="myNavbar">
      					<ul class="nav navbar-nav">      						
                            <li class="<?php echo $a;?>">
                                <a href="<?php echo base_url('Website/');?>services">Service</a>
                            </li> 
                             <li class="<?php echo $b;?>">
                                <a href="<?php echo base_url('Website/');?>about">About</a>
                            </li> 
                            <li class="<?php echo $c;?> dropdown">
                            	<a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            		Industries news <i class="fas fa-angle-down"></i>
                            	</a>
                            	<ul class="dropdown-menu dropdown">
                            		<li><a class="dropdown-item" href="<?php echo base_url('website/');?>lifeScience">Life Science</a></li>
						            <li><a class="dropdown-item" href="<?php echo base_url('website/');?>automotive">Automotive</a></li>
						            <li><a class="dropdown-item" href="<?php echo base_url('website/');?>semiconductor">Semi Conductor</a></li>
                            	</ul>

                            </li>
                            <li class="<?php echo $d;?>">
                            	<a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            		Research Industries <i class="fas fa-angle-down"></i>
                            	</a>
                            	<ul class="dropdown-menu dropdown">
                            		<?php 
						                foreach($skillNav as $row){								    
						          	?>
                            			<li><a class="dropdown-item" href="<?php echo base_url('website/research/'.$row['id']);?>">
                            					<?php echo ucfirst($row['title']);?>                            						
                            				</a>
                            			</li>

                            		<?php }?>						            
                            	</ul>
                            </li>
                            <li class="<?php echo $e;?>">
                            	<a href="<?php echo base_url('website/');?>publisherlist">Publisher list</a>
                            </li>
                            <li class="<?php echo $f;?>">
                            	<a href="<?php echo base_url('website/');?>customResearch">Custom Research</a>
                            </li>
                            <li class="<?php echo $g;?>">
                            	<a href="<?php echo base_url('website/');?>contact">Contact</a>
                            </li>
                        </ul>        
                        <ul class="nav navbar-nav navbar-right">
      						<li class="cart-data">
      							<a href="<?php echo base_url('website/cartItems');?>">
      								<i class="fas fa-shopping-cart"></i>      								
      								<span class="cart-item"><?php echo (count($cart));?></span>
      							</a>
      						</li> 
      						<li class="hide" id="hide">
      							<a style="cursor: pointer;">Compair</a>  
      						</li>
      					</ul>            				    
			    	</div>
			  	</div>
			</nav>
		</section>
		<!-- NAVIGATION BAR CLOED -->