        <footer class="site-footer">

            <div class="upper-footer">

                <div class="container">

                    <div class="row">

                        <div class="col-md-4">

                            <div class="widget quick-links-widget">

                                <h3>Navigation</h3>

                                <ul>

                                    <li><a href="<?php echo base_url('website');?>">Home</a></li>

                                    <li><a href="<?php echo base_url('website/');?>about">About Us</a></li>

                                    <li><a href="<?php echo base_url('website/');?>contact">Contact Us</a></li>

                                    

                               
                               
                                <li><a href="<?php echo base_url('website/');?>faq">Faq</a></li>
                               
                               <li><a href="<?php echo base_url('website/');?>privacy">Privacy Policy</a></li>

                                 <li><a href="<?php echo base_url('website/');?>terms">Terms</a></li>
                                    

                                    

                                  

                                </ul>                               

                            </div>

                        </div>



                        <div class="col-md-4">

                            <div class="widget recent-post-widget">

                                <h3>Contact Address </h3>

                                <ul style="padding: 0;">

                                    <li><span class="gold-head">Address:</span> Office no 421, Pentagon building,pune-</li>

                                    <li>satara road, near panchami hotel, Pune</li>

                                    <li>Maharashtra 411009</li>

                                    <li><span class="gold-head">Phone No:</span> +91-72197 52121</li>

                                    <li><span class="gold-head">Email Address:</span> <a href="mailto:sales@compareinsight.com"> help@compareinsight.com</a><br/> <a href="mailto:sales@compareinsight.com">sales@compareinsight.com</a> </li>

                                </ul>   

                            </div>

                        </div>





                        <div class="col-md-4">

                            <div class="widget recent-post-widget">

                                <h3>Map </h3>

                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3783.810631468645!2d73.85461131489238!3d18.49223498742545!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2c01baae73f2f%3A0xdf60f401e036531a!2sSeisoTech+Pvt.Ltd.!5e0!3m2!1sen!2sin!4v1544789798226" width="100%" height="200px" frameborder="0" style="border:0" allowfullscreen></iframe>

                            </div>

                        </div>



                    </div>

                </div>         

                

            </div> <!-- end upper-footer -->



            <div class="copyright-info">

                <div class="container">

                    <p>Copyright © 2018. All Right Reserved</p>

                </div>

            </div>

        </footer>

        <script type="text/javascript">

    window.addEventListener("scroll", function() {

        if (window.scrollY > 100) {         

            $('.navbar').fadeIn('1000');

            $('.navbar').css('position','fixed');

            $('.navbar').css('top','0');

            $(".navbar").css('left','0');

            $(".navbar").css('right','0');

            $(".navbar").css('z-index','9999');

            $(".navbar").addClass('slim-nav');
            
            if($(document).width()<=600){
                $('.slim-nav .navbar-brand .hidden-xs-h').css('display','block');
            }            

        }else{

            $('.navigation .navbar').removeClass('fadeNav');

            $('.navigation .navbar').attr('style','');

            $(".navbar").attr('style','');

            $(".navbar").removeClass('slim-nav');

          if($(document).width()<=600){
                $('.hidden-xs-h').attr('style','');
            }

        }

    },false);



    $(".prime-btn").on('click',function(){

        var pills = $(".prime-tabs").val();

        $('.tab-pane').removeClass('in active')

        $('.tab-pane').addClass('hide');

        $('#'+pills).removeClass('hide');               

        $('#'+pills).addClass('in active').fadeIn(1000);;

    })

</script>
<script type="text/javascript">
    $('#slide-txt').keyup(function(){
        var txt = $(this).val(); 
        if(txt != ''){   
            $('.errMsg').fadeOut();            
            $.ajax({
                type: "POST",
                data: {data:txt},
                url: "<?php echo base_url('website/');?>getLiveSearch",
                success: function(result){
                    $('.search-item').css('display','block').html(result);
                }
            });        
        }else{
            $('.search-item').css('display','none').html();            
        }        
    })

    $(".search-item").on('click',function(){
        var text = $(event.target).closest('a').text();
        var id   = $(event.target).closest('a').data('value');        
        $('#slide-txt').val(text);
        $('#valId').val(id);
        $('.search-item').css('display','none').html();
    })

    $("#searchBtn").on('click',function(){
        var searchTxt = $("#slide-txt").val();
        var searchId  = $('#valId').val();
        if(searchTxt == ''){           
            $('.errMsg').fadeIn();
            $('.errMsg').text('please type area of function which you want');                
            

        }else{  
            $('.preloader').show();
            $.ajax({
                type: "POST",
                data: {searchTxt:searchTxt,searchId:searchId},
                url: "<?php echo base_url('website/');?>getLiveSearchMenu",
                success: function(result){
                    $('.preloader').fadeOut('400');
                    $("#sr-data").html(result);
                }
            }); 
        }
    })


    $('#authenticity').click(function () {
        $("#chat").toggle("slide");
    })
    $('#close-chat').click(function(){
         $("#chat").toggle("slide");
    })

    $("#chatSubmit").on('click',function(){
        var name   = $('#name').val();
        var email  = $('#email').val();
        var msg    = $('#message').val();

        if(name == '' || email == '' || msg ==''){
            $('#alertBox').modal('show');
        }else{
            $('.preloader').show();
            $.ajax({
                type: "POST",
                data: {name:name,email:email,msg:msg},
                url: "<?php echo base_url('website/contactMail');?>",
                success: function(result){
                    if(result == 'success'){
                        $('.preloader').fadeOut('400');
                        $("#successBox").modal('show');
                    }else{
                        $('.preloader').fadeOut('400');
                        $("#errorBox").modal('show');
                    }
                     $("#chat").toggle("slide");
                }
            }); 
        }
    })

    $('#enqMail').on('click',function(){
        var name    = $('#enq #name').val();
        var cname   = $('#enq #companyname').val();
        var email   = $('#enq #email').val();
        var country = $('#enq #country').val();
        var numbers = $('#enq #numbers').val();
        var msg     = $('#enq #msg').val();
        var r_id    = $('#enq #r_id').val();
        
        $('.preloader').show();
            $.ajax({
                type: "POST",
                data: {name:name,email:email,company:cname,msg:msg,country:country,phone:numbers,report_id:r_id},
                url: "<?php echo base_url('website/');?>mailEnquery",
                success: function(result){
                    if(result == 'success'){
                        $('.preloader').fadeOut('400');
                        $("#successBox").modal('show');
                    }else{
                        $('.preloader').fadeOut('400');
                        $("#errorBox").modal('show');
                    }
                }
            }); 

    })

    $("#contactMail").on('click',function(){
        var name    = $('.foot-form #name').val();
        var email   = $('.foot-form #email').val();
        var msg     = $('.foot-form #message').val();
       if(name == '' ){
           $('.foot-form #name').css('border','1px solid red');
           $('.foot-form #name').focus();
       }else{
           if(email == ''){
               $('.foot-form #email').css('border','1px solid red');
               $('.foot-form #email').focus();
           }else{
                $('.preloader').show();
                $.ajax({
                    type: "POST",
                    data: {name:name,email:email,msg:msg},
                    url: "<?php echo base_url('website/');?>contactMail",
                    success: function(result){
                        if(result == 'success'){
                            $('.preloader').fadeOut('400');
                            $("#successBox").modal('show');
                        }else{
                            $('.preloader').fadeOut('400');
                            $("#errorBox").modal('show');
                        }
                    }
                }); 
           }
       }
           
        
    })

    $("#checkOutBTN").on('click',function(){
        var name       = $('#fname').val();
        var email      = $("#email").val();
        var address    = $("#adr").val();
        var city       = $("#city").val();
        var state      = $("#state").val();
        var zip        = $("#zip").val();
        var nameOnCard = $("#cname").val();
        var cardNumber = $("#ccnum").val();
        var expMonth   = $("#expmonth").val();
        var expYear    = $("#expyear").val();
        var cvv        = $("#cvv").val();
        var product    = $('#product').val();

        if(name == '' || email == '' || address == '' || city == '' || state == '' || zip == '' || nameOnCard == '' || cardNumber == '' || expmonth == '' || expyear == '' || cvv == ''){
            $('#alertBox').modal('show');
        }else{
            $('.preloader').show();
                $.ajax({
                    type: "POST",
                    data: {name:name,email:email,address:address,city:city,state:state,zip:zip,nameOnCard:nameOnCard,cardNumber:cardNumber,expMonth:expMonth,expYear:expYear,cvv:cvv,product:product},
                    url: "<?php echo base_url('website/');?>buyNotify",
                    success: function(result){
                        if(result == 'success'){
                            $('.preloader').fadeOut('400');
                            $("#successBox").modal('show');
                        }else{
                            $('.preloader').fadeOut('400');
                            $("#errorBox").modal('show');
                        }
                    }
                }); 
        }

    })

    $("#cancle").on('click',function(){

    })

    $('#sale').on('click',function(){
        var email = $('#emailCart').val();
        var phone = $('#phoneCart').val();

        if(email == '' || phone ==''){
            $('.alert-p').css('display','block');
            $('#alert-p').text('Please Enter Email And Phone No');
        }else{
            $('.alert-p').css('display','none');
            $("#cartModal").modal('hide');
             $('.preloader').show();
                $.ajax({
                    type: "POST",
                    data: {email:email,phone:phone},
                    url: "<?php echo base_url('website/');?>cartSale",
                    success: function(result){
                        if(result == 'success'){
                            $('.preloader').fadeOut('400');
                            $("#successBox").modal('show');
                            
                        }else{
                            $('.preloader').fadeOut('400');
                            $("#errorBox").modal('show');
                        }
                    }
                }); 
        }
    })
   
</script>






        

    </body>

</html>

		