<?php include('includedItems/headers.php');?>
	
    <!-- BODY WORK START -->
        <?php include('includedItems/navigation.php');?>
        <?php //include('includedItems/slides.php');?>

        <div class="container-fluid">
        	<div class="row">
        		<div class="science-bg-section">
        			<div class="headigs">
        				<h3 class="testimonials-heading">Life & Science</h3>
        			</div>
        		</div>
        	</div>
        </div>


        <div class="container">
        	<div class="row form-group">
        		<div class="col-md-12 " id="pages">
	        		<h5 class="heading">
						<span class='black-heads'>Auto</span><span class="gold-head">motive</span>
					</h5>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12 science" style="">
					<div class="row form-group">
						<div class="col-md-6">
							<img src="<?php echo base_url();?>/vender/images/pine3.jpg" width="100%">							
						</div>
						<div class="col-md-6">
							<h3>G.M to begin U.S Layoff notices as it offers job transfer</h3>
							<h6>Published on June 1, 2018 by Douglas Clark</h6>
							<p>The largest U.S. automaker said 2,800 hourly active U.S. workers at four U.S. plants that will end production next year are eligible for new jobs at other plants.
							</p>
						</div>
					</div>

					<div class="row form-group">
						<div class="col-md-6">
							<img src="<?php echo base_url();?>/vender/images/pine4.jpg" width="100%">							
						</div>
						<div class="col-md-6">
							<h3>National Electronic policy 2018 to be cabinet soon</h3>
					        <h6> Published on May 30, 2018 by Douglas Clark </h6>
					        <p>Union IT and Electronics Minister Ravi Shankar Prasad on Friday said the new draft National Policy on Electronics would soon be finalised and taken up in the Cabinet.
					        </p>
						</div>
					</div>
				</div>
        	</div>
        </div>
    <!-- BODY CLOSE -->
<?php include('includedItems/footer.php');?>