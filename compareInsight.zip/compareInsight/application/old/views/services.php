<?php include('includedItems/headers.php');?>
	
    <!-- BODY WORK START -->
        <?php include('includedItems/navigation.php');?>
        <?php //include('includedItems/slides.php');?>

        <div class="container-fluid">
        	<div class="row">
        		<div class="service-bg-section">
        			<div class="headigs">
        				<h3 class="testimonials-heading">Services</h3>
        			</div>
        		</div>
        	</div>
        </div>


        <div class="container">
        	<div class="row form-group">
        		<div class="col-md-12 " id="pages">
	        		<h5 class="heading">
						<span class='black-heads'>Services</span><span class="gold-head">We Offer</span>
					</h5>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12 service" style="">
					<p>To be a one stop shop for all your market insights, we provide the below service: Off the shelf reports, Custom reports, Industry News</p>
					<h5><b><i class="fas fa-book"></i>Off the shelf reports:</b></h5>
					<p>With over 5k reports across Healthcare, Semiconductor, Information and Communication, Automotive, Energy and Power, Medical Device, Advanced Materials, Chemicals, Food and Beverage, Biotechnology, Aerospace and defence, Transportation, Agriculture, Mining, Materials, Construction, etc. from 20+ renowned vendors across the globe we provide one of the biggest pool of market research reports.</p>



					<h5><b><i class="fas fa-edit"></i>	Custom reports:</b></h5>
					<p>Looking to explore new field, we have the perfect team for you. </p>
					<p>We partner with the best market insights provider to conduct exclusive market research on the topic of your choice to assist you in exploring the next big thing.</p>


					<h5><b><i class="fas fa-industry"></i>	Industry News:</b></h5>
					<p>In a world where everything is moving at a rapid place, you need to be well informed of the updates in each of the industry. We make it possible by providing insights on the latest trends and market news to educate you to have your eureka moment.</p>



					<h5><b><i class="fas fa-award"></i> Our USP (Customer Feedback) :</b></h5>
					<!-- <p>:</p> -->
					<p>	Know reviews about the report from colleagues across the industry and help you choose the report that meets your requirements.</p>
					<p>	Consolidation of world's most renowned market research publishers. </p>
					<p>	One stop shop for market news and market insights .</p>
					<p>	Compare reports to ensure you have your glove.</p>
				</div>
        	</div>
        </div>
    <!-- BODY CLOSE -->
<?php include('includedItems/footer.php');?>