<?php include('includedItems/headers.php');?>	

    <!-- BODY WORK START -->

        <?php include('includedItems/navigation.php');?>

        <?php include('includedItems/slides.php');?>

        <?php if(isset($dataSearch)){?>
        			<?php //var_dump($dataSearch);?>
        <?php }?>
        <div id="sr-data"></div>
        <section class="primiun-reporting">

        	<div class="container">

        		<div class="row form-group" style="margin-top:50px;">
        			<h2 class="heading text-center">
						<span class='black-heads'>Premium</span><span class="gold-head"> Reports</span>
					</h2>
        		</div>

        		<!--<div id="myCarousel" class="carousel slide" data-ride="carousel">
        			<div class="row form-group">
		 				<div class="col-md-12 text-center">
							<a class="left carousel-control" href="#myCarousel" data-slide="prev">
							    <i class="fas fa-angle-left"></i>
							</a>
							<a class="right carousel-control" href="#myCarousel" data-slide="next">
							    <i class="fas fa-angle-right"></i>
							</a>
						</div>
					</div>				  

					  <!-- Wrapper for slides
					 <div class="carousel-inner">
					 	<?php   /*$active = '';
					 		    $divideCount = count($slideData) / (4);	*/	
					 		    	 		    	
					 	?>
					 			<!-- Left and right controls 

					 		    	<div class="item active">
								      	<div class="main-div">
									   		<div class="prime-div">
									   			<div>
									   				<center>
									   					<img src="<?php //echo base_url();?>/vender/uploads/<?php //echo $slideData[0]['reportdoc'];?>" class="img-responsive">
									   				</center>
									   			</div>

									   			<a href="<?php //echo base_url('website/');?>enquery/<?php //echo $slideData[0]['id'];?>" class="prime-link">
									   				<p><?php //echo $slideData[0]['reportname'];?></p>
									   			</a>
									   			<h6><i class="fas fa-rupee-sign"></i> <?php //echo $slideData[0]['price'];?></h6>
									   		</div>
									   </div>

									    <div class="main-div">
									   		<div class="prime-div">
									   			<div>
									   				<center>
									   					<img src="<?php echo base_url();?>/vender/uploads/<?php echo $slideData[1]['reportdoc'];?>" class="img-responsive">
									   				</center>
									   			</div>

									   			<a href="<?php //echo base_url('website/');?>enquery/<?php //echo $slideData[1]['id'];?>" class="prime-link">
									   				<p><?php //echo $slideData[1]['reportname'];?></p>
									   			</a>
									   			<h6><i class="fas fa-rupee-sign"></i> <?php //echo $slideData[1]['price'];?></h6>
									   		</div>
									   </div>
									

										<div class="main-div">
									   		<div class="prime-div">
									   			<div>
									   				<center>
									   					<img src="<?php //echo base_url();?>/vender/uploads/<?php //echo $slideData[2]['reportdoc'];?>" class="img-responsive">
									   				</center>
									   			</div>

									   			<a href="<?php //echo base_url('website/');?>enquery/<?php //echo $slideData[2]['id'];?>" class="prime-link">
									   				<p><?php //echo $slideData[2]['reportname'];?></p>
									   			</a>
									   			<h6><i class="fas fa-rupee-sign"></i> <?php //echo $slideData[2]['price'];?></h6>
									   		</div>
									   </div>
									

									    <div class="main-div">
									   		<div class="prime-div">
									   			<div>
									   				<center>
									   					<img src="<?php //echo base_url();?>/vender/uploads/<?php //echo $slideData[3]['reportdoc'];?>" class="img-responsive">
									   				</center>
									   			</div>

									   			<a href="<?php //echo base_url('website/');?>enquery/<?php //echo $slideData[3]['id'];?>" class="prime-link">
									   				<p><?php //echo $slideData[3]['reportname'];?></p>
									   			</a>
									   			<h6><i class="fas fa-rupee-sign"></i> <?php //echo $slideData[3]['price'];?></h6>
									   		</div>
									   </div>

									</div>
						<?php
									/*$sr = 4;
									$srCount = 1;
					 		    	for($a=2;$a<$divideCount;$a++){*/					 		    	    
					    ?>
						 				<div class="item">
						 					<?php /*for($n=1;$n<=$sr;$n++){
						 						$counters = $srCount-$sr;
						 						$index = ($a*2)-$srCount;
						 						if($slideData[$index]['id']){*/
						 					?>

						 							<div class="main-div">
												   		<div class="prime-div">
												   			<div>
												   				<center>
												   					<img src="<?php //echo base_url();?>/vender/uploads/<?php //echo $slideData[$index]['reportdoc'];?>" class="img-responsive">
												   				</center>
												   			</div>

												   			<a href="<?php //echo base_url('website');?>/enquery/<?php //echo $slideData[$index]['id'];?>" class="prime-link">
												   				<p><?php //echo $slideData[$index]['reportname'];?> </p>
												   			</a>
												   			<h6><i class="fas fa-rupee-sign"></i> <?php //echo $slideData[$index]['price'];?></h6>
												   		</div>
												   </div>

						 					<?php //}
						 				//	$srCount--; }?>								      	

										</div>									
								<?php   //} ?>						    
						
						</div>					 
					</div>-->
					
					<div class="slide-data">
					    <?php foreach($slideData as $rows){?>
					        
					        <div class="main-div">
						   		<div class="prime-div">
						   			<div>
						   				<center>
						   					<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQV_7Fjhf-niFsGtnQzHgpAngCJf7EbJ1aemQ3LQfmRuTGQxq70QA<?php //echo base_url('vender/uploads/'.$rows['reportdoc']);?>" class="img-responsive">
						   				</center>
						   			</div>

						   			<a href="<?php echo base_url('website/enquery/'.$rows['id']);?>" class="prime-link">
						   				<p><?php echo $rows['reportname'];?> </p>
						   			</a>
						   			<h6><i class="fas fa-rupee-sign"></i> <?php echo $rows['price'];?></h6>
						   		</div>
						   </div>
						   
						   
					    <?php }?>
					    
					    <a class="left carousel-control first-slide-left"  data-slide="prev" style="cursor:pointer">
							    <i class="fas fa-angle-left"></i>
							</a>
							<a class="right carousel-control first-slide-right" style="cursor:pointer">
							    <i class="fas fa-angle-right"></i>
							</a>
					</div>

        	</div>

        </section>

       



         <section class="testimonials">

        	<div class="container">

        		<div class="row">

        			<div class="col-md-12">

        				<h3 class="testimonials-heading">Our Client Says</h3>

        			</div>

        		</div>



        		<div class="row form-group">

        			<div class="col-md-12">

        				<div class="controls">

	        				<!-- Left and right controls -->

							<a class="left carousel-control" href="#testimonial" data-slide="prev">

							   <i class="fas fa-angle-left"></i>						   

							</a>

						    <a class="right carousel-control" href="#testimonial" data-slide="next">

							    <i class="fas fa-angle-right"></i>

							 </a>

						</div>

        			</div>

        		</div>

        		<div class="row">

        			<div id="testimonial" class="carousel slide" data-ride="carousel">						



					    <!-- Wrapper for slides -->

						<div class="carousel-inner">

						    <div class="item active">

						       <div class="row">

							       	<div class="col-md-4">

							       		<div class="packeg-div">

							       			<h3>Our customer's feedback </h3>

							       			<p>We appreciate your quick response to our queries and flexibility to personalise the report as per our needs. </p>

							       			<div class="client-info">

			                                    <h4>Marketing Director</h4>

			                                    <span>A leading Chemical Company </span>

			                                </div>

							       		</div>

							       	</div>

							       	<div class="col-md-4">

							       		<div class="packeg-div">

							       			<h3>Our customer's feedback </h3>

							       			<p>We appreciate your quick response to our queries and flexibility to personalise the report as per our needs. </p>

							       			<div class="client-info">

			                                    <h4>Marketing Director</h4>

			                                    <span>A leading Chemical Company </span>

			                                </div>

							       		</div>

							       	</div>



							       	<div class="col-md-4">

							       		<div class="packeg-div">

							       			<h3>Our customer's feedback </h3>

							       			<p>We appreciate your quick response to our queries and flexibility to personalise the report as per our needs. </p>

							       			<div class="client-info">

			                                    <h4>Marketing Director</h4>

			                                    <span>A leading Chemical Company </span>

			                                </div>

							       		</div>

							       	</div>

							    </div>							       	

						    </div>



						     <div class="item">

						    	 <div class="row">

							       	<div class="col-md-4">

							       		<div class="packeg-div">

							       			<h3>Our customer's feedback </h3>

							       			<p>We appreciate your quick response to our queries and flexibility to personalise the report as per our needs. </p>

							       			<div class="client-info">

			                                    <h4>Marketing Director</h4>

			                                    <span>A leading Chemical Company </span>

			                                </div>

							       		</div>

							       	</div>



							       	<div class="col-md-4">

							       		<div class="packeg-div">

							       			<h3>Our customer's feedback </h3>

							       			<p>We appreciate your quick response to our queries and flexibility to personalise the report as per our needs. </p>

							       			<div class="client-info">

			                                    <h4>Marketing Director</h4>

			                                    <span>A leading Chemical Company </span>

			                                </div>

							       		</div>

							       	</div>



							       	<div class="col-md-4">

							       		<div class="packeg-div">

							       			<h3>Our customer's feedback </h3>

							       			<p>We appreciate your quick response to our queries and flexibility to personalise the report as per our needs. </p>

							       			<div class="client-info">

			                                    <h4>Marketing Director</h4>

			                                    <span>A leading Chemical Company </span>

			                                </div>

							       		</div>

							       	</div>

						       </div>

						    </div>



						    <div class="item">

						      	 <div class="row">

							       	<div class="col-md-4">

							       		<div class="packeg-div">

							       			<h3>Our customer's feedback </h3>

							       			<p>We appreciate your quick response to our queries and flexibility to personalise the report as per our needs. </p>

							       			<div class="client-info">

			                                    <h4>Marketing Director</h4>

			                                    <span>A leading Chemical Company </span>

			                                </div>

							       		</div>

							       	</div>



							       <div class="col-md-4">

							       		<div class="packeg-div">

							       			<h3>Our customer's feedback </h3>

							       			<p>We appreciate your quick response to our queries and flexibility to personalise the report as per our needs. </p>

							       			<div class="client-info">

			                                    <h4>Marketing Director</h4>

			                                    <span>A leading Chemical Company </span>

			                                </div>

							       		</div>

							       	</div>



							       	<div class="col-md-4">

							       		<div class="packeg-div">

							       			<h3>Our customer's feedback </h3>

							       			<p>We appreciate your quick response to our queries and flexibility to personalise the report as per our needs. </p>

							       			<div class="client-info">

			                                    <h4>Marketing Director</h4>

			                                    <span>A leading Chemical Company </span>

			                                </div>

							       		</div>

							       	</div>

						       </div>

						    </div>

						</div> 					    

					</div>

        		</div>

        		

        	</div>

        </section>

	<!-- BODY WORK CLOSE -->

<?php include('includedItems/footer.php');?>

