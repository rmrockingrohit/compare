<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Report extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	  public function __construct() 
    {
        parent::__construct();
     
        // load form and url helpers
        $this->load->helper(array('form', 'url'));
         $this->load->library('session'); 
         $this->load->library('email'); 
        // load form_validation library
        $this->load->library('form_validation');   	
		$this->load->helper('html');	
	}  
	
	public function index()
	{
		$this->load->model('reportmodel');
		$this->load->model('skillmodel');
		$result = $this->reportmodel->getreport();
		$data ["report"] =$result;

		$this->load->view('admin/header');
		$this->load->view('admin/manage_report' , $data);
		$this->load->view('admin/footer');
	}
	
	public function update()
	{
	    $id = $this->uri->segment(4);
		$this->load->model('reportmodel');
		$this->load->model('skillmodel');
		
		$res = $this->reportmodel->getreportByid($id);
		$data["report"] = $res;
		$res1 = $this->skillmodel->getskills();
		$data["category"] = $res1;

		$this->load->view('admin/header');
		$this->load->view('admin/edit_report' , $data);
		$this->load->view('admin/footer');
	}

	public function correction()
	{
	    $id = $this->uri->segment(4);
		$this->load->model('reportmodel');
		$this->load->model('skillmodel');
		
		$res = $this->reportmodel->getreportByid($id);
		$data["report"] = $res;
		$res1 = $this->skillmodel->getskills();
		$data["category"] = $res1;
		$this->load->view('admin/header');
		$this->load->view('admin/correction_report' , $data);
		$this->load->view('admin/footer');
	}

	public function correctionreport(){
		$this->load->model('reportmodel');
		$this->load->model('skillmodel');
		$id = $_REQUEST['id'];
		$id = $_REQUEST['correction_update'];
		$status = "Unapproved";
		$this->reportmodel->correction_report($id,$correction,$status);
		redirect(base_url()."index.php/admin/report");
	}
	

    public function updatecorrectionreport(){
		$this->load->model('reportmodel');
		$this->load->model('skillmodel');
		$id = $_POST['id'];
		$status = "Unapproved";
		$report_corr = $_REQUEST['report_corr'];
		$this->reportmodel->correction_report($id,$status,$report_corr);
		$getAuthor = $this->reportmodel->getAuthorOfReportUpdate($id);
		 $this->data['data'] = '<h2>Hi Admin!,</h2>
            			 <p>Report Not Apporved By Site Administrator.</p>
		                 <p>Your Report Has <b> Not been Apporved </b> Please Correct Your Report With Suggested Field. <strong>'.$report_corr.'</strong></p>';
		
		$msg =  $this->load->view('admin/emailTemp',$this->data,true);
			
		// Send Email to administrator For Alert Of New Report Submittion
		$this->load->library('email');
        $this->email->from('insight@coscode.com',"noreply");
        $this->email->to($getAuthor[0]->username);
        
        $this->email->set_header('MIME-Version', '1.0; charset=utf-8');
        $this->email->set_header('Content-type', 'text/html');

        $this->email->subject('Report Not Apporved By Site Administrator.');
        $this->email->message($msg);
        
        if($this->email->send()){
            echo "mail Sent";
        }
        
		redirect(base_url()."index.php/admin/report");
	}


	public function updatereport(){
		$this->load->model('reportmodel');
		$this->load->model('skillmodel');
		$id              = $_REQUEST['id'];
		$title           = $_REQUEST['report_name'];
		$project_link    = $_REQUEST['report_desc'];
		$report_price    = $_REQUEST['report_price'];
		$status          = "Inprogress";
		$category        = $_REQUEST['category'];
		$Publisher_date  = $this->input->post('Publisher_date');
	
		$image = FALSE;
		if(isset($_FILES["image"]["name"]) && ($_FILES["image"]["name"])){
			$physicalpath =  $_SERVER['DOCUMENT_ROOT']."/".basename(base_url())."/report_uploads/";
			$image = date("dmYGis").$_FILES["image"]["name"];
			move_uploaded_file($_FILES["image"]["tmp_name"],$physicalpath.$image);
		}
		 $this->reportmodel->updatereport($id,$title,$project_link,$category,$image,$report_price,$status,$Publisher_date);
		
		// Email Notification 
		$this->session->set_flashdata("success","Update Successfully");
			
    		// In cse of not admin
            $userMail           = $this->session->userdata('adminEmail');
            if($userMail != 'admin@admin.com'){
			    $getUserIfo   = $this->reportmodel->getUserInfoByUsername($id);
			    $this->data['data'] = '<h2>Hi Admin!,</h2>
            			 <p>You have A New Message From <strong>'.$this->session->userdata('adminName').'</strong>.</p>
            			 <p style="margin-top:30px;"><b>'.$this->session->userdata('adminName').'</b> Updated a report Named <b>'.$title.'</b> Today at '.date("H:i:s").'</p>';
            			 $to = 'insight@coscode.com';
            			 $from = $userMail;
            			 $frmTitle = 'noreply@coscode.com';
            }else{
                $getAuthor = $this->reportmodel->getAuthorOfReportUpdate($id);
                $this->data['data'] = '<h2>Hi '.$getAuthor[0]->username.'!,</h2>
            			 <p>Your Report  <strong>'.ucwords($getAuthor[0]->reportname).'</strong> has been Edited By Site Administrator. Check Your Posted Report Data if you need anything change contact to site administrator at insight@coscode.com. </p>';
            			 $from = 'insight@coscode.com';
            			 $to = $getAuthor[0]->username;
            			 $frmTitle = 'noreply@coscode.com';
            }
            			 
			$msg =  $this->load->view('admin/emailTemp',$this->data,true);
			
			// Send Email to administrator For Alert Of New Report Submittion
    			$this->load->library('email');
                $this->email->from($from,$fromTitle);
                $this->email->to($to);
                
                $this->email->set_header('MIME-Version', '1.0; charset=utf-8');
                $this->email->set_header('Content-type', 'text/html');

                $this->email->subject('New Report Submitted By '.$this->session->userdata("adminName"));
                $this->email->message($msg);
                
                $this->email->send();
		
		
		redirect(base_url()."index.php/admin/report");
	}
	
	public function addreport(){
		
		$this->load->view('admin/header');
		$this->load->model('skillmodel');
		$res = $this->skillmodel->getskills();
		$data = array();
		$data ["category"] = $res;
		$this->load->view('admin/add_report', $data );
		$this->load->view('admin/footer');
	}

public function insertreport()
	{
		$this->load->model('reportmodel');
		$this->load->model('skillmodel');
		
		
		$title              = $_REQUEST['report_name'];
		$project_link       = $_REQUEST['report_desc'];
		$project_price      = $_REQUEST['report_price'];
		$status             = "Inprogress";
		$category           = $_REQUEST['category'];
		$Publisher_date     = $_REQUEST['Publisher_date'];
		$Publisher_name     = $_REQUEST['Publisher_name'];
		$report_subcategory = $_REQUEST['report_subcategory'];
		$report_id          = $_REQUEST['report_id'];
		$report_cagr        = $_REQUEST['report_cagr'];
		$report_toc         = $_REQUEST['report_toc'];
		
		// In cse of not admin
        $userMail           = $this->session->userdata('adminEmail');
		

		$physicalpath  =  $_SERVER['DOCUMENT_ROOT']."/".basename(base_url())."/vender/uploads/'";

		$image = date("dmYGis").$_FILES["image"]["name"];
		if(move_uploaded_file($_FILES["image"]["tmp_name"],$physicalpath.$image)){
			$insertrid = $this->reportmodel->insreport($title,$project_link,$category,$image,$project_price,$status,$Publisher_date,$Publisher_name,$report_subcategory,$report_id,$report_cagr,$report_toc);
			 if($insertrid){
    			$this->session->set_flashdata("success","Inserted Successfully");
    			$getUserIfo   = $this->reportmodel->getUserInfoByUsername($insertrid);
			
			    $this->data['data'] = '<h2>Hi Admin!,</h2>
            			 <p>You have A New Message From <strong>'.$this->session->userdata('adminName').'</strong>.</p>
            			 <p style="margin-top:30px;"><b>'.$this->session->userdata('adminName').'</b> Posted a new report Named <b>'.$title.'</b> Today at '.date("H:i:s").'</p>';
            			 
            			 
			$msg =  $this->load->view('admin/emailTemp',$this->data,true);
			
			// Send Email to administrator For Alert Of New Report Submittion
    			$this->load->library('email');
                $this->email->from($userMail, 'noreply@coscode.com');
                $this->email->to('insight@coscode.com');
                
                $this->email->set_header('MIME-Version', '1.0; charset=utf-8');
                $this->email->set_header('Content-type', 'text/html');

                $this->email->subject('New Report Submitted By '.$this->session->userdata("adminName"));
                $this->email->message($msg);
                
                $this->email->send();
		}
		else
		{
			$this->session->set_flashdata("error","Server issue ! Please try again later");
		}
			redirect(base_url()."index.php/admin/report");
		}
	}

	public function delete()
	{
	    $id = $this->uri->segment(4);
		$this->load->model('reportmodel');
		$this->reportmodel->deletepro($id);
		redirect(base_url()."index.php/admin/report");	
	}
	
	public function approve()
	{
	    $id = $this->uri->segment(4);
		$this->load->model('reportmodel');
		$upd = $this->reportmodel->approve($id);
		if($upd){
		    $this->session->set_flashdata('success','Report Approved Successfuly');
		    $getAuthor = $this->reportmodel->getAuthorOfReportUpdate($id);
            $this->data['data'] = '<h2>Hi '.$getAuthor[0]->username.'!,</h2>
            			               <p>Your Report  <strong>'.ucwords($getAuthor[0]->reportname).'</strong> has been Approved By Site Administrator  Today at '.date("H:i:s").'. if you need anything change contact to site administrator at insight@coscode.com. </p>';
            			 
            			 
			$msg =  $this->load->view('admin/emailTemp',$this->data,true);
			
			// Send Email to administrator For Alert Of New Report Submittion
    			$this->load->library('email');
                $this->email->from('insight@coscode.com', 'noreply@coscode.com');
                $this->email->to($getAuthor[0]->username);
                
                $this->email->set_header('MIME-Version', '1.0; charset=utf-8');
                $this->email->set_header('Content-type', 'text/html');

                $this->email->subject('Report Approved by insight@coscode.com');
                $this->email->message($msg);
                
                $this->email->send();
		}else{
		    $this->session->set_flashdata('error','Server Busy Try Later.');
		}
		redirect(base_url()."index.php/admin/report");	
	}
	
	
	 // Send Gmail to another user
    public function Send_Mail() {
        
        // Check for validation
            
            // Configure email library
            $config['protocol'] = 'smtp';
            $config['smtp_host'] = 'smtp.seisotech.org';
            $config['smtp_port'] = 80;
            $config['smtp_user'] = 'seisotec_wp851';
            $config['smtp_pass'] = 'market';

            // Load email library and passing configured values to email library 
            $this->load->library('email', $config);
            $this->email->set_newline("\r\n");
            
            // Sender email address
            $this->email->from('akshaym8677@gmail.com');
            // Receiver email address
            $this->email->to('akshaym8677@gmail.com');
            // Subject of email
            $this->email->subject('approval');
            // Message in email
            $this->email->message('this report is approved');

            if ($this->email->send()) {
                $data['message_display'] = 'Email Successfully Send !';
            } else {
                $data['message_display'] = '<p class="error_msg">Invalid Gmail Account or Password !</p>';
            }
           // $this->load->view('admin/manage_report', $data);
        }

	
	
	
}
