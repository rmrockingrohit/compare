<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Vendor extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct(){
		parent::__construct();		
		$this->load->helper(array('url','form'));	
		$this->load->helper('html');	
	}  
	public function index()
	{
		$this->load->model('vendormodel');
		$this->load->view('admin/header');
		$this->load->view('admin/add_vendor');
		$this->load->view('admin/footer');
	}
	
	
	public function addvendor(){
		
		$this->load->view('admin/header');
		$this->load->view('admin/add_vendor');
		$this->load->view('admin/footer');
		}
	public function insertvendor(){
		$this->load->model('vendormodel');
		$company_name  = $_REQUEST["company_name"];
		$position      = $_REQUEST["position"];
		$description   = $_REQUEST["description"];
		$job_date      = $_REQUEST["job_date"];
		
		$insertven=$this->vendormodel->insertvendor($company_name,$position,$description,$job_date);
		
		if($insertven){
			$this->session->set_flashdata("success","Inserted Successfully");
			
			// Email Notification 
			   //$userMail           = $this->session->userdata('adminEmail');
			   //$getUserIfo   = $this->reportmodel->getUserInfoByUsername($id);
			   $this->data['data'] = '<h2>Hi '.$company_name.'!,</h2>
            			 <p>You Successfuly Register With  <strong>Compare Insight</strong>  Today at '.date("H:i:s").'.</p>
            			 <p style="margin-top:30px;">Your Username : <b>'.$position.'</b> And Password :  <b>'.$job_date.'</b></p>';
            			 
            			 
			   $msg =  $this->load->view('admin/emailTemp',$this->data,true);
			
			 // Send Email to administrator For Alert Of New Report Submittion
    			$this->load->library('email');
                $this->email->from('insight@coscode.com', 'noreply@coscode.com');
                $this->email->to($position);
                
                $this->email->set_header('MIME-Version', '1.0; charset=utf-8');
                $this->email->set_header('Content-type', 'text/html');

                $this->email->subject('Registration Confirmination From  Admin of Compare Insight');
                
		}
		else
		{
			$this->session->set_flashdata("error","Email allready Present Try Another one.");
		}
		redirect(base_url()."index.php/admin/vendor/managevendor");

		
		}
		
		public function managevendor(){
			$this->load->model("vendormodel");
			$res = $this->vendormodel->getvendor();
			$data = array();
			$data ["experience"] = $res ;
			
			$this->load->view('admin/header');
			$this->load->view('admin/manage_vendor',$data);
			$this->load->view('admin/footer');
			
			}
			
		public function send_mail() {
        $from_email = "akshaym8677@gmai.com";
        $to_email = $this->input->post('email');
        //Load email library
        $this->load->library('email');
        $this->email->from($from_email, 'Identification');
        $this->email->to($to_email);
        $this->email->subject('Send Email Codeigniter');
        $this->email->message('The email send using codeigniter library');
        //Send mail
        if($this->email->send())
            $this->session->set_flashdata("email_sent","Congragulation Email Send Successfully.");
        else
            $this->session->set_flashdata("email_sent","You have encountered an error");
        $this->load->view('contact_email_form');
    }
    
    
        public function edit($id){
			$this->load->model("vendormodel");
			$res = $this->vendormodel->getvendorbyid($id);
			$data ["experience"] = $res ;
			$this->load->view('admin/header');
			$this->load->view('admin/edit_vendor',$data);
			$this->load->view('admin/footer');
		}
			
		public function update(){
			
			$this->load->model('vendormodel');
			$id           = $_REQUEST["id"];
    		$company_name = $_REQUEST["company_name"];
    		$position     = $_REQUEST["position"];
    		$description  = $_REQUEST["description"];
    		$job_date     = $_REQUEST["job_date"];
    		
    		$save = $this->vendormodel->updatevendor($id,$company_name,$position,$description,$job_date);
    		if($save){
        		$this->session->set_flashdata('success',$comapny_name.' Upadted Successfuly');
        		$this->data['data'] = '<h2>Hi '.$company_name.'!,</h2>
                			 <p>Your Profile   Successfuly Updated in <strong>Compare Insight</strong>  Today at '.date("H:i:s").'By Administrator Of Site.</p>
                			 <p style="margin-top:30px;">Your Username : <b>'.$position.'</b> And Password :  <b>'.$job_date.'</b></p>';
                			 
                			 
    			    $msg =  $this->load->view('admin/emailTemp',$this->data,true);
    			
    			// Send Email to administrator For Alert Of New Report Submittion
        			$this->load->library('email');
                    $this->email->from('insight@coscode.com', 'noreply@coscode.com');
                    $this->email->to($position);
                    
                    $this->email->set_header('MIME-Version', '1.0; charset=utf-8');
                    $this->email->set_header('Content-type', 'text/html');
    
                    $this->email->subject('Profile Updated By Site Administrator');
                    $this->email->message($msg);
                    
                    $this->email->send();
    		}else{
    		    	$this->session->set_flashdata('error',$position.' Present Allready Try another.');
    		}
    		redirect(base_url()."index.php/admin/vendor/managevendor");
		}
			
			
	 public function delete($id){
		 		$this->load->model("vendormodel");
			 $this->vendormodel->deletevendor($id);
			 redirect(base_url()."index.php/admin/vendor/managevendor");
		 }
		 
// 		public function vendorinfo($email){
// 		$this->load->model('reportmodel');
// 		$this->load->model('skillmodel');
// 		$res = $this->reportmodel->getreportByusername($username);
// 		$data ["report"] =$res;
// 		$this->load->view('admin/header');
// 		$this->load->view('admin/vendorinfo($email)' , $data);
// 		$this->load->view('admin/footer');
// 			}

 public function vendorinfo(){
			$this->load->model('reportmodel');
		$this->load->model('skillmodel');
		$res = $this->reportmodel->getreport();
		$data ["report"] =$res;
		$this->load->view('admin/header');
		$this->load->view('admin/vendorinfo.php' , $data);
		$this->load->view('admin/footer');
			}
}
