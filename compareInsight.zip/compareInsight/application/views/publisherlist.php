<?php include('includedItems/headers.php');?>
<style type="text/css">
  .txt{
    color: #000;
    font-weight: 900;
    font-size: 14px;
    display: block;
  }
  .txt:hover{
    color: #000;
    text-decoration: none;
  }
  .table > thead > tr > th, .table > tbody > tr > th, .table > tfoot > tr > th, .table > thead > tr > td, .table > tbody > tr > td, .table > tfoot > tr > td{
    vertical-align: middle;
    padding: 20px 10px !important;
  }
</style>
    <!-- BODY WORK START -->
        <?php include('includedItems/navigation.php');?>
        <?php    /*$sql="SELECT * FROM report WHERE publisher_name LIKE 'a%' OR publisher_name LIKE 'A% '";
                 $result=mysqli_query($conn,$sql);
                 $data = array();
                 if ($result->num_rows > 0) {
	                 while($row = $result->fetch_assoc()) {
	                 	array_push($data, $row);
	                 }
	             }*/
		?>

        <div class="container-fluid">
        	<div class="row">
        		<div class="research-bg-section">
        			<div class="headigs">
        				<h3 class="testimonials-heading"><?php echo "All ".ucfirst($title); ;?></h3>
        			</div>
        		</div>
        	</div>
        </div>


        <div class="container">                
			    <div class="row form-group">
            <div class="col-md-12 " id="pages">
              <h5 class="heading text-center">
                <span class='black-heads'>Publisher's </span><span class="gold-head">List</span>
              </h5>
            </div>
          </div>

          <div class="row form-group">    
            <div class="table-responsive">
              <table class="table table-striped table-borderd" id="example">
                <thead>
                    <tr>
                      <th>Sr. No. </th>
		                  <th>Publisher Name </th>
		                  <!-- <th>Publisher Date </th> -->
		                  <th width="30%">Report Title </th>
		                  <th>Report Price</th>
		                  <th>Report Sample</th>
		                  <!-- <th>View All</th> -->
                    </tr>
                </thead>
                <tbody>
                  <?php 
                  	$i = 1;
                  	foreach($data as $val){?>
                    <tr>
                      <td><?php echo $i;?></td>
                      <td><?php echo $val['publisher_name'];?> </td>
                      <!-- <td><?php //echo $val['publisher_date'];?> </td> -->
                      <td><a href="<?php echo base_url('Website/report_info/'.$val['id']);?>" class="txt"><?php echo $val['reportname'];?></a> </td>
                      <td><?php echo $val['price'];?></td>                    
                      <td> <a class="nav-link btn-danger" href="<?php echo base_url('website/');?>enquery/<?php echo $val['id'];?>">sample available </a></td>                         
                     <!--  <td> <a class="nav-link btn btn-warning" href="<?php //echo base_url('website/');?>publisherDetail/<?php //echo $val['publisher_name'];?>">view all 
                         </a></td> -->
                  </tr>
                  <?php $i++;} ?>
                </tbody>
              </table>
            </div>

          </div>
      </div>
    <!-- BODY CLOSE -->
<?php include('includedItems/footer.php');?>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
    $('#example').DataTable( {
        "pagingType": "full_numbers"
    } );
} );
</script>
