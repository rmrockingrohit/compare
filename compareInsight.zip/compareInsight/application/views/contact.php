<?php include('includedItems/headers.php');?>
	
    <!-- BODY WORK START -->
        <?php include('includedItems/navigation.php');?>
        <?php //include('includedItems/slides.php');?>

        <div class="container-fluid">
            <div class="row">
                <div class="contact-bg-section">
                    <div class="headigs">
                        <h3 class="testimonials-heading">Contact Us</h3>
                    </div>
                </div>
            </div>
        </div>

        <div class="container-fluid">
        	<div class="row form-group">
        		<div class="col-md-6">
        			<div class="row">
        				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3780.71437723355!2d73.79705747445723!3d18.631912376004504!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2b84cf0f42a0b%3A0xda648cce83edff79!2sEmpire+Estate+Phase+1%2C+Chinchwad%2C+Pimpri-Chinchwad%2C+Maharashtra+411019!5e0!3m2!1sen!2sin!4v1559821484519!5m2!1sen!2sin" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
        			</div>
        		</div>
        		<div class="col-md-6 contact">
        			<div class="col-md-12 ">
                        <h3>Contact Address </h3>
                        <ul style="">
                            <li class="gold-head">Address:</li>
                            <li>Empire estate, D5.-</li>
                            <li>Chinchwad Pune</li>
                            <li>Maharashtra India 411009</li>
                            <li><span class="gold-head">Phone No:</span> +91-8007406789</li>
                            <li><span class="gold-head">Email Address:</span> <a href="mailto:sales@compareinsight.com"> Sales@compareinsights.com</a><br/> <a href="mailto:sales@compareinsight.com">Queries@compareinsights.com</a> </li>
                        </ul>   
                    </div>
        		</div>
        	</div>

            <div class="row">
                <div class="inqury">
                    <div class="row">
                        <div class="col-md-7">
                            <div class="row">
                                <div class="inquries-bg"></div>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="foot-form">
                                <div class="form-horizontal contact-form" >
                                    <fieldset>
                                        <h3 class="text-center">Contact us</h3>
                            
                                        <!-- Name input-->
                                        <div class="form-group">
                                          <label class="col-md-3 control-label" for="name">Name</label>
                                          <div class="col-md-9">
                                            <input id="name" name="name" type="text" placeholder="Your name" class="form-control" required="required" id="name">
                                          </div>
                                        </div>
                        
                                        <!-- Email input-->
                                        <div class="form-group">
                                          <label class="col-md-3 control-label" for="email">Your E-mail</label>
                                          <div class="col-md-9">
                                            <input id="email" name="email" type="email" placeholder="Your email" class="form-control" required="required" id="email">
                                          </div>
                                        </div>
                        
                                        <!-- Message body -->
                                        <div class="form-group">
                                          <label class="col-md-3 control-label" for="message">Your message</label>
                                          <div class="col-md-9">
                                            <textarea class="form-control" id="message" name="message" placeholder="Please enter your message here..." rows="5" required="required" id="msg"></textarea>
                                          </div>
                                        </div>
                        
                                        <!-- Form actions -->
                                        <div class="form-group">
                                          <div class="col-md-12 text-right">
                                            <button type="button" class="btn btn-black" name="submit" id="contactMail">
                                                <i class="fas fa-paper-plane"></i> 
                                                Send
                                            </button>
                                          </div>
                                        </div>

                                    </fieldset>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php include('includedItems/footer.php');?>