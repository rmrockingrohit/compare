<?php include('includedItems/headers.php');?>

    <!-- BODY WORK START -->
<style>
.btn{
    border-radius: 0px;
}

.display-box{
    border-radius: 0px;
    border-bottom: 3px solid #0a0adb;
    border-right: 1px solid blue;
}
.img-box img,.profile-image img {
    width: 100%;
    box-shadow: none !important;
}
.img-box {
    margin-bottom: 10px;
    background: #eadca3;
}
.proile-tag{
    font-size: 12px !important;
    color: #f5c200 !important;
}
.research-bg-section{
    position:relative;
}
.headigs img{
    position: absolute;
    top: 0px;
    left: 47%;
    width: 70px;
    margin-top: 15px;
    background: #f0c422;
    border-radius: 50%;
    height: 70px;
    padding: 15px;
}
.checkboxes{
    display: block;
    text-align: left;
    color: #000;
    font-weight: 600;
}
.checkboxes:hover{
    text-decoration: none;
}
.heading-box a p{
    color: #ff2929;
    font-weight: 900;
    word-spacing: 2px;
    letter-spacing: 1px;
     font-size: 20px; 
    /* padding: 0px !important; */
    height: 60px;
}
.pdf .far{
color: #ea4747;
font-size: 20px;
font-weight: 100;
margin-right: 15px;
}
.price-tag{
    padding: 0px 15px;
}
.price-tag span{
    float: right;
}
.price-tag label{
    float: left;
}
.btn-close{
    position: relative;
    top: -23px;
    background: red;
    border-radius: 50%;
    height: 25px;
    width: 25px;
    text-align: center;
    line-height: 25px;
    color: #fff;
    float: right;
    right: -27px;
}
.btn-close:hover{
    background: #fff;
    border: 1px solid red;
    color: red;
    font-weight: 600;
}
</style>
        <?php include('includedItems/navigation.php');?>

       
 <?php include('includedItems/cart.php');?>
<style type="text/css">
    footer{
        padding: 0px;
    }
</style>
 <div class="container-fluid">

    <div class="row">

        <div class="research-bg-section">

            <div class="headigs">

                <h3 class="testimonials-heading">
                    <?php echo ucfirst($title);?>                                        
                </h3>

            </div>

        </div>

    </div>

</div>
<?php if(isset($cartItem) && !empty($cartItem)){?>
    <div class="container">
        <form method="POST" action="<?php echo base_url('Website/checkout_process');?>">
        <?php if(isset($cartItem)){?>
            <div class="col-md-8">
                <?php 
                    $i=1;
                    $total = $report_id = array();
                    foreach ($cartItem as $row){?>
                       <input type="hidden" name="reportID[]" value="<?php echo $row['id'] ?>">
    
                        <div class="display-box"> 
                            <a href="<?php echo base_url('Website/removecart/'.$row['id']);?>" class="btn-close">
                                <i class="fas fa-times"></i>
                            </a>
    
                            <div class="row" id="reports">
    
                                <div class="col-md-3">
    
                                    <div class="img-box text-center">
                                        <a href="<?php echo base_url('website/');?>report_info/<?php echo $row['id'];?>">
                                            <?php if(!empty($row['reportdoc']) || $row['reportdoc'] != ''){
                                                    foreach($skillNav as $id){
    
                                                        if($id['id'] == $row['category']){
                                            ?>
                                                    <?php if ($id['id'] =="4"){?>
                                                            <img src="<?php echo base_url('vender\images\book/industries.png');?>" alt="Industrial Automation" class="himg" >
                                                    <?php }else if($id['id'] =="78"){?>
                                                            <img src="<?php echo base_url('vender\images\book/medicine.png');?>" alt="sports" class="himg" >
                                                    <?php }else if($id['id'] =="3"){?>
                                                            <img src="<?php echo base_url('vender\images\book/food.png');?>" alt="Food & Beverage" class="himg" >
                                                    <?php }else if($id['id'] =="76"){?>
                                                            <img src="<?php echo base_url();?>vender\images\book/chemistry.png" alt="Chemicals & Materials" class="himg" >
                                                    <?php }else if($id['id'] =="75"){?>
                                                            <img src="<?php echo base_url('vender\images\book/transport.png');?>" alt="Automotive & Transportation" class="himg" >
                                                    <?php }else if($id['id'] =="1"){?>
                                                            <img src="<?php echo base_url('vender\images\book/electronic.png');?>" alt="Electronics & Semiconductor" class="himg" >
                                                    <?php }else if($id['id'] =="77"){?>
                                                            <img src="<?php echo base_url('vender\images\book/medicine.png');?>" alt="Healthcare, Pharmaceuticals & Medical Devices" class="himg" >
                                                    <?php }else if($id['id'] =="2"){?>
                                                            <img src="<?php echo base_url('vender\images\book/retail.png');?>" alt="Retail & Consumer Goods" class="himg" >
                                                    <?php }else if($id['id'] =="79"){?>
                                                            <img src="<?php echo base_url('vender\images\book/defencce.png');?>" alt="Aerospace and Defense" class="himg" >
                                                    <?php }else if($id['id'] =="80"){?>
                                                            <img src="<?php echo base_url('vender\images\book/constuction.png');?>" alt="Building, Construction Manufacturing" class="himg" >
                                                    <?php }
                                                    }?>
                                            <?php }}else{?>
                                                    <img src="<?php echo base_url();?>vender/images/database-connection-error.jpg">
                                            <?php }?>
                                        </a>
                                    </div>
    
                                </div>
    
                                <div class="col-md-9">
    
                                    <div class="heading-box">
    
                                        <div class="row form-group">
    
                                            <a href="<?php echo base_url('website/');?>report_info/<?php echo $row['id'];?>">
                                                <p><?php echo $row['reportname'];?></p>
                                            </a>
    
                                        </div>
    
                                        <div class="row form-group" style="border-top:none;padding: 15px;margin-top:0;background: #fff;">
    
                                            <div class="col-md-12">
    
                                                <div class="row">
    
                                                    <label class="heading-label">Publishing Date </label>
    
                                                    <label class="tiny txt-lbl">
    
                                                        <?php   $date=date_create($row['publisher_date']);
                                                                echo date_format($date,"M - Y");
                                                        ?>
                                                    </label>
    
                                                </div>
    
    
    
                                                <div class="row">
    
                                                    <label class="heading-label">Report Format</label>
    
                                                    <label class="txt-lbl pdf">
    
                                                        <i class="far fa-file-pdf" aria-hidden="true"></i> Available in PDF.
    
                                                    </label>
    
                                                </div>
    
                                            </div>
                                        </div>
    
                                    </div>
    
                                </div>
    
                            </div>           
    
                        </div>
    
                <?php }?>
            </div>
    
            <div class="col-md-4">
                
                <div class="card">
                    <div class="row form-group">
                        <article class="card-group-item">
                            <header class="card-header">
                                <h5 class="title absolute-title">PURCHASE OPTIONS</h5>
                            </header>
                            <div class="filter-content">
                                <div class="card-body">
                                    <form class="col-md-12" action="<?php echo base_url('Website/checkout_process');?>" method="POST">  
                                        <div class="row form-group price-tag">                                      
                                            <label>
                                                <input type="radio" name="checkbox" value="<?php echo "1000.00";?>" required>  
    
                                                    Single User         
                                            </label>
                                            <span> <i class="fas fa-dollar-sign"></i> <?php echo number_format(1000,2);?></span> 
                                        </div>
    
                                        <div class="row form-group price-tag">                                      
                                            <label>
                                                <input type="radio" name="checkbox" value="<?php echo 2000;?>" required>  
                                                    Multi User          
                                            </label>
                                            <span> <i class="fas fa-dollar-sign"></i> <?php echo number_format(2000,2);?></span>
                                        </div>
    
                                        <div class="row form-group  price-tag">                                     
                                            <label>
                                                <input type="radio" name="checkbox" value="<?php echo 3000;?>" required>  
                                                    Five User                                                       
                                            </label>
                                            <span> <i class="fas fa-dollar-sign"></i> <?php echo number_format(3000,2);?></span> 
                                        </div>
    
                                        <div class="row form-group  price-tag">                                     
                                            <label>
                                                <input type="radio" name="checkbox" value="<?php echo 4000;?>" required>  
                                                    Enterprise User 
                                            </label>
                                             <span> <i class="fas fa-dollar-sign"></i>  <?php echo number_format(4000,2);?></span>
                                        </div>
    
                                        <div class="row">
                                            <div class="col-md-12">     
                                                <div class="col-md-6 text-right">
                                                    <a href="<?php echo base_url('Website/resetCart');?>" class="btn btn-danger">Reset Cart</a>
                                                </div>
                                                <div class="col-md-6 text-left">
                                                    <input type="submit" class="btn btn-warning" value="Buy Report">
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div> <!-- card-body.// -->
                            </div>
                        </article> <!-- card-group-item.// -->                                  
                    </div>                                  
                </div>
    
            </div>
        <?php }else{?>
    
        <?php }?>
       </form>
    </div>
<?php }else{?>
        <div class="container">
            <div class="col-md-6 col-md-offset-2">
                <h3 class="alert alert-danger" style="margin-bottom:50px;">No any Product Listed By You . Please Click On Add To Cart On Research Industry.</h3>
            </div>
        </div>
        
<?php }?>

<?php /*
<h1><center><b style="color: #ccda63;"><?php echo ucfirst($title);?></b></center></h1><br><br>




<form action="#" method="POST"></form>
<div class="container mb-4">
    <div class="row">
        <div class="col-12">
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th style="text-align: center;">Sr.no </th> 
                            <th style="text-align: center;">Report Title</th>
                            <th style="text-align: center;">purchase option</th>
                            <th style="text-align: center;">Price</th>
                            <?php if(!isset($buyItem)){?>
                                    <th style="text-align: center;">Remove Cart </th>
                            <?php }?>
                            
                        </tr>
                    </thead>

                    <?php if(isset($cartItem)){?>
                        <tbody>
                            <tr>
                                <?php     $i=1;
                                          $total = array();
                                          foreach ($cartItem as $row){ ?>

                                            <tr class="body-table">
                                                <td><?php echo $i;?></td>  
                                                <td><?php echo $row['reportname'];?></td>
                                                <td>
                                                    <select id="size_select<?php echo $i;?>">
                                                        <option selected="selected">Please select ... </option>
                                                        <option value="<?php echo $row['price'];?>" data-text="single user">single user type</option>
                                                        <option value="<?php echo $row['project_pricemulti'];?>" data-text="multi user">multi user type</option>
                                                        <option value="<?php echo $row['project_pricefive'];?>" data-text="five user">five user type</option>
                                                        <option value="<?php echo $row['project_priceenterp'];?>" data-text="enterprise user">enterprise user type</option>                                                  
                                                    </select>
                                                </td>
                                                <script>
                                                   
                                                    $('#size_select<?php echo $i;?>').on('change',function(){
                                                         var priceValue<?php echo $i;?> = $(this).val();
                                                         var priceType<?php echo $i;?> = $("#size_select<?php echo $i;?> option:selected").text();
                                                        $('#priceValue<?php echo $i;?>').html('<i class="fas fa-dollar-sign"></i> '+priceValue<?php echo $i;?>);
                                                        $('#hiddenPrice<?php echo $i;?>').val(priceValue<?php echo $i;?>);

                                                        $.ajax({
                                                            type: "POST",
                                                            data: {price:priceValue<?php echo $i;?>,type:priceType<?php echo $i;?>,id:<?php echo $row['cartId'];?>},
                                                            url: "<?php echo base_url('Website/updateCartPrice');?>",
                                                            success: function(data){                                           

                                                            }
                                                         });
                                                        
                                                    })
                                                </script>
                                                <td>
                                                    <p id="priceValue<?php echo $i;?>"> </p>      
                                                    
                                                    <input type="hidden" name="priceValue[]" value="" id="hiddenPrice<?php echo $i;?>">                                           
                                                </td>
                                                <td class="text-right">
                                                    <button class="btn btn-sm btn-danger" id="cart<?php echo $row['id'];?>" data-value="$row['id'];?>"><a href="<?php echo base_url();?>index.php/website/removecart/<?php echo $row['id'];?>"><i class="fa fa-trash"></i></a> </button> 
                                                </td>
                                            </tr>
                                                <?php array_push($total,$row['price']);
                                          $i++;}?>
                           
                                            <tr>
                               
                                
                                <td class="text-right"></td>
                            </tr>                            
                        </tbody>
                    <?php }elseif(isset($buyItem)){?>
                            <tbody>
                                <tr class="body-table">
                                    <td><?php echo '1';?></td>
                                        
                                        <td><?php echo $buyItem[0]['reportname'];?></td>
                                        <td>
                                            <select id="size_selects">
                                                <option selected="selected" value="">Please select ... </option>
                                                <option value="<?php echo $buyItem[0]['price'];?>" data-text="single user">single user type</option>
                                                <option value="<?php echo $buyItem[0]['project_pricemulti'];?>" data-text="multi user">multi user type</option>
                                                <option value="<?php echo $buyItem[0]['project_pricefive'];?>" data-text="five user">five user type</option>
                                                <option value="<?php echo $buyItem[0]['project_priceenterp'];?>" data-text="enterprise user">enterprise user type</option>                                                  
                                            </select>
                                        </td>
                                         <script>                                                       
                                            $('#size_selects').on('change',function(){
                                                 var priceValues = $(this).val();
                                                 var priceTypes = $(this).data();
                                                 if(priceValues == ''){
                                                    $("#buyCheck").addClass('hide');
                                                 }else{
                                                    $("#buyCheck").removeClass('hide');
                                                 }
                                                $('#priceValues').text(priceValues);
                                                $('#hiddenPrices').val(priceValues);
                                                $("#forData").val(priceValues);

                                                $.ajax({
                                                    type: "POST",
                                                    data: {price:priceValues,type:priceTypes,id:<?php echo $row['id'];?>},
                                                    url: "<?php echo base_url('Website/updateCartPrice');?>",
                                                    success: function(data){                                           

                                                    }
                                                 });
                                                
                                            })
                                        </script> 
                                        <td>
                                            <p id="priceValues"> </p>      
                                            <input type="hidden" name="priceValue[]" value="" id="hiddenPrices">                                           
                                        </td>                                        
                                    </tr>
                                    <?php //array_push($total,$row['price']);
                                ?>
                               
                                <tr>
                                   
                                    
                                    <td class="text-right"></td>
                                </tr>
                                
                            </tbody>
                    <?php }?>
                </table>

                
            </div>
        </div>

        <?php if(isset($cartItem)){?>
                    <div class="col mb-2">
                        <div class="row">
                            <div class="col-sm-12  col-md-6">
                             <a class="" id='cancle'> <button class="btn btn-lg btn-block btn-success text-uppercase" style="
                width: 234px;
                margin-left: 300px;
                padding-bottom: 5px;
            ">Reset Cart</button></a>
                            </div>
                            <div class="col-sm-12 col-md-6 text-right">
                                <a href="<?php echo base_url('website/');?>cheakout/<?php echo $row['id']; ?>" >
                                    <button class="btn btn-lg btn-block btn-success text-uppercase" style="width: 234px; padding-bottom: 5px;">Checkout</button></a>
                            </div>
                        </div>
                    </div>
        <?php }?>

        <?php if(isset($buyItem)){?>
                    <div class="row form-group">
                        <div class="col-md-12 text-right">
                            <!-- <a href="<?php //echo base_url('website/');?>cheakout/<?php //echo $buyItem[0]['id']; ?>"  class="btn btn-lg btn-block btn-success text-uppercase" style="width: 234px;padding-bottom: 5px;">Checkout</a> -->
                            <button type="button" class="btn btn-success hide" data-toggle="modal" data-target="#myModal" id="buyCheck">CheckOut</button>
                        </div>
                    </div>

                    <!-- Buy Modal -->
                            <div id="myModal" class="modal fade" role="dialog">
                              <div class="modal-dialog">

                                <!-- Modal content-->
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Checkout Information</h4>
                                  </div>
                                  <div class="modal-body">
                                    <div class="row form-group">
                                        <form class="form-horizontal" method="post" action="<?php echo base_url();?>index.php/website/transaction" style="margin-bottom: 30px;">
                                            <div class="panel panel-info">
                                                <!-- <div class="panel-heading">Address</div> -->
                                                <div class="panel-body">
                                                    <div class="form-group">
                                                        <div class="col-md-12">
                                                            <h4>Shipping Address</h4>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <div class="col-md-12"><strong>Country:</strong></div>
                                                        <div class="col-md-12">
                                                            <input type="text" class="form-control" name="country" value="" / required>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <div class="col-md-6 col-xs-12">
                                                            <strong>First Name:</strong>
                                                            <input type="text" name="first_name" class="form-control" value="" / required>
                                                        </div>
                                                        <div class="span1"></div>
                                                        <div class="col-md-6 col-xs-12">
                                                            <strong>Last Name:</strong>
                                                            <input type="text" name="last_name" class="form-control" value="" / required>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <div class="col-md-12"><strong>Address:</strong></div>
                                                        <div class="col-md-12">
                                                            <input type="text" name="address" class="form-control" value="" / required>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <div class="col-md-12"><strong>City:</strong></div>
                                                        <div class="col-md-12">
                                                            <input type="text" name="city" class="form-control" value="" / required>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <div class="col-md-12"><strong>State:</strong></div>
                                                        <div class="col-md-12">
                                                            <input type="text" name="state" class="form-control" value="" / required>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <div class="col-md-12"><strong>Zip / Postal Code:</strong></div>
                                                        <div class="col-md-12">
                                                            <input type="text" name="zip_code" class="form-control" value="" / required placeholder="111111" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <div class="col-md-12"><strong>Phone Number:</strong></div>
                                                        <div class="col-md-12"><input type="text" name="phone_number" class="form-control" value="" / required oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="15" placeholder="0091 9999999999"></div>
                                                    </div>
                                                    <div class="form-group">
                                                        <div class="col-md-12"><strong>Email Address:</strong></div>
                                                        <div class="col-md-12"><input type="email" name="email_address" class="form-control" value="" / required></div>
                                                    </div>
                                                    
                                                </div>
                                            </div>

                                            <input type="hidden" name="price" value="" id="forData">
                                            <input type="hidden" name="reportId" value="<?php echo $buyItem[0]['id'];?>">
                                            
                                            <!--CREDIT CART PAYMENT END-->
                                            <div class="col-md-12 text-right">
                                                <button type="submit" class ="btn btn-info" name="submit">Proceed To Pay</button>
                                            </div>
                                         
                                        </form>
                                    </div>
                                  </div>
                                  <div class="modal-footer">
                                   <!--  <button type="button" class="btn btn-warning" data-dismiss="modal">Buy</button> -->
                                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                  </div>
                                </div>

                              </div>
                            </div>
        <?php }?>
    </div>
</div>
*/?>
</form>
    <script type="text/javascript">
        $("#cancle").on('click',function(){
            $.ajax({
                    type: "POST",
                    data: {data:'reset'},
                    url: "<?php echo base_url('index.php/Website/resetCart');?>",
                    success: function(data){                                          
                      if(data == 'true'){
                        $(".table .body-table").fadeOut(800);
                        $("#req").fadeOut(800);
                        $(".info #amountLast").text('0');
                      }                                         
                     
                    }
            });
        })
    </script>    


<?php include('includedItems/footer.php');?>

