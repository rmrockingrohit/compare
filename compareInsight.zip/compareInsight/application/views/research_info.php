<?php include('includedItems/headers.php');?>
<style type="text/css">
.profile-image img{
	width: 100%;
    height: auto;
}
.profile-image{
	margin-bottom: 10px;
    padding: 10px;
}

.profile-image p{
	font-size: 10px;
	line-height: 12px;
	margin-top: 10px;
	color: #fff;
}
	.nav-tabs{
		border-bottom: 1px solid #022ed0;
	}
	.nav-tabs > li.active > a, .nav-tabs > li.active > a:hover, .nav-tabs > li.active > a:focus{
		border-radius: 0px;
		font-weight: 600;
		border: 1px solid #022ed0;
		    border-bottom-color: rgb(2, 46, 208);
		    border-bottom-style: solid;
		    border-bottom-width: 1px;
		border-bottom: 1px solid #fff;
		color: #022ed0;
		cursor: default;
		background-color: #fff;
	}
	.nav-tabs > li > a:hover{
		background-color: #0505ce;
		color: white;
	}
	.nav-tabs > li > a {
	    float: left;
	    margin-bottom: -1px;
	    background: blue;
	    border: 1px solid #fff;
	    color: #fff;
	}
	.proile-tag {
		color: #353535 !important;
    	font-size: 14px;
    	padding: 0px !important;
	}
	.btn-cus{
		background: blue;
        border: 1px solid #fff;
        color: #fff;
        border-radius: 0px;
	}
	.price-tag span{
		float: right;
	}
	.price-tag label{
		float: left;
	}
	.pdf .far{
        color: #ea4747;
	    font-size: 20px;
	    font-weight: 100;
	    margin-right: 5px;
    }
    .h4{
    	line-height: 30px;
	    margin: 0px;
	    font-size: 20px;
	    padding-bottom: 20px;
	    color:#e60000;
	    font-weight: 900;
    }
</style>

    <!-- BODY WORK START -->

    <?php include('includedItems/navigation.php');?>


        <div class="container-fluid">

        	<div class="row">

        		<div class="research-bg-section">

        		</div>

        	</div>

        </div>

         <div class="container">
             
			<div class="row">

				<div class="col-md-12 science" style="margin-top: 150px;">

					<div class="row form-group">

						<div class="col-md-8">

							<div class="row form-group">
							    <div class="col-md-3  text-center">
							        <div class="profile-image">
							        	<?php if ($reportInfo[0]['category'] =="4"){?>
				                                <img src="<?php echo base_url('vender\images\book/industries.png');?>" alt="Industrial Automation" class="himg" >
										<?php }else if($reportInfo[0]['category']=="78"){?>
												<img src="<?php echo base_url('vender\images\book/medicine.png');?>" alt="sports" class="himg" >
										<?php }else if($reportInfo[0]['category'] =="3"){?>
												<img src="<?php echo base_url('vender\images\book/food.png');?>" alt="Food & Beverage" class="himg" >
										<?php }else if($reportInfo[0]['category'] =="76"){?>
												<img src="<?php echo base_url();?>vender\images\book/chemistry.png" alt="Chemicals & Materials" class="himg" >
										<?php }else if($reportInfo[0]['category'] =="75"){?>
												<img src="<?php echo base_url('vender\images\book/transport.png');?>" alt="Automotive & Transportation" class="himg" >
										<?php }else if($reportInfo[0]['category']=="1"){?>
												<img src="<?php echo base_url('vender\images\book/electronic.png');?>" alt="Electronics & Semiconductor" class="himg" >
										<?php }else if($reportInfo[0]['category'] =="77"){?>
												<img src="<?php echo base_url('vender\images\book/medicine.png');?>" alt="Healthcare, Pharmaceuticals & Medical Devices" class="himg" >
										<?php }else if($reportInfo[0]['category'] =="2"){?>
												<img src="<?php echo base_url('vender\images\book/retail.png');?>" alt="Retail & Consumer Goods" class="himg" >
										<?php }else if($reportInfo[0]['category'] =="79"){?>
												<img src="<?php echo base_url('vender\images\book/defencce.png');?>" alt="Aerospace and Defense" class="himg" >
										<?php }else if($reportInfo[0]['category'] =="80"){?>
												<img src="<?php echo base_url('vender\images\book/constuction.png');?>" alt="Building, Construction Manufacturing" class="himg" >
										<?php }?>
										
							        </div>
							    </div>
							    <div class="col-md-9">
							        <div class="profile-head">
							           <h4 class="h4"><?php echo ucwords($reportInfo[0]['reportname']);?></h4>							          
							           <p class="proile-tag" style=" margin: 0px;">Publish On: <span><?php  $date=date_create($reportInfo[0]['publisher_date']);echo date_format($date,"M - Y");?></span></p>

							           <p class="proile-tag pdf" style=" margin: 0px;">Report Available In : <span><i class="far fa-file-pdf" aria-hidden="true"></i> PDF</span></p>
							    
							        </div>
							    </div>
							</div>



							<div class="row form-group" style="border-top:none;">
								<div class="col-md-12">
								    <ul class="nav nav-tabs" id="myTab" role="tablist">
								        <li class="nav-item active">
								            <a class="nav-link " id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Report Overview</a>
								        </li>
								        <li class="nav-item">
								            <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Table Of Content</a>
								        </li>
								         <li class="nav-item">
								            <a class="nav-link" id="p-tab" data-toggle="tab" href="#p" role="tab" aria-controls="p" aria-selected="false">Sample Report</a>

								        </li>
								         <li class="nav-item">
								            <a class="nav-link" id="k-tab" data-toggle="tab" href="#k" role="tab" aria-controls="k" aria-selected="false">Ask for Discounts</a>

								        </li>
								    </ul>
							    
								    <div class="tab-content profile-tab" id="myTabContent">
								        
								        <div class="tab-pane fade in active" id="home" role="tabpanel" aria-labelledby="home-tab">
								            <div class="row">
								                <div class="col-md-12">
								                    <p style="padding-top:15px;color:#000;min-height:100px;"><?php echo $reportInfo[0]['reportdesc'];?></p>
								                </div>
								            </div>
								        </div>
								        
								        <div class="tab-pane fade in" id="profile" role="tabpanel" aria-labelledby="profile-tab">
								            <div class="row">
								                <div class="col-md-12">
								                    <p style="padding-top:15px;color:#000;min-height:100px;"><?php echo $reportInfo[0]['report_toc'];?></p>
								                </div>
								            </div>
								        </div>
										
										<div class="tab-pane fade in" id="p" role="tabpanel" aria-labelledby="p-tab">
								            <div class="row">
								                <div class="col-md-12">
								                    <p style="padding-top:15px;color:#000;min-height:100px;"><label><font size="5" color="#4682B4">Sample enquery Form</font></label> <br><br>
							                    		 Full Name:<input name="fullname" placeholder="Full Name" class="form-control" type="text" required="required" id="name_p">
							                    		 <br>
							                    		  Company Name:<input  name="companyname" placeholder="Company Name" class="form-control" type="text" required="required" id="companyname_p">
							                    		  <br>
							                    		   Email<input type="email" name="email" class="form-control" placeholder="Email" required="required" id="email_p">
							                    		   <br>
							                    		    Country<select name="country" class="form-control" required="required" id="country_p">
							                                            <option value="" style="color:#888;">Country</option>
							                                            <option value="USA">USA</option> <option value="UK">UK</option>
							                                            <option value="CANADA">Canada</option> 
							                                            <option value="INDIA">India</option>  <option value="PAKISTAN">Pakistan</option>
							                                            <option value="UAE">UAE</option> 
							                                            <optgroup label="- - - - - - - - - - - - - - - - -"></optgroup>
							                                            <option value="AUSTRALIA">Australia</option>
							                                            <option value="AUSTRIA">Austria</option>
							                                            <option value="BAHRAIN">Bahrain</option>
							                                            <option value="BANGLADESH">Bangladesh</option>
							                                            <option value="BELGIUM">Belgium</option>
							                                            <option value="Brazil">Brazil</option>
							                                            <option value="China">China</option>
							                                            <option value="Cuba">Cuba</option>
							                                            <option value="Cyprus">Cyprus</option>
							                                            <option value="Denmark">Denmark</option>
							                                            <option value="Fiji">Fiji</option>
							                                            <option value="Finland">Finland</option>
							                                            <option value="France">France</option>
							                                            <option value="Georgia">Georgia</option>
							                                            <option value="Germany">Germany</option>
							                                            <option value="Greece">Greece</option>
							                                            <option value="Hong Kong">Hong Kong</option>
							                                            
							                                          </select>
							                                          <br>
							                                         Mobile no.<input name="mobileno" placeholder="Mobile No." class="form-control" required="required" type="tel" id="phone_p">
							                                          <br>
							                                          Your Message <textarea name="comment" cols="40" rows="5" placeholder="Your Message"class="form-control" id="msg_p"></textarea>
							                                     <br>
								                    </p>
								                    <p class="text-right"> <button name="button" class="btn btn-warning"  align="middle" id='enqMail_p'>Submit</button></p>
								                </div>
								            </div>								            
								        </div>
								        
								        <div class="tab-pane fade in" id="k" role="tabpanel" aria-labelledby="k-tab">
									        <div class="row">
									            <div class="col-md-12">
									                <p style="padding-top:15px;color:#000;min-height:100px;">
									                    <label><font size="5" color="#4682B4">Ask for Discounts</font></label><br>
									                    <br>
									                		 Full Name:<input name="fullname" placeholder="Full Name" class="form-control" type="text" required="required" id="name_k">
									                		 <br>
									                		  Company Name:<input  name="companyname" placeholder="Company Name" class="form-control" type="text" required="required" id="companyname_k">
									                		  <br>
									                		   Email<input type="email" name="email" class="form-control" placeholder="Email" required="required" id="email_k">
									                		   <br>
									                		    Country<select name="country" class="form-control" required="required" id="country_k">
									                                        <option value="" style="color:#888;">Country</option>
									                                        <option value="USA">USA</option> <option value="UK">UK</option>
									                                        <option value="CANADA">Canada</option> 
									                                        <option value="INDIA">India</option>  
									                                        <option value="PAKISTAN">Pakistan</option>
									                                        <option value="UAE">UAE</option> 
									                                        <optgroup label="- - - - - - - - - - - - - - - - -"></optgroup>
									                                        <option value="AUSTRALIA">Australia</option>
									                                        <option value="AUSTRIA">Austria</option>
									                                        <option value="BAHRAIN">Bahrain</option>
									                                        <option value="BANGLADESH">Bangladesh</option>
									                                        <option value="BELGIUM">Belgium</option>
									                                        <option value="Brazil">Brazil</option>
									                                        <option value="China">China</option>
									                                        <option value="Cuba">Cuba</option>
									                                        <option value="Cyprus">Cyprus</option>
									                                        <option value="Denmark">Denmark</option>
									                                        <option value="Fiji">Fiji</option>
									                                        <option value="Finland">Finland</option>
									                                        <option value="France">France</option>
									                                        <option value="Georgia">Georgia</option>
									                                        <option value="Germany">Germany</option>
									                                        <option value="Greece">Greece</option>
									                                        <option value="Hong Kong">Hong Kong</option>
									                                        
									                                      </select>
									                                      <br>
									                                     Mobile no.<input name="mobileno" placeholder="Mobile No." class="form-control" required="required" type="tel" id="tel_k">
									                                      <br>
									                                      Your Message <textarea name="comment" cols="40" rows="5" placeholder="Your Message"class="form-control" id="msg_k"></textarea>
									                                     <br>
									                	</p>
									                	<p class="text-right"> <button name="button" class="btn btn-warning"  align="middle" id='enqMail_k'>Submit</button></p>

									            </div>
									        </div>
								     	</div>
								    </div>
								</div>
							</div>

						</div>


						<div class="col-md-4">
							<div class="row form-group">
								<div class="card">
									<div class="row form-group">
										<article class="card-group-item">
											<header class="card-header">
												<h5 class="title absolute-title">PURCHASE OPTIONS</h5>
											</header>
											<div class="filter-content">
												<div class="card-body">
													<form class="col-md-12" action="<?php echo base_url('Website/checkout_process');?>" method="POST">	
														<div class="row form-group price-tag">										
															<label>
																<input type="radio" name="checkbox" value="<?php echo $reportInfo[0]['price'];?>" required>  

																    Single User 		
															</label>
															<span> <i class="fas fa-dollar-sign"></i> <?php echo number_format($reportInfo[0]['price'],2);?></span> 
														</div>

														<div class="row form-group price-tag">										
															<label>
																<input type="radio" name="checkbox" value="<?php echo $reportInfo[0]['project_pricemulti'];?>" required>  
																    Multi User			
															</label>
															<span> <i class="fas fa-dollar-sign"></i> <?php echo number_format($reportInfo[0]['project_pricemulti'],2);?></span>
														</div>

														<div class="row form-group  price-tag">										
															<label>
																<input type="radio" name="checkbox" value="<?php echo $reportInfo[0]['project_pricefive'];?>" required>  
																    Five User 									    				
															</label>
															<span> <i class="fas fa-dollar-sign"></i> <?php echo number_format($reportInfo[0]['project_pricefive'],2);?></span>	
														</div>

														<div class="row form-group  price-tag">										
															<label>
																<input type="radio" name="checkbox" value="<?php echo $reportInfo[0]['project_priceenterp'];?>" required>  
																    Enterprise User 
															</label>
															 <span> <i class="fas fa-dollar-sign"></i>  <?php echo number_format($reportInfo[0]['project_priceenterp'],2);?></span>
														</div>

														<div class="row">
															<div class="col-md-12 text-center">		
																<input type="hidden" name="reportID" value="<?php echo $reportInfo[0]['id'];?>">
																<input type="submit" class="btn btn-cus" value="Buy">
															</div>
														</div>
													</form>
												</div> <!-- card-body.// -->
											</div>
										</article> <!-- card-group-item.// -->									
									</div>									
								</div>
							</div>

							<div class="row form-group">
								<div class="card">

									<div class="row form-group">

										<article class="card-group-item">

											<header class="card-header">

												<h5 class="title absolute-title">KEY BENEFITS </h5>

											</header>

											<div class="filter-content">

												<div class="card-body">

												<form>

													<label class="form-check">

													  

													  <span class="form-check-label">

													 <b>  24 * 7 Access to Analyst</b> :

													  </span><br>

													  <p>Get your pre and post sales queries resolved by our Subject matter experts.</p><hr>

													</label> <!-- form-check.// -->

													<label class="form-check">

													  

													  <span class="form-check-label">

													   <b> Customization </b>:

													  </span><br>

													  <p>We will assist you to customize the report to fit your research needs.</p><hr>

													</label>  <!-- form-check.// -->

													<label class="form-check">

													  

													  <span class="form-check-label">

													  <b> Security </b>:

													  </span><br>

													  <p>Your personal and confidential information is safe and secured.</p><hr>

													</label> 

													

														<label class="form-check">

													  

													  <span class="form-check-label">

													  <b> Assured Quality  </b>:

													  </span><br>

													  <p>Our prime focus is to provide qualitative and accurate data.</p><hr>

													</label> 

													

													<label class="form-check">

													  

													  <span class="form-check-label">

													  <b> Free sample report  </b>:

													  </span><br>

													  <p>Feel free to order a sample report before purchase.</p><hr>

													</label> 

													

												</form>



												</div> <!-- card-body.// -->

											</div>

										</article> <!-- card-group-item.// -->
									
									</div>

									<div class="row form-group">	

										<article class="card-group-item">

											<header class="card-header">

												<h4 class="title absolute-title">Require Customization?? </h4>

											</header>

											<div class="filter-content">

												<div class="card-body">

													<label class="form-check">

													 

													  <span class="form-check-label">

													    Let us know your customized needs and our Subject matter experts will work directly with you to provide you with data as per your needs.

													  </span>

													</label>
												</div> 
											</div>
										</article>
									</div>
								</div>
							</div>

						</div>

					</div>
				</div>
			</div>
		</div>

<?php include('includedItems/footer.php');?>