<?php include('includedItems/headers.php');?>	

    <!-- BODY WORK START -->

        <?php include('includedItems/navigation.php');?>

        <?php include('includedItems/slides.php');?>

        <?php if(isset($dataSearch)){?>
                <div class="alert alert-success">
                    <h3>Success !!! report found</h3>
                </div>
        <?php }?>
        <div id="sr-data"></div>
        <section class="primiun-reporting">

        	<div class="container">

        		<div class="row form-group" style="margin-top:50px;">
        			<h2 class="heading text-center">
						<span class='black-heads'>Premium</span><span class="gold-head"> Reports</span>
					</h2>
        		</div>
        		
				<?php if(!empty($slideData)){?>
					<div class="slide-data">
					    <?php for($sd = 0; $sd <6; $sd++){?>
					        
					        <div class="main-div">
					        	<div class="row form-group">
							   		<div class="prime-div">
							   			<div class="row">
								   			<div class="div">
								   				<center>
								   					<img src="<?php echo base_url('assets/default_book.png');?>" class="img-responsive">
								   				</center>
								   			</div>

								   			<a href="<?php echo base_url('website/enquery/'.$slideData[$sd]['id']);?>" class="prime-link">


								   				<p><?php echo $slideData[$sd]['reportname'];?> </p>
								   			</a>
								   		</div>

								   		<div class="row">

							   				<h6><i class="fas fa-dollar-sign"></i> <?php echo $slideData[$sd]['price'];?></h6>

							   			</div>

							   		</div>

							   	</div>
						   		
						   </div>
						   
						   
					    <?php }
					    if(count($slideData)>5){?>
					    
					    <div class="row form-group">
					    	<div class="col-md-12 text-right">
					    		<!-- <a href="<?php echo base_url('Website/allReports');?>" class="btn btn-primary" title="More Reports" style="border-radius: 0px;">More Reports..</a> -->
					    		<button data-toggle="collapse" data-target="#demo" class="btn btn-primary" title="More Reports" onclick="demoShow()" id="setDemo">More Reports..</button>
					    	</div>
					    </div>

					<?php }?>

					    <div class="row form-group">
					    	<div id="demo" class="collapse">
					    		<div class="col-md-12">
					    			<?php for ($jk = 5;$jk<count($slideData);$jk++) {
					    					if($slideData[$jk]['status'] == 'Approve'){?>
						    					<div class="main-div">
										        	<div class="row form-group">
												   		<div class="prime-div">
												   			<div class="row">
													   			<div class="div">
													   				<center>
													   					<img src="<?php echo base_url('assets/default_book.png');?>" class="img-responsive">
													   				</center>
													   			</div>

													   			<a href="<?php echo base_url('website/enquery/'.$slideData[$jk]['id']);?>" class="prime-link">


													   				<p><?php echo $slideData[$jk]['reportname'];?> </p>
													   			</a>
													   		</div>

													   		<div class="row">
												   				<h6><i class="fas fa-dollar-sign"></i> <?php echo $slideData[$jk]['price'];?></h6>
												   			</div>
												   		</div>
												   	</div>										   		
											   </div>
					    			<?php 	}
					    				}
					    			?>
					    		</div>
					    	</div>
					    </div>
					    
					</div>
				<?php }else{?>
							<div class="col-md-4 col-md-offset-4">
								<div class="alert alert-warning">
								  <strong>Warning!</strong> <br/>No any Report Uploaded in Server.
								</div>
							</div>
				<?php }?>
        	</div>

        </section>

       



         <section class="testimonials">

        	<div class="container">

        		<div class="row">

        			<div class="col-md-12">

        				<h3 class="testimonials-heading">Our Client Says</h3>

        			</div>

        		</div>



        		<div class="row form-group">

        			<div class="col-md-12">

        				<div class="controls">

	        				<!-- Left and right controls -->

							<a class="left carousel-control" href="#testimonial" data-slide="prev">

							   <i class="fas fa-angle-left"></i>						   

							</a>

						    <a class="right carousel-control" href="#testimonial" data-slide="next">

							    <i class="fas fa-angle-right"></i>

							 </a>

						</div>

        			</div>

        		</div>

        		<div class="row">

        			<div id="testimonial" class="carousel slide" data-ride="carousel">						



					    <!-- Wrapper for slides -->

						<div class="carousel-inner">

						    <div class="item active">

						       <div class="row">

							       	<div class="col-md-4">

							       		<div class="packeg-div">

							       			<h3>Our customer's feedback </h3>

							       			<p>We appreciate your quick response to our queries and flexibility to personalise the report as per our needs. </p>

							       			<div class="client-info">

			                                    <h4>Marketing Director</h4>

			                                    <span>A leading Chemical Company </span>

			                                </div>

							       		</div>

							       	</div>

							       	<div class="col-md-4">

							       		<div class="packeg-div">

							       			<h3>Our customer's feedback </h3>

							       			<p>We appreciate your quick response to our queries and flexibility to personalise the report as per our needs. </p>

							       			<div class="client-info">

			                                    <h4>Marketing Director</h4>

			                                    <span>A leading Chemical Company </span>

			                                </div>

							       		</div>

							       	</div>



							       	<div class="col-md-4">

							       		<div class="packeg-div">

							       			<h3>Our customer's feedback </h3>

							       			<p>We appreciate your quick response to our queries and flexibility to personalise the report as per our needs. </p>

							       			<div class="client-info">

			                                    <h4>Marketing Director</h4>

			                                    <span>A leading Chemical Company </span>

			                                </div>

							       		</div>

							       	</div>

							    </div>							       	

						    </div>



						     <div class="item">

						    	 <div class="row">

							       	<div class="col-md-4">

							       		<div class="packeg-div">

							       			<h3>Our customer's feedback </h3>

							       			<p>We appreciate your quick response to our queries and flexibility to personalise the report as per our needs. </p>

							       			<div class="client-info">

			                                    <h4>Marketing Director</h4>

			                                    <span>A leading Chemical Company </span>

			                                </div>

							       		</div>

							       	</div>



							       	<div class="col-md-4">

							       		<div class="packeg-div">

							       			<h3>Our customer's feedback </h3>

							       			<p>We appreciate your quick response to our queries and flexibility to personalise the report as per our needs. </p>

							       			<div class="client-info">

			                                    <h4>Marketing Director</h4>

			                                    <span>A leading Chemical Company </span>

			                                </div>

							       		</div>

							       	</div>



							       	<div class="col-md-4">

							       		<div class="packeg-div">

							       			<h3>Our customer's feedback </h3>

							       			<p>We appreciate your quick response to our queries and flexibility to personalise the report as per our needs. </p>

							       			<div class="client-info">

			                                    <h4>Marketing Director</h4>

			                                    <span>A leading Chemical Company </span>

			                                </div>

							       		</div>

							       	</div>

						       </div>

						    </div>



						    <div class="item">

						      	 <div class="row">

							       	<div class="col-md-4">

							       		<div class="packeg-div">

							       			<h3>Our customer's feedback </h3>

							       			<p>We appreciate your quick response to our queries and flexibility to personalise the report as per our needs. </p>

							       			<div class="client-info">

			                                    <h4>Marketing Director</h4>

			                                    <span>A leading Chemical Company </span>

			                                </div>

							       		</div>

							       	</div>



							       <div class="col-md-4">

							       		<div class="packeg-div">

							       			<h3>Our customer's feedback </h3>

							       			<p>We appreciate your quick response to our queries and flexibility to personalise the report as per our needs. </p>

							       			<div class="client-info">

			                                    <h4>Marketing Director</h4>

			                                    <span>A leading Chemical Company </span>

			                                </div>

							       		</div>

							       	</div>



							       	<div class="col-md-4">

							       		<div class="packeg-div">

							       			<h3>Our customer's feedback </h3>

							       			<p>We appreciate your quick response to our queries and flexibility to personalise the report as per our needs. </p>

							       			<div class="client-info">

			                                    <h4>Marketing Director</h4>

			                                    <span>A leading Chemical Company </span>

			                                </div>

							       		</div>

							       	</div>

						       </div>

						    </div>

						</div> 					    

					</div>

        		</div>

        		

        	</div>

        </section>

	<!-- BODY WORK CLOSE -->

	<!-- Modal -->
<div id="myModalSuccesss" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Thank You</h4>
      </div>
      <div class="modal-body">
        <div class="row">
        	<div class="col-md-12">
        		<div class="text-center">
        			<img src="<?php echo base_url('vender\images/successgif.gif');?>">
        		</div>
        		<p>Thank You For Purchase Report With US. We Will contact You with in 24 hours.</p>
        	</div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

	<?php if(isset($success)){?>
		<script>
			$('#myModalSuccesss').modal('toggle');
		</script>
	<?php }?>

<?php include('includedItems/footer.php');?>

