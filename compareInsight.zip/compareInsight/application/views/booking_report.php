<?php include('includedItems/headers.php');?>

    <!-- BODY WORK START -->

        <?php include('includedItems/navigation.php');?>

        <?php //include('includedItems/slides.php');?>


        <style>
	        .btn{
	        	border-radius: 0px;
	        }

	        .display-box{
	        	border-radius: 0px;
	        	border-bottom: 3px solid #0a0adb;
				border-right: 1px solid blue;
	        }
            .img-box img,.profile-image img {
                width: auto;
                box-shadow: none !important;
                max-width: 100%;
                max-height: 142px;
            }
            .proile-tag{
                font-size: 12px !important;
                color: #f5c200 !important;
            }
            .research-bg-section{
                position:relative;
            }
            .headigs img{
                position: absolute;
                top: 0px;
                left: 47%;
                width: 70px;
                margin-top: 15px;
                background: #f0c422;
                border-radius: 50%;
                height: 70px;
                padding: 15px;
            }
            .checkboxes{
            	display: block;
            	text-align: left;
            }
            .checkboxes:hover{
            	text-decoration: none;
            }
            .blue-bg{            	
            	background:#f9f9f9;
            	padding: 20px 15px;
            }
            .reporting label{
            	font-size: 16px;
            	font-weight: 600;
            }
            .blue{
            	background-color: #022ed0;
				color: #eaeaea;
				line-height: 65px;
				font-size: 17px;
				font-weight: 100;
            }
            .img-box img{
				width: 100%;
			}
			.img-box{
				width: 100%;
				padding-right: 10px;
			}

			.img-box p{
				font-size: 10px;
				line-height: 12px;
				margin-top: 10px;
				color: #fff;
			}
			.btn-info {
			    color: #fff;
			    background-color: #022ed0;
			    border-color: #022ed0;
			}
			.btn-info:hover {
			    color: #7171f7;
			    background-color: #fff;
			    border-color: #0a0adb;
			}
			.total-res{
				background: #022ed0;
				padding: 15px 15px;
				text-align: right;
				font-weight: 600;
				font-size: 18px;				
				border: 3px solid #022ed0;
				color: #fff;
			}

			.science h3 {
			    margin-top: 0px;
			    color: #ff0702;
			    font-weight: 900;
			    line-height: 35px;
			}
			
        </style>
        <div class="container-fluid">

        	<div class="row">

        		<div class="research-bg-section">

        			<div class="headigs">        			    
                        <h3 class="testimonials-heading">CheckOut Process</h3>
        			</div>

        		</div>

        	</div>

        </div>


<?php if(isset($buyItem)){
		if($module== $buyItem[0]['price']){
			$modePrice = $module;
			$modeName  = 'Single User';
		}elseif($module== $buyItem[0]['project_pricemulti']){
			$modePrice = $module;
			$modeName  = 'Multi User';
		}elseif($module== $buyItem[0]['project_pricefive']){
			$modePrice = $module;
			$modeName  = 'Five User';
		}elseif($module== $buyItem[0]['project_priceenterp']){
			$modePrice = $module;
			$modeName  = 'EnterPrice User';
		}
	}

	if(isset($buyItems)){
		foreach($buyItems as $item){
			if($module== $item['price']){
				$modePrice = $module;
				$modeName  = 'Single User';
			}elseif($module== $item['project_pricemulti']){
				$modePrice = $module;
				$modeName  = 'Multi User';
			}elseif($module== $item['project_pricefive']){
				$modePrice = $module;
				$modeName  = 'Five User';
			}elseif($module== $item['project_priceenterp']){
				$modePrice = $module;
				$modeName  = 'EnterPrice User';
			}
		}
	}


?>


        <div class="container">
        	
			<div class="row">

				<div class="col-md-12 science" style="">

					<div class="row form-group">

						<div class="col-md-4">

							<div class="row form-group hide-media">

								<div class="card">

									<div class="row form-group">

										<article class="card-group-item">

											<header class="card-header">

												<h5 class="title absolute-title">Billing Information </h5>

											</header>

											<div class="filter-content">

												<div style="border-left: 1px solid lightgray;">

													<form class="form-horizontal" method="post" action="<?php echo base_url();?>index.php/website/transaction" style="margin-bottom: 30px;">
			                                            <div class="panel">
			                                                <!-- <div class="panel-heading">Address</div> -->
			                                                <div class="panel-body">
			                                                    <div class="form-group">
			                                                        <div class="col-md-12">
			                                                            <h4>Shipping Address</h4>
			                                                        </div>
			                                                    </div>
			                                                    
			                                                    <div class="form-group">
			                                                        <div class="col-md-6 col-xs-12">
			                                                            <strong>First Name:</strong>
			                                                            <input type="text" name="first_name" class="form-control" value="" / required>
			                                                        </div>
			                                                        <div class="span1"></div>
			                                                        <div class="col-md-6 col-xs-12">
			                                                            <strong>Last Name:</strong>
			                                                            <input type="text" name="last_name" class="form-control" value="" / required>
			                                                        </div>
			                                                    </div>
			                                                    <div class="form-group">
			                                                        <div class="col-md-12"><strong>Address:</strong></div>
			                                                        <div class="col-md-12">
			                                                            <input type="text" name="address" class="form-control" value="" / required>
			                                                        </div>
			                                                    </div>
			                                                    <div class="form-group">
			                                                        <div class="col-md-12"><strong>City:</strong></div>
			                                                        <div class="col-md-12">
			                                                            <input type="text" name="city" class="form-control" value="" / required>
			                                                        </div>
			                                                    </div>
			                                                    <div class="form-group">
			                                                        <div class="col-md-12"><strong>State:</strong></div>
			                                                        <div class="col-md-12">
			                                                            <input type="text" name="state" class="form-control" value="" / required>
			                                                        </div>
			                                                    </div>

			                                                    <div class="form-group">
			                                                        <div class="col-md-12"><strong>Country:</strong></div>
			                                                        <div class="col-md-12">                                          
			                                                            <select name="country" class="form-control" required="required" id="country_k">
									                                        <option value="" style="color:#888;">Country</option>
									                                        <option value="USA">USA</option> <option value="UK">UK</option>
									                                        <option value="CANADA">Canada</option> 
									                                        <option value="INDIA">India</option>  
									                                        <option value="PAKISTAN">Pakistan</option>
									                                        <option value="UAE">UAE</option> 
									                                        <optgroup label="- - - - - - - - - - - - - - - - -"></optgroup>
									                                        <option value="AUSTRALIA">Australia</option>
									                                        <option value="AUSTRIA">Austria</option>
									                                        <option value="BAHRAIN">Bahrain</option>
									                                        <option value="BANGLADESH">Bangladesh</option>
									                                        <option value="BELGIUM">Belgium</option>
									                                        <option value="Brazil">Brazil</option>
									                                        <option value="China">China</option>
									                                        <option value="Cuba">Cuba</option>
									                                        <option value="Cyprus">Cyprus</option>
									                                        <option value="Denmark">Denmark</option>
									                                        <option value="Fiji">Fiji</option>
									                                        <option value="Finland">Finland</option>
									                                        <option value="France">France</option>
									                                        <option value="Georgia">Georgia</option>
									                                        <option value="Germany">Germany</option>
									                                        <option value="Greece">Greece</option>
									                                        <option value="Hong Kong">Hong Kong</option>
									                                        
									                                      </select>
			                                                        </div>
			                                                    </div>

			                                                    <div class="form-group">
			                                                        <div class="col-md-12"><strong>Zip / Postal Code:</strong></div>
			                                                        <div class="col-md-12">
			                                                            <input type="text" name="zip_code" class="form-control" value="" / required placeholder="111111" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
			                                                        </div>
			                                                    </div>
			                                                    <div class="form-group">
			                                                        <div class="col-md-12"><strong>Phone Number:</strong></div>
			                                                        <div class="col-md-12"><input type="text" name="phone_number" class="form-control" value="" / required oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="15" placeholder="0091 9999999999"></div>
			                                                    </div>
			                                                    <div class="form-group">
			                                                        <div class="col-md-12"><strong>Email Address:</strong></div>
			                                                        <div class="col-md-12"><input type="email" name="email_address" class="form-control" value="" / required></div>
			                                                    </div>
			                                                    
			                                                </div>
			                                            </div>
			                                        <?php if(isset($buyItem)){?>
			                                            <input type="hidden" name="price" value="<?php echo $modePrice;?>" id="forData">
			                                            <input type="hidden" name="reportName" value="<?php echo $buyItem[0]['reportname'];?>">
			                                             <input type="hidden" name="reportType" value="<?php echo $modeName;?>">
			                                            <input type="hidden" name="reportId" value="<?php echo $buyItem[0]['id'];?>">

			                                        <?php }?>

			                                        <?php if(isset($buyItems)){?>
			                                        	 <input type="hidden" name="price" value="<?php echo $modePrice;?>" id="forData">
			                                        	  <input type="hidden" name="reportType" value="<?php echo $modeName;?>">
			                                        <?php	foreach($buyItems as $input){
			                                        ?>
					                                           
					                                            <input type="hidden" name="reportName[]" value="<?php echo $input['reportname'];?>">
					                                            
					                                            <input type="hidden" name="reportId[]" value="<?php echo $input['id'];?>">

			                                        <?php 	}
			                                        	}
			                                        ?>
			                                            
			                                            <!--CREDIT CART PAYMENT END-->
			                                            <div class="col-md-12 text-right">
			                                                <button type="submit" class ="btn btn-info" name="submit">Proceed To Pay</button>
			                                            </div>
			                                         
			                                        </form>

												</div> <!-- card-body.// -->

											</div>

										</article> <!-- card-group-item.// -->
									
									</div>
								</div>
							</div>


							
						</div><!-- COL_MD_4 -->
					
						<div class="col-md-8">
							<?php if(isset($buyItem)){?>

								<div class="display-box" style="padding-bottom: 0px; padding-top:0px;">	
									<div class="row blue">
										<div class="col-md-12">
											<label>Order Summary </label>
										</div>
									</div>

								
									<div class="row" id="reports">
										<div class="col-md-3">
											<div class="img-box text-center">
												<?php if ($buyItem[0]['category'] =="4"){?>
						                                <img src="<?php echo base_url('vender\images\book/industries.png');?>" alt="Industrial Automation" class="himg" >
												<?php }else if($buyItem[0]['category'] =="78"){?>
														<img src="<?php echo base_url('vender\images\book/medicine.png');?>" alt="sports" class="himg" >
												<?php }else if($buyItem[0]['category'] =="3"){?>
														<img src="<?php echo base_url('vender\images\book/food.png');?>" alt="Food & Beverage" class="himg" >
												<?php }else if($buyItem[0]['category'] =="76"){?>
														<img src="<?php echo base_url();?>vender\images\book/chemistry.png" alt="Chemicals & Materials" class="himg" >
												<?php }else if($buyItem[0]['category'] =="75"){?>
														<img src="<?php echo base_url('vender\images\book/transport.png');?>" alt="Automotive & Transportation" class="himg" >
												<?php }else if($buyItem[0]['category'] =="1"){?>
														<img src="<?php echo base_url('vender\images\book/electronic.png');?>" alt="Electronics & Semiconductor" class="himg" >
												<?php }else if($buyItem[0]['category'] =="77"){?>
														<img src="<?php echo base_url('vender\images\book/medicine.png');?>" alt="Healthcare, Pharmaceuticals & Medical Devices" class="himg" >
												<?php }else if($buyItem[0]['category'] =="2"){?>
														<img src="<?php echo base_url('vender\images\book/retail.png');?>" alt="Retail & Consumer Goods" class="himg" >
												<?php }else if($buyItem[0]['category'] =="79"){?>
														<img src="<?php echo base_url('vender\images\book/defencce.png');?>" alt="Aerospace and Defense" class="himg" >
												<?php }else if($buyItem[0]['category'] =="80"){?>
														<img src="<?php echo base_url('vender\images\book/constuction.png');?>" alt="Building, Construction Manufacturing" class="himg" >
												<?php }?>
											</div>
										</div>

										<div class="col-md-9">
											<div class="row form-group">
												<div class="heading-box">
													<a href="<?php echo base_url('website/report_info/'.$buyItem[0]["id"]);?>">
														<h3><?php echo $buyItem[0]['reportname'];?></h3>	
													</a>	
												</div>
											</div>
										</div>
									</div>
									<div class="row" style="padding: 0;">
								
											<div class="blue-bg">
												<div class="row">
													<div class="col-md-6">
														<h4 style="line-height: 80px;font-weight: 900; text-align: center;">Report Cost And Licence Type</h4>
													</div>

													
													<div class="col-md-6 reporting">
														<div class="row">
															<div class="col-sm-6">
																<label>
																	Licence Name
																</label>
															</div>
															<div class="col-sm-6 text-right">
																<label><?php echo $modeName;?></label>
															</div>
														</div>

														<div class="row">
															<div class="col-sm-6">
																<label>
																	Licence Name
																</label>
															</div>
															<div class="col-sm-6 text-right">
																<label><i class="fas fa-dollar-sign"></i> <?php echo number_format($modePrice,2);?></label>
															</div>
														</div>

														<div class="row">
															<div class="col-sm-6">
																<label>Total Price </label>
															</div>

															<div class="col-sm-6 text-right">
																<label><i class="fas fa-dollar-sign"></i> <?php echo number_format($modePrice,2);?></label>
															</div>
														</div>

													</div>
												</div>
											</div>
								
									</div>
								</div>	
							<?php }
									if(isset($buyItems)){
										foreach($buyItems as $item){
							?>
										
											<div class="display-box" style="padding-bottom: 0px; padding-top:0px;">	
												<div class="row blue">
													<div class="col-md-12">
														<label>Order Summary </label>
													</div>
												</div>

											
												<div class="row" id="reports">
													<div class="col-md-3">
														<div class="img-box text-center">
															<?php if ($item['category'] =="4"){?>
									                                <img src="<?php echo base_url('vender\images\book/industries.png');?>" alt="Industrial Automation" class="himg" >
															<?php }else if($item['category'] =="78"){?>
																	<img src="<?php echo base_url('vender\images\book/medicine.png');?>" alt="sports" class="himg" >
															<?php }else if($item['category'] =="3"){?>
																	<img src="<?php echo base_url('vender\images\book/food.png');?>" alt="Food & Beverage" class="himg" >
															<?php }else if($item['category'] =="76"){?>
																	<img src="<?php echo base_url();?>vender\images\book/chemistry.png" alt="Chemicals & Materials" class="himg" >
															<?php }else if($item['category'] =="75"){?>
																	<img src="<?php echo base_url('vender\images\book/transport.png');?>" alt="Automotive & Transportation" class="himg" >
															<?php }else if($item['category'] =="1"){?>
																	<img src="<?php echo base_url('vender\images\book/electronic.png');?>" alt="Electronics & Semiconductor" class="himg" >
															<?php }else if($item['category'] =="77"){?>
																	<img src="<?php echo base_url('vender\images\book/medicine.png');?>" alt="Healthcare, Pharmaceuticals & Medical Devices" class="himg" >
															<?php }else if($item['category'] =="2"){?>
																	<img src="<?php echo base_url('vender\images\book/retail.png');?>" alt="Retail & Consumer Goods" class="himg" >
															<?php }else if($item['category'] =="79"){?>
																	<img src="<?php echo base_url('vender\images\book/defencce.png');?>" alt="Aerospace and Defense" class="himg" >
															<?php }else if($item['category'] =="80"){?>
																	<img src="<?php echo base_url('vender\images\book/constuction.png');?>" alt="Building, Construction Manufacturing" class="himg" >
															<?php }?>
														</div>
													</div>

													<div class="col-md-9">
														<div class="row form-group">
															<div class="heading-box">
																<a href="<?php echo base_url('website/report_info/'.$item["id"]);?>">
																	<h3><?php echo $item['reportname'];?></h3>	
																</a>	
															</div>
														</div>
													</div>
												</div>
												<div class="row" style="padding: 0;">
											
														<div class="blue-bg">
															<div class="row">
																<div class="col-md-6">
																	<h4 style="line-height: 80px;font-weight: 900; text-align: center;">Report Cost And Licence Type</h4>
																</div>

																
																<div class="col-md-6 reporting">
																	<div class="row">
																		<div class="col-sm-6">
																			<label>
																				Licence Name
																			</label>
																		</div>
																		<div class="col-sm-6 text-right">
																			<label>
																				<?php   
																						echo $modeName;
																				?>
																					
																				</label>
																		</div>
																	</div>

																	<div class="row">
																		<div class="col-sm-6">
																			<label>
																				<b>Licence Price</b>
																			</label>
																		</div>
																		<div class="col-sm-6 text-right">
																			<label><i class="fas fa-dollar-sign"></i> <?php echo number_format($modePrice,2);?></label>
																		</div>
																	</div>

																	<!-- <div class="row">
																		<div class="col-sm-6">
																			<label><b>Total Price</b></label>
																		</div>

																		<div class="col-sm-6 text-right">
																			<label><i class="fas fa-dollar-sign"></i> <?php //echo number_format($modePrice,2);?></label>
																		</div>
																	</div> -->

																</div>
															</div>
														</div>
											
												</div>
											</div>
							<?php		}
									}
							?>

							<?php if(isset($cartItem)){
									$i=1;
									foreach ($cartItem as $value) {?>
										<div class="display-box" style="padding-bottom: 0px; padding-top:0px;">	
											<div class="row blue">
												<div class="col-md-12">
													<label>Cart Summary <?php echo $i;?> </label>
												</div>
											</div>

											<div class="row" id="reports">
												<div class="col-md-3">
													<div class="img-box text-center">

														<?php if ($value['category'] =="4"){?>
									                                <img src="<?php echo base_url('vender\images\book/industries.png');?>" alt="Industrial Automation" class="himg" >
															<?php }else if($value['category'] =="78"){?>
																	<img src="<?php echo base_url('vender\images\book/medicine.png');?>" alt="sports" class="himg" >
															<?php }else if($value['category'] =="3"){?>
																	<img src="<?php echo base_url('vender\images\book/food.png');?>" alt="Food & Beverage" class="himg" >
															<?php }else if($value['category'] =="76"){?>
																	<img src="<?php echo base_url();?>vender\images\book/chemistry.png" alt="Chemicals & Materials" class="himg" >
															<?php }else if($value['category'] =="75"){?>
																	<img src="<?php echo base_url('vender\images\book/transport.png');?>" alt="Automotive & Transportation" class="himg" >
															<?php }else if($value['category'] =="1"){?>
																	<img src="<?php echo base_url('vender\images\book/electronic.png');?>" alt="Electronics & Semiconductor" class="himg" >
															<?php }else if($value['category'] =="77"){?>
																	<img src="<?php echo base_url('vender\images\book/medicine.png');?>" alt="Healthcare, Pharmaceuticals & Medical Devices" class="himg" >
															<?php }else if($value['category'] =="2"){?>
																	<img src="<?php echo base_url('vender\images\book/retail.png');?>" alt="Retail & Consumer Goods" class="himg" >
															<?php }else if($value['category'] =="79"){?>
																	<img src="<?php echo base_url('vender\images\book/defencce.png');?>" alt="Aerospace and Defense" class="himg" >
															<?php }else if($value['category'] =="80"){?>
																	<img src="<?php echo base_url('vender\images\book/constuction.png');?>" alt="Building, Construction Manufacturing" class="himg" >
															<?php }?>

			                                            
													</div>
												</div>

												<div class="col-md-9">
													<div class="row form-group">
														<div class="heading-box">
															<?php echo $value['reportname'];?>										
														</div>
													</div>
												</div>
											</div>
											<div class="row" style="padding: 0;">									
												<div class="blue-bg">
													<div class="row">
														<div class="col-md-6">
															<h4 style="line-height: 80px;font-weight: 900; text-align: center;">Report Cost And Licence Type</h4>
														</div>

														
														<div class="col-md-6 reporting">
															<div class="row">
																<div class="col-sm-6">
																	<label>
																		Licence Name
																	</label>
																</div>
																<div class="col-sm-6 text-right">
																	<label><?php echo $value['reportType'];?></label>
																</div>
															</div>

															<div class="row">
																<div class="col-sm-6">
																	<label>
																		Licence Name
																	</label>
																</div>
																<div class="col-sm-6 text-right">
																	<label><i class="fas fa-dollar-sign"></i> <?php echo number_format($value['reportPrice'],2);?></label>
																</div>
															</div>

															<div class="row">
																<div class="col-sm-6">
																	<label>Total Price </label>
																</div>

																<div class="col-sm-6 text-right">
																	<label><i class="fas fa-dollar-sign"></i> <?php echo number_format($value['reportPrice'],2);?></label>
																</div>
															</div>

															<?php $total = array(); array_push($total,$value['reportPrice']);?>

														</div>
													</div>
												</div>								
											</div>
										</div>	
								<?php $i++;}									
								}?>		
							<?php if(isset($cartItem)){?>
								<div class="col-md-12">									
									<div class="total-res">
										<label>Total Payout = <i class="fas fa-dollar-sign"></i> <?php echo number_format(array_sum($total),2);?></label>
									</div>
								</div>	
							<?php }?>				
						</div><!-- COL_MD_8 CLOSED -->
					</div>
		     	</div>
		    </div>
		</div>

    <!-- BODY CLOSE -->

<?php include('includedItems/footer.php');?>