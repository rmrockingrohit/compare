<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<style>table{
    width:100%;
}
#example_filter{
    float:right;
}
#example_paginate{
    float:right;
}
label {
    display: inline-flex;
    margin-bottom: .5rem;
    margin-top: .5rem;
   
}
</style> 
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.10.18/datatables.min.css"/>
 
<script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.10.18/datatables.min.js"></script>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       <?php if(isset($report)){?>Manage Report<?php }else{?>View Reports<?php }?>
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title"> <?php if(isset($report)){?>Manage Report<?php }else{?>View Reports<?php }?></h3>
                <div class="clearfix" style="padding:10px;"></div>
                 <?php if($this->session->flashdata("success")){?>
                <div class="alert alert-success">
                  <?php echo $this->session->flashdata("success"); ?>
                  </div>  
          <?php  }?>
          <?php if($this->session->flashdata("error")){?>
                <div class="alert alert-danger">
                  <?php echo $this->session->flashdata("error"); ?>
                  </div>
          <?php  }?>
              <div class="box-tools">
                <?php if(isset($report)){?>
                <a href='<?php echo base_url(); ?>index.php/admin/report/addreport' class="btn btn-primary pull-left" style='margin-right: 10px;margin-bottom:5px;'>Add Report</a>
                <?php }?>
                <!-- <div class="input-group input-group-sm" style="width: 150px;">
                  <input type="text" name="table_search" class="form-control pull-right" placeholder="Search">
                  <div class="input-group-btn">
                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                  </div>
                </div> -->
                
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
                <?php if(isset($report)){?>
              <table id="example" class="table table-striped table-bordered" style="width:100%">
                    <thead>
                        <tr>
                            <!-- <th><input type="checkbox" onclick="checkAll(this)"></th> -->
                           <th>Report Id </th>
                              <th>Report Title </th>
                              <th>Report Description</th>
                              <th>Report Doc</th>
                              <th>Category</th>
                              <th>Price</th>
                              <th>Publisher Date</th>
                              <th>Status</th>
                              <th>Correction</th>
                              <th>Action</th>      
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($report as $allportfolio){
                            $style = '';
                            if($allportfolio['status'] == 'Approve'){
                                $style = "style='background: #53d053;padding: 6px;color: #fff;vertical-align: -webkit-baseline-middle;'";
                            }elseif($allportfolio['status'] == 'Inprogress'){
                                $style = "style='background: orange;padding: 6px;color: #fff;vertical-align: -webkit-baseline-middle;'";
                            }elseif($allportfolio['status'] == 'Unapproved'){
                                $style = "style='background: #ec7575;padding: 6px;color: #fff;vertical-align: -webkit-baseline-middle;'";
                            }?>
                            <tr>
                              <!-- <td><input type="checkbox" onclick="checkAll(this)"></td> -->
                              <td><?php echo $allportfolio["id"] ; ?></td>
                              <td><?php echo $allportfolio["reportname"] ; ?></td>
                              <td> <?php echo substr($allportfolio["reportdesc"],1,50)."..."; ?></td>
                              <td><a target="_blank" style="width:300px ; height:300px ; " href="<?php echo base_url();?>report_uploads/<?php echo $allportfolio["reportdoc"] ; ?>" /><?php echo $allportfolio['reportname']?></a></td>
                              <td><?php echo $allportfolio["title"] ; ?></td>
                              <td><?php echo $allportfolio["price"] ; ?></td>
                              <td><?php echo $allportfolio["publisher_date"] ; ?></td>
                              <td ><span <?php echo $style;?>><?php echo $allportfolio["status"] ; ?></td>
                              <td><?php echo $allportfolio["report_corr"] ; ?></td>
                            <td>                    
                              <a href="<?php echo base_url();?>index.php/admin/report/update/<?php echo $allportfolio["id"] ; ?>" > Edit</a> | 
                              <a href="<?php echo base_url();?>index.php/admin/report/delete/<?php echo $allportfolio["id"] ; ?>" > Delete</a> |
                              <?php if($this->session->userdata('adminType') == 'admin') {
                                        if($allportfolio['status'] == 'Approve'){
                                            $active = 'class = "btn btn-success"';
                                              echo '<a '.$active.'><i class="fa fa-check"></i> Approved</a>';
                                        }elseif($allportfolio['status'] == 'Inprogress'){
                                           $active = 'class = "btn btn-warning"';
                                            echo '<a '.$active.' href="'.base_url().'index.php/admin/report/approve/'.$allportfolio["id"].'"> Approve</a>';
                                        }elseif($allportfolio['status'] == 'Unapproved'){
                                           $active = 'class = "btn btn-danger"';
                                            echo '<a '.$active.' href="'.base_url().'index.php/admin/report/approve/'.$allportfolio["id"].'"> Approve</a>';
                                        }?>
                                <a href="<?php echo base_url();?>index.php/admin/report/correction/<?php echo $allportfolio["id"] ; ?>"> Correction</a>|
                               <?php }?>
                                  <!--<a href="<?php //echo base_url();?>index.php/admin/report/Send_Mail/<?php echo $allportfolio["id"] ; ?>" > email</a> |--> 
                            </td>             
                          </tr>
                            
                 <?php
                             }?>
                    </tbody>   
                   
                </table>
                <?php }else{?>
                <form action="<?php echo base_url().'index.php/admin/Viewreport/getReport';?>" method="POST">
                    <div class="col-md-4">
                        <div class="row form-group">
                            <div class="col-md-12">
                                <p><label>Report Type</label></p>
                                <select class="form-control" id="select" name="report">
                                    <option value="all">All Report</option>
                                    <option value="Approve">Approved Report</option>
                                    <option value="Inprogress">New Report</option>
                                    <option value="Unapproved">Un-Approved Report</option>
                                    <?php if($this->session->userdata("adminType") == 'admin'){?>
                                        <option value="venderType">Vender Type Report</option>
                                    <?php }?>
                                </select>
                                <?php echo form_error('report', '<div class="error">', '</div>'); ?>
                            </div>
                        </div>
                    </div>
                    <?php if($this->session->userdata("adminType") == 'admin'){?>
                    <div class="col-md-4">
                        
                        <div class="row form-group">
                            <div class="col-md-12">
                                <p><label>Vender Name</label></p>
                                <input type="text" name="vender" id="vender" class="form-control" disabled>
                                <?php echo form_error('vender', '<div class="error">', '</div>'); ?>
                            </div>
                        </div>
                        
                    </div>
                    <?php }?>
                    <div class="col-md-4">
                        <div class="row form-group text-left">
                            <p><label>Search</label></p>
                            <input type="submit" class="btn btn-success" value="Search" >
                        </div>
                    </div>
                </div>
            </form>
            
            <?php if(isset($getreport) && (!empty($getreport))){?>
                <table id="example" class="table table-striped table-bordered" style="width:100%">
                    <thead>
                        <tr>
                            <!-- <th><input type="checkbox" onclick="checkAll(this)"></th> -->
                           <th>Report Id </th>
                              <th>Report Title </th>
                              <th>Report Description</th>
                              <th>Report Doc</th>
                              <th>Category</th>
                              <th>Price</th>
                              <th>Publisher Date</th>
                              <th>Status</th>
                              <th>Correction</th>
                              <th>Action</th>      
                        </tr>
                    </thead>
                    <tbody>
                        <?php  foreach ($getreport as $allportfolio){
                                    $style = '';
                                    if($allportfolio['status'] == 'Approve'){
                                        $style = "style='background: #53d053;padding: 6px;color: #fff;vertical-align: -webkit-baseline-middle;'";
                                    }elseif($allportfolio['status'] == 'Inprogress'){
                                        $style = "style='background: orange;padding: 6px;color: #fff;vertical-align: -webkit-baseline-middle;'";
                                    }elseif($allportfolio['status'] == 'Unapproved'){
                                        $style = "style='background: #ec7575;padding: 6px;color: #fff;vertical-align: -webkit-baseline-middle;'";
                                    }
                        ?>
                                    <tr>
                                          <!-- <td><input type="checkbox" onclick="checkAll(this)"></td> -->
                                          <td><?php echo $allportfolio["id"] ; ?></td>
                                          <td><?php echo $allportfolio["reportname"] ; ?></td>
                                          <td> <?php echo substr($allportfolio["reportdesc"],1,50)."..."; ?></td>
                                          <td><a target="_blank" style="width:300px ; height:300px ; " href="<?php echo base_url();?>report_uploads/<?php echo $allportfolio["reportdoc"] ; ?>" /><?php echo $allportfolio['reportname']?></a></td>
                                          <td><?php echo $allportfolio["title"] ; ?></td>
                                          <td><?php echo $allportfolio["price"] ; ?></td>
                                          <td><?php echo $allportfolio["publisher_date"] ; ?></td>
                                          <td ><span <?php echo $style;?>><?php echo $allportfolio["status"] ; ?></td>
                                          <td><?php echo $allportfolio["report_corr"] ; ?></td>
                                        <td>                    
                                            <a href="<?php echo base_url();?>index.php/admin/report/update/<?php echo $allportfolio["id"] ; ?>" > Edit</a> | 
                                            <a href="<?php echo base_url();?>index.php/admin/report/delete/<?php echo $allportfolio["id"] ; ?>" > Delete</a> |
                                            <?php if($this->session->userdata('adminType') == 'admin') {
                                                    if($allportfolio['status'] == 'Approve'){
                                                        $active = 'class = "btn btn-success"';
                                                          echo '<a '.$active.'><i class="fa fa-check"></i> Approved</a>';
                                                    }elseif($allportfolio['status'] == 'Inprogress'){
                                                       $active = 'class = "btn btn-warning"';
                                                        echo '<a '.$active.' href="'.base_url().'index.php/admin/report/approve/'.$allportfolio["id"].'"> Approve</a>';
                                                    }elseif($allportfolio['status'] == 'Unapproved'){
                                                       $active = 'class = "btn btn-danger"';
                                                        echo '<a '.$active.' href="'.base_url().'index.php/admin/report/approve/'.$allportfolio["id"].'"> Approve</a>';
                                                    }
                                            ?>
                                            <a href="<?php echo base_url();?>index.php/admin/report/correction/<?php echo $allportfolio["id"] ; ?>"> Correction</a>|
                                           <?php }?>
                                              <!--<a href="<?php //echo base_url();?>index.php/admin/report/Send_Mail/<?php //echo $allportfolio["id"] ; ?>" > email</a> |--> 
                                        </td>             
                                  </tr>
                            <?php }?>
                    </tbody>
                </table>
            <?php }}?>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>
      </section>
      </div>
      <script >$(document).ready(function() {
    $('#example').DataTable({
        "aLengthMenu": [[5, 10, 25, -1], [5, 10, 25, "All"]],
        "iDisplayLength": 5
       } 
        );
} );

$("#select").on('change',function(){
    var select = $(this).val();

    if(select == 'venderType'){
        $("#vender").removeAttr('disabled','true')
    }
})


function checkAll(bx) {
  var cbs = document.getElementsByTagName('input');
  for(var i=0; i < cbs.length; i++) {
    if(cbs[i].type == 'checkbox') {
      cbs[i].checked = bx.checked;
    }
  }
}</script>