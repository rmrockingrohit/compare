<style type="text/css">
  .upload-panel{
    margin: 50px auto;
    width: 80%;
    border: 1px dotted #337ab7;
    padding: 53px;
    border-radius: 10px;
  }
  .upload-hidden{
    width: 130px;
    z-index: 99999999;
    position: relative;
    left: 70px;
    height: 35px;
    opacity: 0;
    cursor: pointer;
    top: -15px;
  }
  .upload-btn{
    position: relative;
    top: 20px;
    left: 70px;
    width: 130px;
    z-index: 9;
  }
  .progress-bar-div{
    display: none;
  }
  .progress{
    width: 300px;
    margin: 0 auto;
  }
  .error-msg{
    color: #e24a4a;
    width: 100%;
    text-align: center;
  }
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1> Add Report In Bulk </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title"> Add Report In Bulk</h3>
            </div>

            <div class="box-body">
              <div class="form-group">
                
                <div class="panel-group">
                  <div class="panel panel-info">
                    <div class="panel-heading">Bulk Report Upload Rules</div>
                    <div class="panel-body">
                      <ul>
                        <li>1 - Please Ensure That All Field Are Filled Peroperly.</li>
                        <li>2- Category Shuld be filled by there ID. For Know Your Category ID Download Category List In Given Download.</li>
                      </ul>

                      <div class="col-md-12">
                        <div class="row form-group">
                          <div class="col-md-3"></div>
                          <div class="col-md-3">
                            <div class="row form-group">
                              <a href="<?php echo base_url('assets/Bulk_Report.xlsx');?>" class="btn btn-success" download><i class="fa fa-download"></i> Download Bulk Sheet</a>
                            </div>
                          </div>
                          <div class="col-md-3">
                            <div class="row form-group">
                              <a href="<?php echo base_url('index.php/admin/Report/getExcelSheetForCategoryList');?>" class="btn btn-info" ><i class="fa fa-download"></i> Download Category List</a>
                            </div>
                          </div>
                          <div class="col-md-3"></div>
                        </div>
                      </div>                      
                    </div>
                  </div>
                </div>

              </div>

              <div class="form-group">
                <div class="panel panel-primary">
                  <div class="panel-heading"> Upload Bulk Report</div>
                  <div class="panel-body">

                    <div class="upload-panel">
                      <div class="row">
                        <div class="col-md-4 col-md-offset-4">
                          <form enctype="multipart/form-data" method="POST" id="form" action="<?php echo base_url('index.php/admin/Report/uploadBulkData');?>">
                            <a class="btn btn-primary upload-btn" title="Upload xlsx File"> Upload File</a>
                            <input type="file" name="bulk" accept=".xlsx" class="upload-hidden">
                          </form>
                        </div>
                      </div>
                    </div>

                    <div class="error-msg"></div>

                    <div class="progress-bar-div">
                      <div class="progress">
                        <div class="progress-bar progress-bar-striped active" role="progressbar"
                        aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width:10%">
                         10%
                        </div>
                      </div>
                    </div>

                  </div>
                </div>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>

</div>

<script type="text/javascript">
  $(function(){
    $(".upload-hidden").on("change",function(){
      
         var file_size = (this).files[0].size;
         if(file_size>8530){
          //var uploadData = new FormData("#form");
            $(".error-msg").fadeOut(800);
            //$('.progress-bar-div').fadeIn(600);
            $(".upload-hidden").css('z-index','0');
            $("#form").submit();
          }else{
            $(".error-msg").fadeIn(function(){
              $(this).text('Minimum File Size Found.System Track Empty Upload. Please Upload Filled Data File.');
            })
          }
    })
  })
 
$('#form').submit(function() { // catch the form's submit event
    var file_data = $('#bulk').prop('files')[0];   
    var form_data = new FormData();  
    form_data.append('file', file_data);
    $.ajax({ // create an AJAX call...
        //data: $(this).serialize(), // get the form data
        dataType: 'text',
        type: $(this).attr('method'), // GET or POST
        url: $(this).attr('action'), // the file to call
        cache: false,
        contentType: false,
        processData: false,
        success: function(response) { // on success..
            //$('#created').html(response); // update the DIV
            alert(response);
        }
    });
    return false; // cancel original event to prevent form submitting
});
</script>