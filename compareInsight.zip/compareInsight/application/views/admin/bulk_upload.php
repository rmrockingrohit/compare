<style type="text/css">
  .label_title{
    padding: 0px 15px 10px;
    border-bottom: 1px dotted #ffdb99;
    width: 100%;
    color: #39a1d0;
  }
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1> Add Report In Bulk </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title"> Add Report In Bulk</h3>
            </div>

            <div class="box-body">
              <form action="<?php echo base_url('index.php/admin/Report/uploadFileBulk');?>" method="POST" enctype="multipart/form-data">
                <table class="table table-hover">
                  <tr>
                    <th>Report Name</th>
                    <th>Publisher's Name</th>
                    <th>Upload Report File</th>
                  </tr>
                
              <?php foreach($uploadID as $ids){?>
                      <tr>
                        <td><?php echo ucwords($ids['reportname']);?></td>
                        <td><?php echo ucwords($ids['publisher_name']);?></td>
                        <td><input type="file" name="report_file<?php echo $ids['id'];?>"></td>
                        <input type="hidden" name="reportID[]" value="<?php echo $ids['id'];?>">
                      </tr>
                      
              <?php }?>
                </table>
                <div class="col-md-12 text-right">
                  <input type="submit" name="save" class="btn btn-warning" value="Save">
                </div>
              </form>
            </div>

            <!-- general form elements -->
          </div>
        </div>
      </div>
       <!-- Main content -->
    </section>
    <!-- Content Header (Page header) -->
</div>
