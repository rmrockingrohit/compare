  <style type="text/css">
    .center-div{
      width: 15%;
      margin: 0 auto;
    }
    .img-inline{
      width: 50%;
      display: block;
      margin: 0 auto;
    }
    .text-inline{
      width: 100%;
      display: block;
    }
    .text-inline h4{
      font-size: 17px;
    }
  </style>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1> Add Report In Bulk </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title"> Add Report In Bulk</h3>
            </div>

            <div class="box-body">
              <div class="center-div">
                <div class="img-inline">
                  <!-- <img src="http://assets.stickpng.com/thumbs/580b57fcd9996e24bc43c4c4.png" width="100%"> -->
                  <img src="http://pngriver.com/wp-content/uploads/2018/04/Download-Success-PNG-Image.png" width="100%">
                </div>
                <div class="text-inline">
                  <h4>File Save Successfully</h4>
                </div>
                <div class="col-md-12">
                  <div class="text-center">
                    <a href="<?php echo base_url('index.php/admin/Report');?>" class="btn btn-success" title="Go Back">Go Back</a>
                  </div>
                </div>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  </div>
