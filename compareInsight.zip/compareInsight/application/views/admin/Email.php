<!DOCTYPE html>
<html>
<head>
	<title>Compare Insight <?php echo $title;?></title>
</head>
<style type="text/css">
	@import url('https://fonts.googleapis.com/css?family=Livvic&display=swap');
		/*font-family: 'Livvic', sans-serif;*/
	@import url('https://fonts.googleapis.com/css?family=Montserrat');
		/*  font-family: 'Montserrat', sans-serif;  */
	@import url('https://fonts.googleapis.com/css?family=Rajdhani&display=swap');
		/*font-family: 'Rajdhani', sans-serif;*/
	body{
		margin: 0px auto;
		width: 50%;
		font-family: 'Livvic', sans-serif;
	}
	.head{
		background-color: #022ed0;
		height: 110px;
		text-align: center;
		color: #fff;
		line-height: 110px;
		font-family: 'Rajdhani', sans-serif;
		font-weight: 900;
		font-size: 20px;
		width: 100%;
	}
	
	.big{
		font-size: 30px;
	}
	.title{
		border:1px solid #eaeaea;
		padding-right: 15px;
		text-align: center;
		color: #1dcc1d;
	}
	.body{
		background: #eaeaea;
		height: 100%;
		padding:15px;
		margin: 0 auto;
	}
</style>
<body>
	<div class="head">
		<label class="big">C</label>ompare <label class="big">I</label>nsight
	</div>
	<div class="title">
		<h5><?php echo $title;?></h5>
	</div>
	<div class="body">
		
	</div>
</body>
</html>