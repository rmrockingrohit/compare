<?php include('includedItems/headers.php');?>
<style type="text/css">
	.heading-h2{
		color:orange;
		padding-bottom: 15px;
	    margin-bottom: 30px;
	}
	.heading-h2 b{
		border-bottom: 2px solid;
		padding-bottom: 20px;
	}
	.title-head{
		font-weight: 900;
	    font-size: 12px;
	    color: #807d7d;
	    text-shadow: none;
	    word-spacing: 2px;
	    letter-spacing: 1px;
	}
	.science img{
		float: left !important;
	    width: 100px !important;
	    padding-right: 15px !important;
	    margin: 0px 10px 10px !important;
	}
</style>
    <!-- BODY WORK START -->
        <?php include('includedItems/navigation.php');?>
        <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
		<script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
		<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.10.18/datatables.min.css"/>
		 
		<script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.10.18/datatables.min.js"></script>

        <div class="container-fluid">

        	<div class="row">

        		<div class="research-bg-section">

        			<div class="headigs">

        				<h3 class="testimonials-heading"><?php if(isset($data[0]['title'])){echo ucfirst($data[0]['title']);}else{ echo $title;}?></h3>

        			</div>

        		</div>

        	</div>

        </div>





        <div class="container">
        	
			<div class="row">

				<div class="col-md-12 science" style="">

					<div class="row form-group">
						<div class="col-md-12">
							<div class="table-responsive">
								<table class="table table-bordered" style="width:100%">
								    <h2 class="heading-h2"><b>Compare Reports</b></h2>
										<br>
				                    <thead>
				                        <tr id="headings">
				                         	<th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Report Title : activate to sort column ascending" style="width: 35%;text-align: center;">Report Title </th>
				                            
				                            <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="category  : activate to sort column ascending" style="width: 520px;text-align: center;">Category </th>

				                            <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="price  : activate to sort column ascending" style="width: 520px;text-align: center;">Price </th>

				                            <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Publisher Date  : activate to sort column ascending" style="width: 520px;text-align: center;">Publisher Date </th>
											 <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Report Forcast : activate to sort column ascending" style="width: 520px;text-align: center;">Sample Request</th>	

											 <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Report Forcast : activate to sort column ascending" style="width: 520px;text-align: center;">Ask For Discount</th>	
				                           <!-- <th>Publisher Name</th>-->
				                           
				                            <!--<th>Report Forcastto</th>-->
				                                 
				                        </tr>
				                    </thead>

				                    <tbody>
				                    	<?php foreach($report as $row){?>
				                    			<tr>
				                    				<td class="title-head">
				                    					<a href="<?php echo base_url('website/report_info/'.$row[0]['id']);?>" style="color: #000;font-size: 16px;">

				                    						<?php if ($row[0]['category'] =="4"){?>
										                                <img src="<?php echo base_url('vender\images\book/industries.png');?>" alt="Industrial Automation" class="himg" >
																<?php }else if($row[0]['category'] =="78"){?>
																		<img src="<?php echo base_url('vender\images\book/medicine.png');?>" alt="sports" class="himg" >
																<?php }else if($row[0]['category'] =="3"){?>
																		<img src="<?php echo base_url('vender\images\book/food.png');?>" alt="Food & Beverage" class="himg" >
																<?php }else if($row[0]['category'] =="76"){?>
																		<img src="<?php echo base_url();?>vender\images\book/chemistry.png" alt="Chemicals & Materials" class="himg" >
																<?php }else if($row[0]['category'] =="75"){?>
																		<img src="<?php echo base_url('vender\images\book/transport.png');?>" alt="Automotive & Transportation" class="himg" >
																<?php }else if($row[0]['category'] =="1"){?>
																		<img src="<?php echo base_url('vender\images\book/electronic.png');?>" alt="Electronics & Semiconductor" class="himg" >
																<?php }else if($row[0]['category'] =="77"){?>
																		<img src="<?php echo base_url('vender\images\book/medicine.png');?>" alt="Healthcare, Pharmaceuticals & Medical Devices" class="himg" >
																<?php }else if($row[0]['category'] =="2"){?>
																		<img src="<?php echo base_url('vender\images\book/retail.png');?>" alt="Retail & Consumer Goods" class="himg" >
																<?php }else if($row[0]['category'] =="79"){?>
																		<img src="<?php echo base_url('vender\images\book/defencce.png');?>" alt="Aerospace and Defense" class="himg" >
																<?php }else if($row[0]['category'] =="80"){?>
																		<img src="<?php echo base_url('vender\images\book/constuction.png');?>" alt="Building, Construction Manufacturing" class="himg" >
																<?php }?>
				                    						
				                    						
				                    						<?php echo $row[0]['reportname'];?>
				                    					</a>
				                    				</td>
				                    				
				                    				<td class="text-center">
				                    					<a href="<?php echo base_url('website/research/'.$row[0]['category']);?>" style="color: #000;font-size: 12px;">
				                    						<?php echo $row[0]['title'];?>
				                    					</a>
				                    				</td>
				                    				<td class="text-center"><i class="fas fa-dollar-sign"></i> <?php echo $row[0]['price'];?></td>
				                    				<td class="text-center">
				                    					<?php $date=date_create($row[0]['publisher_date']);echo date_format($date,"M - Y");?>
				                    				</td>
				                    			
				                    				<td class="text-center">
				                    					<a href="<?php echo base_url('website/');?>enquery/<?php echo $row[0]['id'];?>" class="byn btn-link" style="color: #000;font-size: 12px;">Click Here..</a>
				                    				</td>

				  									<td>
				  										<a href="<?php echo base_url('website/');?>enquery/<?php echo $row[0]['id']; ?>" style="color: #000;font-size: 12px;">Report Enquery</a>
				  									</td>
				                    				
				                    			</tr>
				                    	<?php }?>
				                    </tbody>
				                </table>
							</div>
							<div class="col-md-12 text-right">
								<a href="<?php echo base_url('website/research/'.$report_id);?>" title="Back To report" class="btn btn-danger" style="">Back To Report Page
								</a>
							</div>
						</div>
					</div>

				</div>

			</div>

		</div>

<?php include('includedItems/footer.php');?>
<script type="text/javascript">
$(document).ready(function() {
    $('#example').DataTable({
        "aLengthMenu": [[5, 10, 25, -1], [5, 10, 25, "All"]],
        "iDisplayLength": 5
       } 
        );
} );
</script>