<?php include('includedItems/headers.php');?>
  
    <!-- BODY WORK START -->
        <?php include('includedItems/navigation.php');?>

        <div class="container-fluid" style="
    height: 270px;
">
          <div class="row">
            <div class="research-bg-section">
              <div class="headigs">
                <h3 class="testimonials-heading"><?php echo ucfirst($title)."<br/>(Sample Report Request)";?></h3>
              </div>
            </div>
          </div>
        </div>

<section class="contact py-8 bg-light" id="contact">
  <div class="container">
    <div class="row">
        <div class="col-md-8" >
           <h4 style="margin-left: 25px;color: #c32121;"> <b>Enquery Form</b></h4>
          <hr>
        </div>
  <!--  <div class="col-md-6">
        
    </div>-->
    <div class="col-md-8" style=" margin-left: 0px; " id="enq">
        <div class="card">
          <div class="card-body">
            <div style="margin-top: 25px;" id="enq-form">
              
              <div class="row form-group">
                <div class="col-md-11 sm-middle">
                  <input name="fullname" placeholder="Full Name" class="form-control" type="text" required="required" id="name">
                  <br>
                </div>
</div>
<div class="row form-group">
                <div class="col-md-11 sm-middle">
                  <input  name="companyname" placeholder="Company Name" class="form-control" type="text" required="required" id="companyname">
                  <br>
                </div>
</div>
<div class="row form-group">
                <div class="col-md-11 sm-middle">
                  <input type="email" name="email" class="form-control" placeholder="Email" required="required" id="email">
                  <br>
                </div>
              </div>
              
              <div class="row form-group">
                <div class="col-md-11 sm-middle">
                  <select name="country" class="form-control" required="required" id="country">
                    <option value="" style="color:#888;">Country</option>
                    <option value="USA">USA</option> <option value="UK">UK</option>
                    <option value="CANADA">Canada</option> 
                    <option value="INDIA">India</option>  <option value="PAKISTAN">Pakistan</option>
                    <option value="UAE">UAE</option> 
                    <optgroup label="- - - - - - - - - - - - - - - - -">
                    <option value="AUSTRALIA">Australia</option>
                    <option value="AUSTRIA">Austria</option>
                    <option value="BAHRAIN">Bahrain</option>
                    <option value="BANGLADESH">Bangladesh</option>
                    <option value="BELGIUM">Belgium</option>
                    <option value="Brazil">Brazil</option>
                    <option value="China">China</option>
                    <option value="Cuba">Cuba</option>
                    <option value="Cyprus">Cyprus</option>
                    <option value="Denmark">Denmark</option>
                    <option value="Fiji">Fiji</option>
                    <option value="Finland">Finland</option>
                    <option value="France">France</option>
                    <option value="Georgia">Georgia</option>
                    <option value="Germany">Germany</option>
                    <option value="Greece">Greece</option>
                    <option value="Hong Kong">Hong Kong</option>
                    
                  </select>
                  <br>
                </div>  
</div>

<div class="row form-group">
                <div class="col-md-11 sm-middle">
                  <input name="mobileno" placeholder="Mobile No." class="form-control" required="required" type="number" id="numbers"><br>
                </div>
                </div>
                <div class="row form-group">                           
                <div class="col-md-11 sm-middle">
                    <textarea name="comment" cols="40" rows="5" placeholder="Your Message"class="form-control" id="msg"></textarea><br>
                </div>
              </div>
              <div class="row form-group">
              <input type="hidden" name="report" value="<?php echo $report_id;?>" id="r_id">
              </div>

              <div class="from-group text-center">
                <button name="button" class="btn btn-warning" id='enqMail'> Submit</button>
              
              </div>
              <br>
          </div>
        </div>
      </div>
    </div>




      <div class="col-md-4" style="
    width: 360px;
">

              <div class="card">

                <article class="card-group-item">

                  <header class="card-header">

                    <h5 class="title">KEY BENEFITS </h5>

                  </header>

                  <div class="filter-content">

                    <div class="card-body">

                    <form>

                      <label class="form-check">

                        

                        <span class="form-check-label">

                       <b>  24 * 7 Access to Analyst</b> :

                        </span><br>

                        <p>Get your pre and post sales queries resolved by our Subject matter experts.</p><hr>

                      </label> <!-- form-check.// -->

                      <label class="form-check">

                        

                        <span class="form-check-label">

                         <b> Customization </b>:

                        </span><br>

                        <p>We will assist you to customize the report to fit your research needs.</p><hr>

                      </label>  <!-- form-check.// -->

                      <label class="form-check">

                        

                        <span class="form-check-label">

                        <b> Security </b>:

                        </span><br>

                        <p>Your personal and confidential information is safe and secured.</p><hr>

                      </label> 

                      

                        <label class="form-check">

                        

                        <span class="form-check-label">

                        <b> Assured Quality  </b>:

                        </span><br>

                        <p>Our prime focus is to provide qualitative and accurate data.</p><hr>

                      </label> 

                      

                      <label class="form-check">

                        

                        <span class="form-check-label">

                        <b> Free sample report  </b>:

                        </span><br>

                        <p>Feel free to order a sample report before purchase.</p><hr>

                      </label> 

                      

                    </form>



                    </div> <!-- card-body.// -->

                  </div>

                </article> <!-- card-group-item.// -->

  

                <article class="card-group-item">

                  <header class="card-header">

                    <h4 class="title">Require Customization?? </h4>

                  </header>

                  <div class="filter-content">

                    <div class="card-body">

                    <label class="form-check">

                     

                      <span class="form-check-label">

                        Let us know your customized needs and our Subject matter experts will work directly with you to provide you with data as per your needs.

                      </span>

                    </label>

                  

                  

                    </div> 

                  </div>

                </article> 

              </div> 



            </div>

          </div>



          

        </div>

          </div>

        </div>












  </div>
</div>
</section>
   


       
   <?php include('includedItems/footer.php');?>