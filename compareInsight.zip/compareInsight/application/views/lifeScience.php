<?php include('includedItems/headers.php');?>
	
    <!-- BODY WORK START -->
        <?php include('includedItems/navigation.php');?>
        <?php //include('includedItems/slides.php');?>

        <div class="container-fluid">
        	<div class="row">
        		<div class="science-bg-section">
        			<div class="headigs">
        				<h3 class="testimonials-heading">Life & Science</h3>
        			</div>
        		</div>
        	</div>
        </div>


        <div class="container">
        	
			<div class="row">
				<div class="col-md-12 science" style="">
					<div class="row form-group">
						<div class="col-md-6">
							<img src="<?php echo base_url();?>/vender/images/pine.jpg" width="100%">							
						</div>
						<div class="col-md-6">
							<h3>Study examines colonoscopy, endoscopy infection risks</h3>
							<h6 style="padding: 0px 10px;">Published on June 1, 2018 by Douglas Clark</h6>
							<p>Authors said the work involved examining data from California, Florida, Georgia, Nebraska, New York, and Vermont, as a means of tracking infection-related emergency room visits and unplanned inpatient admissions within seven and 30 days after a colonoscopy or upper-GI endoscopy.
							</p>
						</div>
					</div>

					<div class="row form-group">
						<div class="col-md-6">
							<img src="<?php echo base_url();?>/vender/images/pine2.jpg" width="100%">							
						</div>
						<div class="col-md-6">
							<h3>New blood test aids swift liver damage detection</h3>
					        <h6> Published on May 30, 2018 by Douglas Clark </h6>
					        <p>Details of work from University of Massachusetts Amherst and University College London (UCL) chemists published in Advanced Materials outlined a quick and robust blood test identifying liver damage before symptoms appear, offering what they hope is a significant advance in early detection of liver disease.
					        </p>
						</div>
					</div>
				</div>
        	</div>
        </div>
    <!-- BODY CLOSE -->
<?php include('includedItems/footer.php');?>