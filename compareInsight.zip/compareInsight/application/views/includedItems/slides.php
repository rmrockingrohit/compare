


<section class="">

	<div class="">

		<div class="sliders-wraper">

		    <div class="sliders">

		    	<div class="slide">
		    		<div class="cover-bg-div">
			    		<div class="container">

				    		<div class="row">

				    				<div class="col-md-8 col-md-offset-3 margintop30" style="margin-left: 140px;">
									<div id="left-col"></div>
									<div id="right-col"></div>
									<div id="right-col"></div>
				    				<div class="row form-group" id="slide"></div>
				    		</div>

			    			<div class="row">

			    				<div class="slide-form">

			    					
			    						<?php if(!empty($skillNav)){?>
			    								<div class="row form-group">
			    									<?php for($i=0;$i<5;$i++){?>
				    									<div class="col-md-2">
				    									    <div class="a">
	    			    									    <div class="zooms">
	    			    										    <a href="<?php echo base_url('website/');?>research/<?php echo $skillNav[$i]['id'];?>">
	    							    							    <div class="smooth-zoom">
	            							    							<?php if ($skillNav[$i]['id']=="4"){?>
	                                                         						<img src="<?php echo base_url('assets/images/icn/automatn.png');?>" alt="Aerospace and Defense" class="himg" >
	            											   
	            															<?php }else if($skillNav[$i]['id']=="78"){?>
	            																	<img src="<?php echo base_url('assets/images/icn/sports.png');?>" alt="Aerospace and Defense" class="himg" >
	            
	            															<?php }else if($skillNav[$i]['id']=="3"){?>
	            																	<img src="<?php echo base_url('assets/images/icn/food.png');?>" alt="Aerospace and Defense" class="himg" >
	            
	            															<?php }else if($skillNav[$i]['id']=="76"){?>
	            																	<img src="<?php echo base_url('assets/images/icons/chemical.png');?>" alt="Aerospace and Defense" class="himg" >
	            
	            															<?php }else if($skillNav[$i]['id']=="75"){?>
	            																	<img src="<?php echo base_url('assets/images/icn/transport.png');?>" alt="Aerospace and Defense" class="himg" >
	            
	            															<?php }else if($skillNav[$i]['id']=="1"){?>
	            																	<img src="<?php echo base_url('assets/images/icn/electronics.png');?>" alt="Aerospace and Defense" class="himg" >
	            
	            															<?php }else if($skillNav[$i]['id']=="77 Devices"){?>
	            																	<img src="<?php echo base_url('assets/images/icn/medical.png');?>" alt="Aerospace and Defense" class="himg" >
	            
	            															<?php }else if($skillNav[$i]['id']=="2"){?>
	            																	<img src="<?php echo base_url('assets/images/icn/cart.png');?>" alt="Aerospace and Defense" class="himg" >
	            															

	            														<?php }else if($skillNav[$i]['id']=="79"){?>
					            												<img src="<?php echo base_url('assets/images/icn/plane.png');?>" alt="Aerospace and Defense" class="himg" >
					                                                    <?php }else if($skillNav[$i]['id']=="80"){?>
					            												<img src="<?php echo base_url('assets/images/icn/home.png');?>" alt="Aerospace and Defense" class="himg" >
					            										<?php } ?>
	        							    								<p>
	        							    								<font size ="2" color="#fff"><b><?php echo ucfirst($skillNav[$i]['title']);?></b></font>
	        							    								</p>
	        							    						  </div>
								    						       </a>
								    						  </div>
								    					   </div>
				    									</div>
				    								<?php }?>
			    								</div>
			    						<?php }?>
			    					

	    							<div class="row form-group">

	    								<div class="col-md-12">			    							

	    									<form class="form-index-input" id="slide-form">
	    										<div class="input-group">														
	    											<span class="errMsg" style="right: 0px;left: 158px;top: 05px;"></span>
	    											<input type="text" style="background-color:transparent;border:2px solid #f9f9f9;margin-top: 20px;color: #fff" name="name" class="form-control" placeholder="Search Here.." id="slide-txt" >
													<button type="submit" class="button-slide1" style="top: 40px;"><i class="fa fa-search"></i></button>
	    											<div class="search-item"></div>
	    										</div>

	    										<span class="errMsg"></span>						   										
	    										<input type="hidden" name="id" id='valId'>
	    									</form>

		    							</div>

	    							</div>


	    							<?php if(!empty($skillNav)){?>
		    								<div class="row form-group">
		    									<?php for($j=5;$j<10;$j++){?>
			    									<div class="col-md-2">
			    									    <div class="aa">
			    									        <div class="zooms">
	        		    										<a href="<?php echo base_url('website/');?>research/<?php echo $skillNav[$j]['id'];?>">
	        						    							<div class="smooth-zoom">
	        						    							<?php if ($skillNav[$j]['id']=="4"){?>
	                                                 						<img src="<?php echo base_url('assets/images/icn/automatn.png');?>" alt="Aerospace and Defense" class="himg" >
	        										   
	        														<?php }else if($skillNav[$j]['id']=="78"){?>
	        																<img src="<?php echo base_url('assets/images/icn/sports.png');?>" alt="Aerospace and Defense" class="himg" >
	        
	        														<?php }else if($skillNav[$j]['id']=="3"){?>
	        																<img src="<?php echo base_url('assets/images/icn/food.png');?>" alt="Aerospace and Defense" class="himg" >
	        
	        														<?php }else if($skillNav[$j]['id']=="76"){?>
	        																<img src="<?php echo base_url('assets/images/icn/chemical.png');?>" alt="Aerospace and Defense" class="himg" >
	        
	        														<?php }else if($skillNav[$j]['id']=="75"){?>
	        																<img src="<?php echo base_url('assets/images/icn/transport.png');?>" alt="Aerospace and Defense" class="himg" >
	        
	        														<?php }else if($skillNav[$j]['id']=="1"){?>
	        																<img src="<?php echo base_url('assets/images/icn/electronics.png');?>" alt="Aerospace and Defense" class="himg" >
	        
	        														<?php }else if($skillNav[$j]['id']=="77"){?>
	        																<img src="<?php echo base_url('assets/images/icn/medical.png');?>" alt="Aerospace and Defense" class="himg">
	        
	        														<?php }else if($skillNav[$j]['id']=="2"){?>
	        																<img src="<?php echo base_url('assets/images/icons/cart.png');?>" alt="Aerospace and Defense" class="himg" >
	        														
	            														<?php
														}    else if($skillNav[$j]['id']=="79"){?>
	            																	<img src="<?php echo base_url('assets/images/icn/plane.png');?>" alt="Aerospace and Defense" class="himg" >
	            															

	                                                                            
	            															




	                                                    <?php
														}    else if($skillNav[$j]['id']=="80"){?>
	            																	<img src="<?php echo base_url('assets/images/icn/home.png');?>" alt="Aerospace and Defense" class="himg" >
	            															<?php
														}
															?>


	        						    								<p>
	        						    									<font size ="2" color="#fff"><b><?php echo ucfirst($skillNav[$j]['title']);?></b></font>
	        						    								</p>
	        						    							</div>
	        						    						</a>
	        						    					</div>
	        						    				</div>
			    									</div>
			    								<?php }?>
		    								</div>
		    						<?php }?>

	    						</div>
	    					</div><!-- Row Closed -->
										


			    				</div><!-- COL-MD-8 -->

			    			</div>

			    		</div><!-- CONTAINER -->

			    	</div>

		    	</div>

		    </div>

		</div>

	</div>

</section>



<!-- <?php  /* if(!empty($skillNav)){		    								
			    						    
		    						      		foreach($skillNav as $value){ ?>

						    						<div class="right-box-md-2">

						    							<a href="<?php echo base_url('website/');?>research/<?php echo $value['id'];?>">

						    								<div class="smooth-zoom">
															
													<?php	if ($value['title']=="Industrial Automation")
															{?>
                                              <img src="assets/images/icons/automatn.png" alt="Aerospace and Defense" class="himg" style=" width: 50px; height: 50px;">
											   
															<?php }
															
															else if($value['title']=="Sports"){?>
															<img src="<?php echo base_url('assets/images/icons/sports.png');?>" alt="Aerospace and Defense" class="himg" style=" width: 50px; height: 50px;">
																<?php
															}
														
														else if($value['title']=="Food & Beverage"){?>
															<img src="assets/images/icons/food.png" alt="Aerospace and Defense" class="himg" style=" width: 50px; height: 50px;">
																<?php
															}
															else if($value['title']=="Chemicals & Materials"){?>
															<img src="assets/images/icons/chemical.png" alt="Aerospace and Defense" class="himg" style=" width: 50px; height: 50px;">
																<?php
															}
															else if($value['title']=="Automotive & Transportation"){?>
															<img src="assets/images/icons/transport.png" alt="Aerospace and Defense" class="himg" style=" width: 50px; height: 50px;">

																<?php
															}
													else if($value['title']=="Electronics & Semiconductor"){?>
															<img src="assets/images/icons/electronics.png" alt="Aerospace and Defense" class="himg" style=" width: 50px; height: 50px;">
																<?php
													}
													else if($value['title']=="Healthcare, Pharmaceuticals & Medical Devices"){?>
															<img src="assets/images/icons/medical.png" alt="Aerospace and Defense" class="himg" style=" width: 50px; height: 50px;">
																<?php
													}
													else if($value['title']=="Retail & Consumer Goods"){?>
															<img src="assets/images/icons/cart.png" alt="Aerospace and Defense" class="himg" style=" width: 50px; height: 50px;">
																<?php
													}
													else if($value['title']=="Construction & Manfacturing"){?>
															<img src="assets/images/icons/construction.png" alt="Aerospace and Defense" class="himg" style=" width: 50px; height: 50px;">
																<?php
													}
														?>
														
													<p><font size ="3" color="black"><b><?php echo ucfirst($value['title']);?></font></b></p>
															

						    								</div>

						    							</a>

						    						</div>

		    						<?php   	 }
		    								} */ ?> -->