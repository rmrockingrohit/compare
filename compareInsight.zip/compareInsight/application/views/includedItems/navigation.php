		<?php $a = $b = $c = $d = $e = $f = $g = $def = '';
		switch ($title) {
		    case "Service":
		        $a = 'active';
		        break;
		    case "About":
		        $b = 'active';
		        break;
		    case "Industries news":
		        $c = 'active';
		        break;
		    case "Research Industries":
		        $d = 'active';
		        break;
		    case "Publisher list":
		        $e = 'active';
		        break;
		    case "Custom Research":
		        $f= 'active';
		        break;
		    case "Contact":
		        $g= 'active';
		        break;
		   
		    default:
		         $def = 'active';
		}
?>

		<!--	TOP NAVIGATION BAR -->
			<section class="top-nav">
			    <div class="container-fluid">
			    	<div class="row">
			    		<div class="topbar" 
background-color=black;
	style="
    border-right-width: 0px;
    border-top-width: 90px">
			    			<div class="container">
			    				<div class="row">
			    					<div class="col-md-4">
			    						<div class="contact-info-wraper">
			    							<ul class="contact-info">
			    								<li class="l-h-70" style="letter-spacing: 1px; display: block;">
			    									<b><i class="fas fa-phone-volume"></b></i>			    						
			    									<b><font size=2>	
			    									+91 8007-4067-89</b></font>		
			    									<br/>
			    									<i class="far fa-envelope-open"></i><b>	
			    									sales@compareinsights.com
			    									<br><p>
			    									<i class="far fa-envelope-open"></i> queries@compareinsights.com</p></b>
			    								</li>
			    							</ul>
			    						</div>			    						
			    					</div>
			    					<div class="col-md-4">
			    						<h3 class="company-name"  style="margin-top: 25px;">
			    							<span class="largefont">C</span>OMPARE <span class="largefont">I</span>NSIGHTS
			    						</h3>
			    					</div>
			    					<div class="col-md-4"  style="margin-top: 25px;">			    						
			    						<div class="contact-info-wraper2">
			    							<ul class="contact-info">
			    								<li class="l-h-70">
			    									<a href="<?php echo base_url('login');?>">
			    										<i class="fas fa-user"></i><b><font size=3> Login | SignUp</font></b>
			    									</a>
			    								</li>			    								
			    							</ul>

			    							<ul class="contact-info ">
			    								<li class="social l-h-70"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
		    									<li class="social l-h-70"><a href="#"><i class="fab fa-twitter"></i></a></li>
		    									<li class="social l-h-70"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>							
			    							</ul>
			    						</div>
			    					</div>
			    				</div>
			    			</div>
			    		</div>
			    	</div>
			    </div>
			</section>
		<!-- TOP NAVIGATION BAR CLOSED -->

		

		<!-- NAVIGATION BAR START -->
		<section class="navigation">
			<nav class="navbar navbar-default">
				<div class="container">
				    <div class="navbar-header">
				    	<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
					        <span class="icon-bar"></span>
					        <span class="icon-bar"></span>
					        <span class="icon-bar"></span> 
				        </button>
				      <!-- <a class="navbar-brand" href="<?php echo base_url('website');?>">
				      	<!--<img src="<?php //echo base_url(' vender/images/default/logo1.png');?>"> 
				      		<img src="<?php //echo base_url();?>vender/images/default/compare.png" style="width: 110px; height: 32px;margin-top: 10px;">
				      	<h1 class="hidden-xs-h"><b>Compare Insight</b></h1>
				      </a> -->
				        <div class="show-xs">
                            <a href="<?php echo base_url('website/cartItems1');?>">
                              <i class="fas fa-shopping-cart"></i>      								
                              <span class="cart-item"><?php echo (count($cart));?></span>
                            </a>
                            <div class="hide" id="hide">
      							<form action="<?php echo base_url('website/compare');?>" method="post" id="compareForm">
      								<input type="submit" name="check" class="btn btn-danget" value="Compair" id="compBtn">
      							</form>
      							<!-- <a style="cursor: pointer;">Compair</a>  --> 
      						</div>
                        </div>
				    </div>
			    	<div class="collapse navbar-collapse" id="myNavbar">
      					<ul class="nav navbar-nav">      						
                            <li class="">
                                <a href="<?php echo base_url('Website/');?>">
                                	<i class="fas fa-home"></i>
                                </a>
                            </li> 
                            <li class="<?php echo $a;?>">
                                <a href="<?php echo base_url('Website/');?>services">Service</a>
                            </li> 
                             <li class="<?php echo $b;?>">
                                <a href="<?php echo base_url('Website/');?>about">About</a>
                            </li> 
                            <li class="<?php echo $c;?> dropdown">
                            	<a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            		Industries news <i class="fas fa-angle-down"></i>
                            	</a>
                            	<ul class="dropdown-menu dropdown">
                            		<li>
                            			<a class="dropdown-item" href="<?php echo base_url('website/');?>lifeScience">Life Science</a>
                            		</li>
						            <li><a class="dropdown-item" href="<?php echo base_url('website/');?>automotive">Automotive</a></li>
						            <li><a class="dropdown-item" href="<?php echo base_url('website/');?>semiconductor">Semi Conductor</a></li>
                            	</ul>

                            </li>
                            <li class="<?php echo $d;?>">
                            	<a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            		Research Industries <i class="fas fa-angle-down"></i>
                            	</a>
                            	<ul class="dropdown-menu dropdown">
                            		<?php 
						                foreach($skillNav as $row){								    
						          	?>
                            			<li><a class="dropdown-item" href="<?php echo base_url('website/research/'.$row['id']);?>">
                            					<?php echo ucfirst($row['title']);?>     						
                            				</a>
                            			</li>

                            		<?php }?>						            
                            	</ul>
                            </li>
                            <li class="<?php echo $e;?>">
                            	<a href="<?php echo base_url('website/');?>publisherlist">Publisher list</a>
                            </li>
                            <li class="<?php echo $f;?>">
                            	<a href="<?php echo base_url('website/');?>customResearch">Custom Research</a>
                            </li>
                            <li class="<?php echo $g;?>">
                            	<a href="<?php echo base_url('website/');?>contact">Contact</a>
                            </li>
                            
                        </ul>        
                        <ul class="nav navbar-nav navbar-right">
      						<li class="cart-data hide-xs rigtCart">
      							<a href="<?php echo base_url('website/cartItems1');?>">
      								<i class="fas fa-shopping-cart"></i>  
      								<?php if(count($cart)>0){?>
      									<span class="cart-item"><?php echo (count($cart));?></span>
      								<?php }?>
      							</a>
      						</li> 
      						<li class="hide hide-xs" id="hide">
      							<form action="<?php echo base_url('website/compare');?>" method="post" id="compareForm">
      								<input type="submit" name="check" class="btn btn-danget" value="Compare" id="compBtn">
      								<?php if(isset($report_id)){?>
      								    <input type="hidden" name="report_id" value="<?php echo $report_id;?>">
      								<?php }?>
      							</form>
      							<!-- <a style="cursor: pointer;">Compair</a>  --> 
      						</li>
      					</ul>            				    
			    	</div>
			  	</div>
			</nav>
		</section>
		<!-- NAVIGATION BAR CLOED -->