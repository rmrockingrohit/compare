
<!DOCTYPE html>

<html>

	<head>

		<title> Compare Insight</title>

		<!-- META TAGS -->

		  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

 		  <meta http-equiv="X-UA-Compatible" content="IE=edge">

 		  <meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1, minimal-ui">

		  <meta charset="UTF-8">

		  <meta name="description" content="">

		  <meta name="keywords" content="">

		  <meta name="author" content="Rohit Mishra(coscode.com)">

		  <meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- META CLOSED -->		

		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>vender/css/bootstrap.css">		

		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>vender/css/helper.css">

		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css" >		

		<script type="text/javascript" src="<?php echo base_url();?>vender/js/jquery.js"></script>

    <script type="text/javascript" src="<?php echo base_url();?>vender/js/bootstrap.min.js"></script>
   

	</head>

	<body>
    <!-- <script>
     $(function(){
         $(window).on('load',function(){
            jQuery(".preloader").delay(1000).fadeOut("slow")
         })
        
     })
       </script> 
    <div class="preloader">
      <span class="spiner"></span>
    </div> -->



<!-- EXTRA WIDGETS  -->

 

        <div id="mySidenav" class="sidenav">
        	<a id="authenticity" style="cursor: pointer;">Offine Chat</a>
    		    <div id="chat" class="">
    		    	<div class="panel panel-default">

    		    		<div class="panel-heading"><strong>Offline Chat</strong>
                  <span class="exit" id="close-chat" style="cursor: pointer;"><i class="far fa-window-close"></i>
                </div>
                <form class="form-horizontal contact-form">
    		    		  <div class="panel-body">    		    			
                    <fieldset>                        
                      <div class="form-group">
                        <label class="col-md-12" for="name">Name</label>
                        <div class="col-md-12">
                          <input id="name" name="name" type="text" placeholder="Your name" class="form-control" required="required" id="name">
                        </div>
                      </div>       
                      <!-- Email input-->
                      <div class="form-group">
                        <label class="col-md-12" for="email">Your E-mail</label>
                        <div class="col-md-12">
                          <input id="email" name="email" type="email" placeholder="Your email" class="form-control" required="required" id="email">
                        </div>
                      </div>
                      <!-- Message body -->
                      <div class="form-group">
                        <label class="col-md-12" for="message">Your message</label>
                        <div class="col-md-12">
                          <textarea class="form-control" id="message" name="message" placeholder="Please enter your message here..." rows="5" required="required" id="message"></textarea>
                        </div>
                      </div>                       
                    </fieldset>                  
    		    		</div>
        				<div class="panel-footer">
                  <!-- Form actions -->
                    <div class="form-group">
                      <div class="col-md-12 text-right">
                        <button type="button" class="btn btn-black" name="submit" id="chatSubmit">
                            <i class="fas fa-paper-plane"></i> 
                            Send
                        </button>
                      </div>
                    </div>
                </div>
              </form>
  		    	</div>
  		    </div>
		</div> 


<div id="alertBox" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Inputs Error Notification</h4>
      </div>
      <div class="modal-body">
        <p class="text-center">Please Fill All Deatil properly .</p>
        <p class="text-center">Every Fields are Require .</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<div id="successBox" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Offline Chat Success</h4>
      </div>
      <div class="modal-body">
        <h3>Success .</h3>
        <p>Your Query Has been Submitted Successfuly. We will contact You As Soon As Possible.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<div id="errorBox" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Service Failed</h4>
      </div>
      <div class="modal-body">
        <h3>Error .</h3>
        <p>Due to Some Server Error we are not able to submit uoyr request. Please Try After Some Time.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>




	    <!-- EXTRA CLOSE -->