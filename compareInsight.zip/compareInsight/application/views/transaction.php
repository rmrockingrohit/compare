<?php  include('includedItems/headers.php');?>
	
    <!-- BODY WORK START -->
        <?php include('includedItems/navigation.php');?>
        <?php // include('includedItems/slides.php');?>

       <div class="container-fluid">
            <div class="row">
                <div class="about-bg-section">
                    <div class="headigs">
                        <h3 class="testimonials-heading">Transaction</h3>
                    </div>
                </div>
            </div>
        </div>

     


			<div class="row">
				<div class="col-md-12" style="">
					<form action="/action_page.php">

										
							
			        
				        	

						
					    <div class="row form-group">						
							<div class="col-md-12">
				                <h3 class="text-center">Payment</h3>
				            </div>				        

					        <div class="col-md-12">								    								      
								<div class="row form-group">
									<div class="col-md-4">
							            <label for="fname" class="col-md-12">Accepted Cards</label>
							            <div class="icon-container text-center">
							              <i class="fab fa-cc-visa" style="color:navy;font-size: 45px;"></i>
							              <i class="fab fa-cc-amex" style="color:blue;font-size: 45px;"></i>
							              <i class="fab fa-cc-mastercard" style="color:red;font-size: 45px;"></i>
							              <i class="fab fa-cc-discover" style="color:orange;font-size: 45px;"></i>
							            </div>
							        </div>
							        <div class="col-md-4">
							            <label for="cname" class="col-md-12">Name on Card</label>
							            <input type="text" id="cname" name="cardname" class="form-control" placeholder="John More Doe" required="required">
							        </div>
							        <div class="col-md-4">
							            <label for="ccnum" class="col-md-12">Credit card number</label>
							            <input type="text" class="form-control" id="ccnum" name="cardnumber" placeholder="1111-2222-3333-4444" required="required">					            
							        </div>
							    </div>

							    <div class="row form-group">
									<div class="col-md-4">
							            <label for="expmonth" class="col-md-12">Exp Month</label>
						            	<input type="text" id="expmonth" name="expmonth" class="form-control" placeholder="September" required="required">
							        </div>
							        <div class="col-md-4">
							            <label for="expyear" class="col-md-12">Exp Year</label>
						                <input type="text" class="form-control" id="expyear" name="expyear" placeholder="2018" required="required">
							        </div>
							        <div class="col-md-4">
							            <label for="cvv" class="col-md-12">CVV</label>
						                <input type="text" id="cvv" class="form-control" name="cvv" placeholder="352" required="required">				            
							        </div>
							    </div>
							    <input type="hidden" id="product" name="reportId" value="">
				            </div>
						</div>


						<div class="row form-group">						
							<div class="col-md-12">				               
				                <a id="checkOutBTN" class="btn btn-success" data-toggle="modal" >   
				                	Continue to checkout
				                </a>
				            </div>	
				        </div>				     
					</form>						    					
				</div>
        	</div>
   <hr>

   <hr>
   
<?php include('includedItems/footer.php');?>