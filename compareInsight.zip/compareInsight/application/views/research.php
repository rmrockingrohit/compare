<?php include('includedItems/headers.php');?>

    <!-- BODY WORK START -->

        <?php include('includedItems/navigation.php');?>

        <?php //include('includedItems/slides.php');?>


        <style>
	        .btn{
	        	border-radius: 0px;
	        }

	        .display-box{
	        	border-radius: 0px;
	        	border-bottom: 3px solid #0a0adb;
				border-right: 1px solid blue;
	        }
            .img-box img,.profile-image img {
                /*width: auto;
                box-shadow: none !important;
                max-width: 50px;
				max-height: 142px;
				margin-top: 40px;*/
				max-width: 100%;
    			max-height: 180px;
            }
            .img-box {
			    margin-bottom: 10px;
			    background: #eadca3;
			    height: 180px;
			}
            .proile-tag{
                font-size: 12px !important;
                color: #f5c200 !important;
            }
            .research-bg-section{
                position:relative;
            }
            .headigs img{
                position: absolute;
                top: 0px;
                left: 47%;
                width: 70px;
                margin-top: 15px;
                background: #f0c422;
                border-radius: 50%;
                height: 70px;
                padding: 15px;
            }
            .checkboxes{
            	display: block;
            	text-align: left;
            	color: #000;
    			font-weight: 600;
            }
            .checkboxes:hover{
            	text-decoration: none;
            }
            .heading-box a p{
            	color: #ff2929;
			    font-weight: 900;
			    word-spacing: 2px;
			    letter-spacing: 1px;
			    /* font-size: 20px; */
			    /* padding: 0px !important; */
			    height: 60px;
            }
            .pdf .far{
            color: #ea4747;
		    font-size: 20px;
		    font-weight: 100;
		    margin-right: 15px;
            }
        </style>
        <div class="container-fluid">

        	<div class="row">

        		<div class="research-bg-section">

        			<div class="headigs">
        			    <?php if ($id =="4"){?>
                                <img src="<?php echo base_url('assets/images/icons/automatn.png');?>" alt="Aerospace and Defense" class="himg" >
						<?php }else if($id =="78"){?>
								<img src="<?php echo base_url('assets/images/icons/sports.png');?>" alt="Aerospace and Defense" class="himg" >

						<?php }else if($id =="3"){?>
								<img src="<?php echo base_url('assets/images/icons/food.png');?>" alt="Aerospace and Defense" class="himg" >

						<?php }else if($id =="76"){?>
								<img src="<?php echo base_url();?>assets/images/icons/chemical.png" alt="Aerospace and Defense" class="himg" >

						<?php }else if($id =="75"){?>
								<img src="<?php echo base_url('assets/images/icons/transport.png');?>" alt="Aerospace and Defense" class="himg" >

						<?php }else if($id =="1"){?>
								<img src="<?php echo base_url('assets/images/icons/electronics.png');?>" alt="Aerospace and Defense" class="himg" >

						<?php }else if($id =="77"){?>
								<img src="<?php echo base_url('assets/images/icons/medical.png');?>" alt="Aerospace and Defense" class="himg" >

						<?php }else if($id =="2"){?>
								<img src="<?php echo base_url('assets/images/icons/cart.png');?>" alt="Aerospace and Defense" class="himg" >
						<?php }else if($id =="79"){?>
								<img src="<?php echo base_url('assets/images/icons/plane.png');?>" alt="Aerospace and Defense" class="himg" >
						<?php }else if($id =="80"){?>
								<img src="<?php echo base_url('assets/images/icons/home.png');?>" alt="Aerospace and Defense" class="himg" >
						<?php }?>
                        <h3 class="testimonials-heading"><?php if(isset($data[0]['title'])){echo ucfirst($data[0]['title']);}else{ echo $title;}?></h3>
        			</div>

        		</div>

        	</div>

        </div>





        <div class="container">
        	
			<div class="row">

				<div class="col-md-12 science" style="">

					<div class="row form-group">

						<div class="col-md-4">

							<div class="row form-group hide-media">

								<div class="card">

									<div class="row form-group">

										<article class="card-group-item">

											<header class="card-header">

												<h5 class="title absolute-title">Search By Category </h5>

											</header>

											<div class="filter-content">

												<div class="card-body">

													<form>

														<?php foreach($skillNav as $category){
																if($id == $category['id']){
																	$check = "checked = checked";
																	$act   = 'style="color:#f52020"' ;
																}else{
																	$check = $act = '';
																}
														 ?>
															<a href="<?php echo base_url('Website/research/'.$category['id']);?>" class="btn btn-link checkboxes" <?php echo $act;?>>
																<input type="checkbox" name="checkbox" <?php echo $check;?>> 
																<?php echo $category['title'];?>
															</a>
														<?php }?>

													</form>

												</div> <!-- card-body.// -->

											</div>

										</article> <!-- card-group-item.// -->
									
									</div>
								</div>
							</div>


							
						</div><!-- COL_MD_4 -->
					
						<div class="col-md-8">

							<?php   if (count($reports) > 0) {
                  					   foreach($reports as $row) {?>

										<div class="display-box">							

											<div class="row" id="reports">

												<div class="col-md-3">

													<div class="img-box text-center">
														<a href="<?php echo base_url('website/');?>report_info/<?php echo $row['id'];?>">
	                                                        <?php if(!empty($row['reportdoc']) || $row['reportdoc'] != ''){?>
	                                                        	<?php if ($id =="4"){?>
										                                <img src="<?php echo base_url('vender\images\book/industries.png');?>" alt="Industrial Automation" class="himg" >
																<?php }else if($id =="78"){?>
																		<img src="<?php echo base_url('vender\images\book/medicine.png');?>" alt="sports" class="himg" >
																<?php }else if($id =="3"){?>
																		<img src="<?php echo base_url('vender\images\book/food.png');?>" alt="Food & Beverage" class="himg" >
																<?php }else if($id =="76"){?>
																		<img src="<?php echo base_url();?>vender\images\book/chemistry.png" alt="Chemicals & Materials" class="himg" >
																<?php }else if($id =="75"){?>
																		<img src="<?php echo base_url('vender\images\book/transport.png');?>" alt="Automotive & Transportation" class="himg" >
																<?php }else if($id =="1"){?>
																		<img src="<?php echo base_url('vender\images\book/electronic.png');?>" alt="Electronics & Semiconductor" class="himg" >
																<?php }else if($id =="77"){?>
																		<img src="<?php echo base_url('vender\images\book/medicine.png');?>" alt="Healthcare, Pharmaceuticals & Medical Devices" class="himg" >
																<?php }else if($id =="2"){?>
																		<img src="<?php echo base_url('vender\images\book/retail.png');?>" alt="Retail & Consumer Goods" class="himg" >
																<?php }else if($id =="79"){?>
																		<img src="<?php echo base_url('vender\images\book/defencce.png');?>" alt="Aerospace and Defense" class="himg" >
																<?php }else if($id =="80"){?>
																		<img src="<?php echo base_url('vender\images\book/constuction.png');?>" alt="Building, Construction Manufacturing" class="himg" >
																<?php }?>
								                            <?php }else{?>
		                                                            <?php if ($id =="4"){?>
										                                <img src="<?php echo base_url('vender\images\book/industries.png');?>" alt="Industrial Automation" class="himg" >
																<?php }else if($id =="78"){?>
																		<img src="<?php echo base_url('vender\images\book/medicine.png');?>" alt="sports" class="himg" >
																<?php }else if($id =="3"){?>
																		<img src="<?php echo base_url('vender\images\book/food.png');?>" alt="Food & Beverage" class="himg" >
																<?php }else if($id =="76"){?>
																		<img src="<?php echo base_url();?>vender\images\book/chemistry.png" alt="Chemicals & Materials" class="himg" >
																<?php }else if($id =="75"){?>
																		<img src="<?php echo base_url('vender\images\book/transport.png');?>" alt="Automotive & Transportation" class="himg" >
																<?php }else if($id =="1"){?>
																		<img src="<?php echo base_url('vender\images\book/electronic.png');?>" alt="Electronics & Semiconductor" class="himg" >
																<?php }else if($id =="77"){?>
																		<img src="<?php echo base_url('vender\images\book/medicine.png');?>" alt="Healthcare, Pharmaceuticals & Medical Devices" class="himg" >
																<?php }else if($id =="2"){?>
																		<img src="<?php echo base_url('vender\images\book/retail.png');?>" alt="Retail & Consumer Goods" class="himg" >
																<?php }else if($id =="79"){?>
																		<img src="<?php echo base_url('vender\images\book/defencce.png');?>" alt="Aerospace and Defense" class="himg" >
																<?php }else if($id =="80"){?>
																		<img src="<?php echo base_url('vender\images\book/constuction.png');?>" alt="Building, Construction Manufacturing" class="himg" >
																<?php }?>
				                                            <?php }?>
				                                        </a>
													</div>

												</div>

												<div class="col-md-9">

													<div class="heading-box">

														<div class="row form-group">

															<a href="<?php echo base_url('website/');?>report_info/<?php echo $row['id'];?>">
																<p><?php echo $row['reportname'];?></p>
															</a>

														</div>

														<div class="row form-group" style="border-top:none;padding: 15px;margin-top:0;background: #fff;">

															<!-- <div class="col-md-12">

																<div class="row">

																	<label class="heading-label">Publisher Name</label>											

																	<label class="txt-lbl">

																		<?php //echo $row['publisher_name'];?>

																	</label>

																</div>

															</div> -->

															

															<div class="col-md-12">

																<div class="row">

																	<label class="heading-label">Publishing Date </label>

																	<label class="tiny txt-lbl">

																		<?php   
																		$date=date_create($row['publisher_date']);
																				echo date_format($date,"M - Y");
																		?>
																	</label>

																</div>



																<div class="row">

																	<label class="heading-label">Report Format</label>

																	<label class="txt-lbl pdf">

																		<i class="far fa-file-pdf" aria-hidden="true"></i> Available in PDF.

																	</label>

																</div>

															</div>



															<!-- <div class="col-md-12">

																<div class="row">

																	<label class="heading-label">Price</label>

																	<label class="tiny txt-lbl">

																		<?php //echo $row['price'];?>

																	</label>

																</div>

															</div> -->											

															

														</div>

													</div>

												</div>

											</div>	

										
											<div class="row">

												<div class="col-md-12 xs-btns text-center">

													<a href="<?php echo base_url('website/');?>enquery/<?php echo $row['id']; ?>" class="btn btn-info">

														Sample Report

													</a>
                                                   
    													<a class="btn btn-warning" id="cart<?php echo $row['id'];?>" style="cursor: pointer;" data-value="$row['id'];?>">
    
    														Add to Cart

    														<span class="tool-tip" id="toolTip<?php echo $row['id'];?>" style="display:none;">Added To cart </span>
    
    													</a>
    												
													<script type="text/javascript">

														$('#cart<?php echo $row['id'];?>').on('click',function(){

															$.ajax({

														            type: "POST",

														            data: {id:'<?php echo $row["id"];?>'},

														            url: "<?php echo base_url('website/')."addcart";?>",

														            success: function(data){											               

														                if(data == 'error'){

														                	console.log('error')

														                }else{

														                	$('.cart-item').text(data);
														                	$("#toolTip<?php echo $row['id'];?>").fadeIn(200);
														                	$("#toolTip<?php echo $row['id'];?>").fadeOut(1600);

														                }											              

														            }

														     })

														})
													</script>

													<label class="btn btn-compair">	

														<input type="checkbox" class="btn-get-id" value="<?php echo $row['id'] ?>" name="id[]" id="btn<?php echo $row['id'];?>"> &nbsp;Add to compare														

													</label>

													<script type="text/javascript">															
														$('#btn<?php echo $row['id'];?>').on('click',function () {      
													        var id = [];
													        if($(this). prop("checked") == true){
													            var id = $(this).val();
													            $("#myNavbar ul #hide").removeClass('hide');			
													            $("#hide #compareForm").append("<input type='hidden' name='id[]' value='"+id+"' id='input<?php echo $row['id'];?>'>");						           
													        }else{
													            $("#myNavbar ul #hide").addClass('hide');
													            $("#hide #compareForm").find("#input<?php echo $row['id'];?>").remove();	
													        }
													    });	  
												    </script>

													

													<!-- <a href="<?php //echo base_url('website/');?>buyNow/<?php //echo $row['id']; ?>" class="btn btn-danger">

														Buy Now

													</a> -->

												</div>

											</div>						

										</div>
							<?php   }

	                  			}else{

	                  				echo "<h2> NO ANY RECORD</h2>";

	                  			}
							?>
				</div><!-- COL_MD_8 CLOSED -->
			</div>
     	</div>
    </div>
</div>

    <!-- BODY CLOSE -->

<?php include('includedItems/footer.php');?>



<?php 
/**/
?>