<?php include('includedItems/headers.php');?>	

<!-- BODY WORK START -->
<style type="text/css">
	.nav > li > a{
		padding: 4px 6px;
		font-size: 10px;
	}
	.table th, .table td{
		font-size: 10px;
	}
	.nav-tabs > li.active > a, .nav-tabs > li.active > a:hover, .nav-tabs > li.active > a:focus{
	    color: #fff;
    cursor: default;
    background-color: #70b5f7;
    border: 1px solid #70b5f7;
	}
</style>

<?php include('includedItems/navigation.php');?>

<?php //include('includedItems/slides.php');?>

 <div class="container-fluid">

	<div class="row">

		<div class="research-bg-section">

			<div class="headigs">

				<h3 class="testimonials-heading"><?php echo ucfirst($title); ;?></h3>

			</div>

		</div>

	</div>

</div>


<div class="container">
        	
	<div class="row">

		<div class="col-md-12" style="">
			<ul class="nav nav-tabs">
				<?php   $active = '';
						$sr = $sr1 =  0;
					    foreach($skillNav as $li){
					    	if($sr == 0){
					    		$active = 'active';
					    	}else{
					    		$active = '';
					    	}?>
						  	<li class="<?php echo $active;?>">
						  		<a data-toggle="tab" href="#li<?php echo $li['id'];?>"><?php echo ucwords($li['title']);?></a>
						  	</li>						  
				<?php $sr++;}?>
			</ul>

			<div class="tab-content">
				<?php   foreach ($skillNav as $value) {
						if($sr1 == 0){
				    		$active = 'in active';
				    	}else{
				    		$active = '';
				    	}?>
							<div id="li<?php echo $value['id'];?>" class="tab-pane fade  <?php echo $active;?>">
							    <h3><?php echo $value['title'];?></h3>
							    <table class="table table-hover">
							    	<tr>
							    		<th>Report Name</th>
							    		<th>Short Description</th>							    		
							    		<th>Publisher Name</th>
							    		<th>Publishing Date</th>
							    		<th>Report ID</th>
							    		<th>CAGR</th>	
							    		<th>Price</th>						    								    		
							    	</tr>
								    <?php foreach($slideData as $sd){
								    		if($value['id'] == $sd['category'] && $sd['status'] == 'Approve'){?>
								    			<tr>
										    		<td>
										    			<a href="<?php echo base_url('website/enquery/'.$sd['id']);?>" class="prime-link">
										    				<?php echo $sd['reportname'];?>		    				
										    			</a>
										    		</td>

										    		<td>
										    			<a href="<?php echo base_url('website/enquery/'.$sd['id']);?>" class="prime-link">
										    				<?php echo substr($sd['reportdesc'],0,50).' ....';?>
										    			</a>
										    		</td>
										    		
										    		<td>
										    			<a href="<?php echo base_url('website/enquery/'.$sd['id']);?>" class="prime-link">
										    				<?php echo $sd['publisher_name'];?>
										    			</a>
										    		</td>

										    		<td>
										    			<a href="<?php echo base_url('website/enquery/'.$sd['id']);?>" class="prime-link">
										    				<?php echo $sd['publisher_date'];?>
										    			</a>
										    		</td>

										    		<td>
										    			<a href="<?php echo base_url('website/enquery/'.$sd['id']);?>" class="prime-link">
										    				<?php echo $sd['report_id'];?>
										    			</a>
										    		</td>
										    		<td>
										    			<a href="<?php echo base_url('website/enquery/'.$sd['id']);?>" class="prime-link">
										    				<?php echo $sd['report_cagr'];?>
										    			</a>
										    		</td>

										    		<td>
										    			<a href="<?php echo base_url('website/enquery/'.$sd['id']);?>" class="prime-link">
										    				<?php echo $sd['price'];?>
										    			</a>
										    		</td>	    		
										    	</tr>
								    <?php 	}
								    }?>
							    </table>
							</div>
				<?php   $sr1++;}?>
				
		</div>

	</div>

</div>
