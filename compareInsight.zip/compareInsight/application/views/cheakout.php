<?php include('includedItems/headers.php');?>

    <!-- BODY WORK START -->

        <?php include('includedItems/navigation.php');?>

       
 <?php include('includedItems/cheakoutcss.php');?>

 <div class="container-fluid">

            <div class="row">

                <div class="research-bg-section">

                    <div class="headigs">

                        <h3 class="testimonials-heading"><?php echo ucfirst($title); ;?></h3>

                    </div>

                </div>

            </div>

        </div>
<h1><center><b style="
    color: #ccda63;
">Cheakout Process</b></center></h1><br>

<div class="container wrapper">
          
    <div class="row cart-body">                
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 col-md-push-6 col-sm-push-6">
            <!--REVIEW ORDER-->
            <div class="panel panel-info">
                <div class="panel-heading">
                    Review Order <div class="pull-right"><small><a class="afix-1" href="#"></a></small></div>
                </div>
                <div class="panel-body">
                    <?php   $i=1;
                            $total = array();
                            foreach ($cartItem as $row){ ?>
                                <div class="row form-group">                              
                                    <div class="col-sm-9 col-xs-9">
                                        
                                            <div class="col-xs-12 small">
                                                <a href="">
                                                    <?php echo $row['reportname'];?>
                                                </a>
                                            </div>
                                       
                                    </div>
                                    <div class="col-sm-3 col-xs-3 text-right">
                                        <h6><span style="color: #f07474; font-weight: bold;"><?php echo $row['reportPrice'];?></span></h6>
                                    </div>                               
                                </div>
                                <div class="form-group"><hr /></div>
                    <?php array_push($total,$row['reportPrice']);
                          $i++;
                    }?>
                    
                   
                    
                    <div class="row form-group">
                        <div class="col-xs-12">
                            <strong> Order Total</strong>
                            <div class="pull-right">
                                <span style="color: #54b1ff; font-weight: bold;"> <?php 
                                                $t=(array_sum($total));
                                                echo $t;
                                        ?>                                      
                                </span>
                            </div>
                        </div>
                    
                    </div>
                </div>
            </div> <!--REVIEW ORDER END-->
        </div>
         






    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 col-md-pull-6 col-sm-pull-6">
        <!--SHIPPING METHOD-->
        <form class="form-horizontal" method="post" action="<?php echo base_url();?>index.php/website/insertpriuser" style="margin-bottom: 30px;">
            <div class="panel panel-info">
                <div class="panel-heading">Address</div>
                <div class="panel-body">
                    <div class="form-group">
                        <div class="col-md-12">
                            <h4>Shipping Address</h4>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12"><strong>Country:</strong></div>
                        <div class="col-md-12">
                            <input type="text" class="form-control" name="country" value="" / required>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-6 col-xs-12">
                            <strong>First Name:</strong>
                            <input type="text" name="first_name" class="form-control" value="" / required>
                        </div>
                        <div class="span1"></div>
                        <div class="col-md-6 col-xs-12">
                            <strong>Last Name:</strong>
                            <input type="text" name="last_name" class="form-control" value="" / required>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12"><strong>Address:</strong></div>
                        <div class="col-md-12">
                            <input type="text" name="address" class="form-control" value="" / required>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12"><strong>City:</strong></div>
                        <div class="col-md-12">
                            <input type="text" name="city" class="form-control" value="" / required>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12"><strong>State:</strong></div>
                        <div class="col-md-12">
                            <input type="text" name="state" class="form-control" value="" / required>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12"><strong>Zip / Postal Code:</strong></div>
                        <div class="col-md-12">
                            <input type="text" name="zip_code" class="form-control" value="" / required placeholder="111111" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12"><strong>Phone Number:</strong></div>
                        <div class="col-md-12"><input type="text" name="phone_number" class="form-control" value="" / required oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="15" placeholder="0091 9999999999"></div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12"><strong>Email Address:</strong></div>
                        <div class="col-md-12"><input type="email" name="email_address" class="form-control" value="" / required></div>
                    </div>
                    
                </div>
            </div>
            
            <!--CREDIT CART PAYMENT END-->
         <button type="submit" class ="btn btn-info" name="submit">Proceed To Pay</button>
         <br>
        </form>
    </div>
        


       
    </div>              
    </div>
       

<?php include('includedItems/footer.php');?>

