<?php
defined('BASEPATH') OR exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, OPTIONS");
class Website extends CI_Controller {
    
    /**
	 * Company Name   : COSCODE SOLUTIONS.
	 * Developer Name : Rohit Mishra
	 * Development URL: https://www.coscode.com/onlineexamination
	 * Copyright Under COSCODE SOLUTIONS PVT LTD. 
	 * Development Contry : Nepal Butwal
	 */

	public function __construct(){
		parent::__construct();		
		$this->load->helper(array('url','form'));
		$this->load->model('WebModal');
		$this->load->helper('ipfilter');
		$this->load->library('pagination');
	}  
	
	public function get_client_ip (){
	    return getHostByName(getHostName());
	}

    public function index(){
    	$data['success']   = $this->session->flashdata('success');
    	$data['title']     = 'Home Page';  
    	$data['slideData'] = $this->WebModal->getAllSliderData();
    	$data['skillNav']  = $this->WebModal->getNavData();
    	$ip = get_client_ip();
    	$data['cart']      = $this->WebModal->cartCount($ip);
    	$this->load->view('home',$data);
	}
	
	public function allReports(){
	    $data['title']     = 'All Reports';  
    	$data['slideData'] = $this->WebModal->getAllSliderData();
    	$data['skillNav']  = $this->WebModal->getNavData();
    	$ip = get_client_ip();
    	$data['cart']      = $this->WebModal->cartCount($ip);
    	$this->load->view('all_reports',$data);
	}

	public function research(){
		$ip = get_client_ip();
		$data['title'] = "Research Industries";
		$id    = '';
		if($this->uri->segment(4)){			
			$reports           = $this->WebModal->getIdRelatedReportDataForReport($this->uri->segment(3));
			if(!empty($reports)){
			    $id                = $reports[0]['category']; 
			    $data['id']        = $id;
			}else{
				$data['id']            = $this->uri->segment(3);
			}
		}else{ 
			$id                = $this->uri->segment(3);
			$reports           = $this->WebModal->getIdRelatedReportData($this->uri->segment(3));
			if(!empty($reports)){
			    $id                = $reports[0]['category']; 
			    $data['id']        = $id;
			}else{
				$data['id']            = $this->uri->segment(3);
			}
			
		}
		
		$data['reports']   = $reports;
			

		$data['slideData'] = $this->WebModal->getAllSliderData();
    	$data['skillNav']  = $this->WebModal->getNavData();
    	$data['cart']      = $this->WebModal->cartCount($ip);
		$data['data']      = $this->WebModal->GetAllIdRelatedSkillData($id);
		$data['report_id'] = $id;
		$this->load->view('research',$data);
	}
	
	public function report_info(){
	    $data['title'] = "Research Industries";
	    $id = $this->uri->segment(3);
	    $ip = get_client_ip();
	    $data['reportInfo'] = $this->WebModal->getReportById($id);
	    $data['slideData']  = $this->WebModal->getAllSliderData();
    	$data['skillNav']   = $this->WebModal->getNavData();
    	$data['cart']       = $this->WebModal->cartCount($ip);
		$data['data']       = $this->WebModal->GetAllIdRelatedSkillData($id);
		$data['r_id']       = $id;
		$data['id']         = $data['reportInfo'][0]['category'];
		$this->load->view('research_info',$data);
	}


	public function getLiveSearch(){
		$txt = $this->input->post('data');
		$sql = $this->WebModal->getNavDataByTXT($txt);		
		if (count($sql) > 0) {
		  foreach($sql as $row) { 
		    echo '<a href="'.base_url('website/research/').$row['id'].'/search" data-value="'.$row['id'].'"style="cursor:pointer;">'.$row['reportname'].'</a>';
		  }
		}
	}

	public function getLiveSearchMenu(){
		$txt = $this->input->post('searchTxt');
		$id  = $this->input->post('searchId');
		$sql = $this->WebModal->getSearchReletedDataByIdOrTXT($id,$txt);

		if(count($sql) > 0){		
			echo'<div class="container">

		    		<div class="row form-group" style="margin-top:50px;">
		    			<h2 class="heading text-center">
							<span class="black-heads">Search</span><span class="gold-head"> Results</span>
						</h2>
		    		</div>

		    		<div class="row form-group" style="margin-top:50px;">
		    			<div class="col-md-12">
							<div class="table-responcive">
								<table class="table table-striped table-bordered">
									<tr>
										<th>Sr. No.</th>
										<th>Book Title</th>
										<th>Author</th>
										<th>Price</th>
										<th>Uploed On</th>
									</tr>';
									$i=1;
										foreach($sql as $row) {
										
										echo'<tr>
												<td>'.$i.'</th>
												<td><a href="'.base_url('website/').'research/'.$row['id'].'/search">'.$row['reportname'].'</a></td>
												<td>'.$row['publisher_name'].'</td>
												<td>'.$row['price'].'</td>
												<td>'.$row['publisher_date'].'</td>
											</tr>';
											$i++;
										}
											
							   echo'</table>
							</div>
						</div>
		    		</div>
		        </div>';
		
		}else{
			echo "<h2> No any Record Found </h2>";
		}	

	}

	public function enquery(){
		$data['title'] = "Research Industries";

		$data['slideData'] = $this->WebModal->getAllSliderData();
    	$data['skillNav']  = $this->WebModal->getNavData();
    	$ip = get_client_ip();
    	$data['cart']      = $this->WebModal->cartCount($ip);

		$data['report_id'] = $this->uri->segment(3);

		$this->load->view('enquery',$data);
	}

	public function mailEnquery(){
		$name    = $this->input->post('name');
		$cname   = $this->input->post('email');
		$email   = $this->input->post('company');
		$country = $this->input->post('country');
		$message = $this->input->post('msg');
		$phone   = $this->input->post('phone');
		$r_id    = $this->input->post('report_id');
		
		
		$getReportDetail = $this->WebModal->get_reportDetail_byID($r_id);
		
		
		if(!$this->input->post('from')){
		    $this->data['data'] = '<h2>Hi Admin!,</h2>
            			 <p>You Have New <strong>Report Enquery</strong>  Today at '.date("H:i:s").'.</p>
            			 <p style="margin-top:30px;"> <b>Report Name : '.$getReportDetail[0]['reportname'].'</b></p>
            			 <p style="margin-top:30px;"> <b>Details Are : </b></p>
            			 <p style="margin-top:30px;">Company Name : <b>'.$cname.'</b> <br/> Name : <b>'.$name.'</b> <br/> Email :  <b>'.$email.'</b> <br/> Country : <b>'.$country.'</b> Contact Number :<b> '.$phone.'</b><br/> Message : '.$message.'</p>';

		}else{
		    $this->data['data'] = '<h2>Hi Admin!,</h2>
            			 <p>You Have New <strong>enquery for '.$this->input->post('from').'</strong>  Today at '.date("H:i:s").'.</p>
            			 <p style="margin-top:30px;"> <b>Report Name : '.$getReportDetail[0]['reportname'].'</b></p>
            			 <p style="margin-top:30px;"> <b>Details Are : </b></p>
            			 <p style="margin-top:30px;">Company Name : <b>'.$cname.'</b> <br/> Name : <b>'.$name.'</b> <br/> Email :  <b>'.$email.'</b> <br/> Country : <b>'.$country.'</b> Contact Number :<b> '.$phone.'</b><br/> Message : '.$message.'</p>';

		}

		
		
		
        
		$this->load->library('email');
        
	    $msg =  $this->load->view('admin/emailTemp',$this->data,true);
			
			 // Send Email to administrator For Alert Of New Report Submittion
    			$this->load->library('email');
                $this->email->from($email, 'noreply@coscode.com');
                $this->email->to('rmrockingrohit@gmail.com');
                
                $this->email->set_header('MIME-Version', '1.0; charset=utf-8');
                $this->email->set_header('Content-type', 'text/html');

                $this->email->subject('Contact Us Enquery');
                $this->email->message($msg);

		if($this->email->send()){
			echo 'success';
		}else{
			echo 'failed';
		}
		
		
	}

	public function services(){
		$data['title'] ="Service";

		$data['slideData'] = $this->WebModal->getAllSliderData();
    	$data['skillNav']  = $this->WebModal->getNavData();
    	$ip = get_client_ip();
    	$data['cart']      = $this->WebModal->cartCount($ip);

    	$this->load->view('services',$data);
	}

	public function about(){
		$data['title'] = "About";

		$data['slideData'] = $this->WebModal->getAllSliderData();
    	$data['skillNav']  = $this->WebModal->getNavData();
    	$ip = get_client_ip();
    	$data['cart']      = $this->WebModal->cartCount($ip);

    	$this->load->view('about',$data);
	}
	public function lifeScience(){
		$data['title'] = "Industries news";

		$data['slideData'] = $this->WebModal->getAllSliderData();
    	$data['skillNav']  = $this->WebModal->getNavData();
    	$ip = get_client_ip();
    	$data['cart']      = $this->WebModal->cartCount($ip);

    	$this->load->view('lifeScience',$data);
	}

	public function automotive(){
		$data['title'] = "Industries news";

		$data['slideData'] = $this->WebModal->getAllSliderData();
    	$data['skillNav']  = $this->WebModal->getNavData();
    	$ip = get_client_ip();
    	$data['cart']      = $this->WebModal->cartCount($ip);

    	$this->load->view('automotive',$data);
	}

	public function semiconductor(){
		$data['title'] = "Industries news";

		$data['slideData'] = $this->WebModal->getAllSliderData();
    	$data['skillNav']  = $this->WebModal->getNavData();
    	$ip = get_client_ip();
    	$data['cart']      = $this->WebModal->cartCount($ip);

    	$this->load->view('semiconductor',$data);
	}

	public function publisherlist(){

		$data['title'] = "Publisher list";

		$data['slideData'] = $this->WebModal->getAllSliderData();
    	$data['skillNav']  = $this->WebModal->getNavData();
    	$ip = get_client_ip();
    	$data['cart']   = $this->WebModal->cartCount($ip);
    	$data["data"]   = $this->WebModal->getAllPublisherName();      
    	$this->load->view('publisherlist',$data);
	}

	public function publisherDetail(){

		$data['title'] = "Publisher list";
		$pub_name      = $this->uri->segment(3);

		$explode = explode('%20',$pub_name);
		$implode = implode(' ',$explode);

		$data['slideData'] = $this->WebModal->getAllSliderData();
    	$data['skillNav']  = $this->WebModal->getNavData();
    	$ip = get_client_ip();
    	$data['cart']   = $this->WebModal->cartCount($ip);

    	$data["data"]   = $this->WebModal->getAllPublisherReportsBYBuplisherName($implode); 
    
    	$this->load->view('publisher_report',$data);
	}

	public function customResearch(){
		$data['title'] = 'Custom Research';

		$data['slideData'] = $this->WebModal->getAllSliderData();
    	$data['skillNav']  = $this->WebModal->getNavData();
    	$ip = get_client_ip();
    	$data['cart']   = $this->WebModal->cartCount($ip);

    	$this->load->view('full-width',$data);
	}

	public function contact(){
		$data['title'] = 'Contact';

		$data['slideData'] = $this->WebModal->getAllSliderData();
    	$data['skillNav']  = $this->WebModal->getNavData();
    	$ip = get_client_ip();
    	$data['cart']   = $this->WebModal->cartCount($ip);

    	$this->load->view('contact',$data);
	}
		public function terms(){
		$data['title'] = 'Terms';

		$data['slideData'] = $this->WebModal->getAllSliderData();
    	$data['skillNav']  = $this->WebModal->getNavData();
    	$ip = get_client_ip();
    	$data['cart']   = $this->WebModal->cartCount($ip);

    	$this->load->view('terms',$data);
	}
	public function privacy(){
		$data['title'] = 'Privacy';

		$data['slideData'] = $this->WebModal->getAllSliderData();
    	$data['skillNav']  = $this->WebModal->getNavData();
    	$ip = get_client_ip();
    	$data['cart']   = $this->WebModal->cartCount($ip);

    	$this->load->view('privacy',$data);
	}
		public function faq(){
		$data['title'] = 'Faq';

		$data['slideData'] = $this->WebModal->getAllSliderData();
    	$data['skillNav']  = $this->WebModal->getNavData();
    	$ip = get_client_ip();
    	$data['cart']   = $this->WebModal->cartCount($ip);

    	$this->load->view('faq',$data);
	}

	public function contactMail(){
		$name    = $this->input->post('name');		
		$email   = $this->input->post('email');		
		$message = $this->input->post('msg');	
		$this->data['data'] = '<h2>Hi Admin!,</h2>
            			 <p>You Have New <strong>Contact Us</strong> Enquery Today at '.date("H:i:s").'.</p>
            			 <p style="margin-top:30px;"> <b>Details Are : </b></p>
            			 <p style="margin-top:30px;">Name : <b>'.$name.'</b> <br/> Email :  <b>'.$email.'</b> <br/> Message : '.$message.'</p>';

	    $msg =  $this->load->view('admin/emailTemp',$this->data,true);
			
			 // Send Email to administrator For Alert Of New Report Submittion
    			$this->load->library('email');
                $this->email->from($email, 'Sales@compareinsights.com');
                $this->email->to('Queries@compareinsights.com');
                
                $this->email->set_header('MIME-Version', '1.0; charset=utf-8');
                $this->email->set_header('Content-type', 'text/html');

                $this->email->subject('Contact Us Enquery');
                $this->email->message($msg);

		if($this->email->send()){
			echo 'success';
		}else{
			echo 'failed';
		}
	}

	public function addcart(){
		$report_id = $this->input->post('id');
		$count = '';	
		// If Not logged
			$ip    = get_client_ip();
			$query = $this->WebModal->addCartByIp($report_id,$ip);
			if($query){				
		  		$countQuery = $this->WebModal->getCartItemCount($ip);
		  		$count      .= count($countQuery);
		  		echo $count;
			}else{
			return "error";
		}
	}

	public function buyNow(){
		$data['title']     = "Buy Item";
	  	$data['reportId'] = $this->uri->segment(3);

	  	$data['slideData'] = $this->WebModal->getAllSliderData();
    	$data['skillNav']  = $this->WebModal->getNavData();
    	$ip = get_client_ip();
    	$data['cart']   = $this->WebModal->cartCount($ip);
    	$data['buyItem'] = $this->WebModal->getBuyItemData($data['reportId']);    	
    	$this->load->view('cartItems1',$data);
	}

	public function buyNotify(){
		$name 		= $this->input->post('name');
		$email 		= $this->input->post('email');
		$address 	= $this->input->post('address');
		$city		= $this->input->post('city');
		$state 		= $this->input->post('state');
		$zip 		= $this->input->post('zip');
		$nameOnCard = $this->input->post('nameOnCard');
		$cardNumber = $this->input->post('cardNumber');
		$expMonth 	= $this->input->post('expMonth');
		$expYear 	= $this->input->post('expYear');
		$cvv 		= $this->input->post('cvv');
		$product    = $this->input->post('product');

		$getProduct = $this->WebModal->get_reportDetail_byID($product);

		$this->load->library('email');

		$this->email->from($email, 'Sales@compareinsights.com');
		$this->email->to('Queries@compareinsights.com');
		/*$this->email->cc('another@another-example.com');
		$this->email->bcc('them@their-example.com');*/

		$this->email->subject('Intrested To Buy Report = "<strong>'.$getProduct[0]['reportname'].'</strong>"."');
		$this->email->message('Hi User!, You have New Buyer Mail .\r\n Details are: \r\n name = '.$name.'\r\n email ='.$email.'\r\n Address = '.$address.'.\r\n City = '.$city.'\r\n State = '.$state.'\r\n Postal Code = '.$zip.'\r\n card Number = '.$cardNumber.' \r\n Card Holder Name = '.$nameOnCard.'\r\n Card Exp. Month = '.$expMonth.'\r\n Card Exp. Year = '.$expYear.'\r\n CVV No. = '.$cvv.'\r\n . Please Contact To The Buyer And Confirm Your Booking.' );

		if($this->email->send()){
			echo 'success';
		}else{
			echo 'failed';
		}

	}

	public function checkout_process(){
		$reportID          = $this->input->post('reportID');
		$buyItem           = array();
		$data['module']    = $this->input->post('checkbox');

		$data['title']     = "Buy Item";
	  	$data['reportId']  = $this->uri->segment(3);

	  	$data['slideData'] = $this->WebModal->getAllSliderData();
    	$data['skillNav']  = $this->WebModal->getNavData();

    	$ip 			   = get_client_ip();
    	$data['cart']      = $this->WebModal->cartCount($ip);
    	if (is_array($reportID)){

    		foreach($reportID as $id){
    			$items = $this->WebModal->getBuyItemData($id);
    			array_push($buyItem, $items[0]);
    		}

    		$data['buyItems'] = $buyItem;

    	}else{
    		$data['buyItem']   = $this->WebModal->getBuyItemData($reportID); 
    	}

    	$this->load->view('booking_report',$data);
	}

	/*public function cartItems(){
		$data['title']     = "Cart Items";
	  	$data['reportId'] = $this->uri->segment(3);

	  	$data['slideData'] = $this->WebModal->getAllSliderData();
    	$data['skillNav']  = $this->WebModal->getNavData();
    	$ip = get_client_ip();
    	$data['cart']   = $this->WebModal->cartCount($ip);
    	$data['cartItem']= $this->WebModal->getCartItems($ip);
    	$this->load->view('cartItems',$data);
	}*/


	public function cartItems1(){
		$data['title']     = "Cart Items";
	  	$data['reportId'] = $this->uri->segment(3);

	  	$data['slideData'] = $this->WebModal->getAllSliderData();
    	$data['skillNav']  = $this->WebModal->getNavData();
    	$ip = get_client_ip();
    	$data['cart']   = $this->WebModal->cartCount($ip);
    	$data['cartItem']= $this->WebModal->getCartItems($ip);
    	
    	$this->load->view('cartItems1',$data);
	}



	public function cheakout(){
		$data['title']     = "Cart Items";
	  	$data['reportId'] = $this->uri->segment(3);

	  	$data['slideData'] = $this->WebModal->getAllSliderData();
    	$data['skillNav']  = $this->WebModal->getNavData();
    	$ip = get_client_ip();
    	$data['cart']   = $this->WebModal->cartCount($ip);
    	$data['cartItem']= $this->WebModal->getCartItems($ip);	  	
    	//$this->load->view('booking_report',$data);
    	$this->load->view('cheakout',$data);
	}




	public function cartSale(){
		$ip   = get_client_ip();
		$rows = $this->WebModal->getCartItems($ip);

		$email  = $this->input->post('email');
		$phone  = $this->input->post('phone');

		$sum = array();
		$reports = '';
		$this->load->library('email');
		$this->email->from($email, 'Sales@compareinsights.com');
		$this->email->to('Queries@compareinsights.com');
		$txt = '<table>
					<tr>
						<th>Sr. No.</td>
						<th>Report Name</td>
						<th>Author Name</td>
						<th>Price</td>
					</tr>';
					$i=1;
	            foreach($rows as $row){
			    $txt .= '<tr>
			    			<td>'.$i.'</td>
			    			<td>'.$row['reportname'].'</td>
			    			<td>'.$row['publisher_name'].'</td>
			    			<td>'.$row['price'].'</td>
			    		</tr>';
	            $i++;
	            array_push($sum,$row['price']);
	            $reports .= '"'.$row['reportname'].'" - ';
	            }
			    $txt .= '<tr>
			    			<td></td>
			    			<td></td>
			    			<td>Total Payout</td>
			    			<td>'.array_sum($sum).'</td>
			    		</tr>
				</table>';				

		$this->email->subject('Buyer Ready to Buy These Reports');
		$this->email->message($txt);
		$this->email->cc($email);
		if($this->email->send()){
			$deleteCart = $this->WebModal->deleteCart($ip);
			echo 'success';
		}else{
			echo 'failed';
		}
	}

	public function resetCart(){
		$ip   = get_client_ip();
		$reset = $this->WebModal->resetCartItems($ip);
		if($reset){
			redirect("website");
		}
	}
    
   public function compare(){
    	$reports = array();
	    $id = $this->input->post('id');
	    foreach($id as $row){
	    	$get = $this->WebModal->getCompareReportByID($row);
	    	array_push($reports,$get);
	    }
	    $data['title'] = "Compare Report";
	    $data['report'] = $reports;
		$data['slideData'] = $this->WebModal->getAllSliderData();
    	$data['skillNav']  = $this->WebModal->getNavData();
    	$ip = get_client_ip();
    	$data['cart']   = $this->WebModal->cartCount($ip); 
    	$data['report_id'] = $this->input->post('report_id');
    	$this->load->view('compare',$data);
	}






	public function add(){
		
		$this->load->view('includedItems/headers');
		$this->load->view('cheakout');
		$this->load->view('includedItems/footer');
		}
	public function insertpriuser(){
	    $this->load->model('Primusermodel');
	    
        $country       = $_POST["country"];
        $first_name    = $_POST["first_name"];
        $last_name     = $_POST["last_name"];
        $address       = $_POST["address"];
        $city          = $_POST["city"];
        $state         = $_POST["state"];
        $zip_code      = $_POST["zip_code"];
        $email_address = $_POST["email_address"];
        $phone_number  = $_POST["phone_number"];
		
		$save = $this->WebModal->saveTransactionData($country,$first_name,$last_name,$address,$city,$state,$zip_code,$email_address,$phone_number);
		if($save){
			$ip = get_client_ip();
	    	$cartData = $this->WebModal->getCartItems($ip);	    	
	    	$setCart  = $this->WebModal->setSaleCart($cartData,$save);
	    	if($setCart){
	    		$deleteTempCart = $this->WebModal->deleteTempCartDataBYIP($ip);
	    		if($deleteTempCart){
	    			$this->session->set_flashdata('success','success');
	    			redirect(base_url('Website'));
	    		}
	    	}
		}
		
		
	}

	public function transaction(){
		$this->load->model('Primusermodel');
	    
        $country       = $_POST["country"];
        $first_name    = $_POST["first_name"];
        $last_name     = $_POST["last_name"];
        $address       = $_POST["address"];
        $city          = $_POST["city"];
        $state         = $_POST["state"];
        $zip_code      = $_POST["zip_code"];
        $email_address = $_POST["email_address"];
        $phone_number  = $_POST["phone_number"];
        $reportId      = $_POST['reportId'];
        $price         = $_POST['price'];
        $reportname    = $this->input->post('reportName');
        $reportType    = $this->input->post('reportType');
        $ip            = get_client_ip();;

        if(!is_array($reportname)){
        	
			$save = $this->WebModal->saveTransactionData($country,$first_name,$last_name,$address,$city,$state,$zip_code,$email_address,$phone_number);
			if($save){		
				$cartData    = array(
			        					'report_ID'      => $reportId,
			        					'report_price'   => $price,
			        					'tr_ID'          => $save    					
	        				        );	  	
		    	$setCart     = $this->WebModal->setSaleCartBuy($cartData);
		    	$delete_cart = $this->WebModal->deleteTempCartDataBYIP($ip);

		    	if($setCart){
		    		$name = $first_name.' '.$last_name;
		    		//$this->send_mail($name,$sendTo,$senderBy,$reportName,$reportType,$reportPrice);
		    		$txt = '<table>
						<tr>						
							<th>Report Name</td>
							<th>Licence</td>
							<th>Price</td>
						</tr>';
					$txt .= '<tr>			    			
				    			<td>'.$reportname.'</td>
				    			<td>'.$reportType.'</td>
				    			<td>'.$price.'</td>
				    		</tr>';


				   	$this->load->library('email');
					$this->email->from($email_address, $name);
					$this->email->to('sales@compareinsights.com');
				    $this->email->subject('Buyer Ready to Buy These Reports');
					$this->email->message($txt);

					if($this->email->send()){
						$txtUser = "<h4> Thank You For Purchasing With Us. Your Request Has been Submited to Us . We Will Connect You With In 24 Hours. Here Is your Request Summery - </h4>";
						$txtUser .= '<table>
										<tr>						
											<th>Report Name</td>
											<th>Licence</td>
											<th>Price</td>
										</tr>
										<tr>			    			
							    			<td>'.$reportname.'</td>
							    			<td>'.$reportType.'</td>
							    			<td>'.$price.'</td>
							    		</tr>';
						$this->email->from('query@compareinsights.com','Compare Insight');
						$this->email->to($email_address);
					    $this->email->subject('Report Purchase Confirmination');
						$this->email->message($txtUser);
						$this->email->send();				
					}

		    		$this->session->set_flashdata('success','success');
		    		redirect(base_url('Website'));
		    	}
			}
		}else{
			
			for($i=0;$i<count($reportname);$i++){
				$save = $this->WebModal->saveTransactionData($country,$first_name,$last_name,$address,$city,$state,$zip_code,$email_address,$phone_number);
				if($save){		
					$cartData    = array(
				        					'report_ID'      => $reportId[$i],
				        					'report_price'   => $price,
				        					'tr_ID'          => $save    					
		        				        );

			    	$setCart     = $this->WebModal->setSaleCartBuy($cartData);
			    	$delete_cart = $this->WebModal->deleteTempCartDataBYIP($ip);

			    	$txtUser = "<h4> Thank You For Purchasing With Us. Your Request Has been Submited to Us . We Will Connect You With In 24 Hours. Here Is your Request Summery - </h4>";
				}
			}

    		$name = $first_name.' '.$last_name;
    		//$this->send_mail($name,$sendTo,$senderBy,$reportName,$reportType,$reportPrice);
    		$txt = '<table>
						<tr>						
							<th>Report Name</td>
							<th>Licence</td>
							<th>Price</td>
						</tr>';
			for($i=0;$i<count($reportName);$i++){
				$txt .= '<tr>			    			
			    			<td>'.$reportname[$i].'</td>
			    			<td>'.$reportType.'</td>
			    			<td>'.$price.'</td>
			    		</tr>';
		    }
		    $txt .= '</table>';

		   	$this->load->library('email');
			$this->email->from($email_address, $name);
			$this->email->to('sales@compareinsights.com');
		    $this->email->subject('Buyer Ready to Buy These Reports');
			$this->email->message($txt);

			if($this->email->send()){

				$txtUser .= '<table>
									<tr>						
										<th>Report Name</td>
										<th>Licence</td>
										<th>Price</td>
									</tr>';
				for($j=0;$j<count($reportname);$j++){
					$txtUser .= '<tr>			    			
					    			<td>'.$reportname[$j].'</td>
					    			<td>'.$reportType.'</td>
					    			<td>'.$price.'</td>
					    		</tr>';
			    }
		    	
		    	$txtUser .= '</table>';

				$this->email->from('query@compareinsights.com','Compare Insight');
				$this->email->to($email_address);
			    $this->email->subject('Report Purchase Confirmination');
				$this->email->message($txtUser);
				$this->email->send();				
			}

    		$this->session->set_flashdata('success','success');
    		redirect(base_url('Website'));		    	
		}
	}

	



    public function removecart($id){
   		$data['reportId'] = $this->uri->segment(3);
		$ip   = get_client_ip();
        $data['cart']   = $this->WebModal->cartCount($ip);
    	$data['cartItem']= $this->WebModal->getCartItems($ip);
    	//print_r($data);
		$del = $this->WebModal->deletecart($ip,$id);
		if($del){
			//echo 'true';
			redirect(base_url()."website/cartItems1");
		}
	}

	public function updateCartPrice(){
		$price = $this->input->post('price');
		$type  = $this->input->post('type');
		$id    = $this->input->post('id');
		$updateCart = $this->WebModal->updateCartPrice($price,$type,$id);
		echo $updateCart;
	}


}


