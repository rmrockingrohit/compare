<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Category extends CI_Controller {  

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 public function __construct(){
		parent::__construct();		
		$this->load->helper(array('url','form'));	
		$this->load->helper('html');	
        // load form_validation library
        $this->load->library('form_validation');
    }
    
   /* public function basic()
    {
        // basic required field
        $this->form_validation->set_rules('title', 'Title', 'required');
         
        if ($this->form_validation->run() == FALSE)
        {
       	$this->load->model('categorymodel');
		$this->load->view('admin/header');
		$this->load->view('admin/add_category');
		$this->load->view('admin/footer');
        }
        else
        {
            // load success template...
           	$this->load->model('categorymodel');
		$this->load->view('admin/header');
		$this->load->view('admin/add_category');
		$this->load->view('admin/footer');
        }
    }*/
	public function index()
	{
	    
          	$this->load->model('model');
		$this->load->view('admin/header');
		$this->load->view('admin/add_category');
		$this->load->view('admin/footer');
        
	}
	
	
	public function add(){
		
		$this->load->view('admin/header');
		$this->load->view('admin/add_category');
		$this->load->view('admin/footer');
		}
	public function insertcategory(){
	    $this->load->model('categorymodel');
	     $this->form_validation->set_rules('title', 'Title', 'required|is_unique[skills.title]');
	       if ($this->form_validation->run() !== FALSE)
        {
            	$title = $_REQUEST["title"];
		$short_description = $_REQUEST["short_description"];
			
		$this->categorymodel->insertcategory($title,$short_description);
		
	/*	$insertcat = $this->categorymodel->insertcategory($title,$short_description);*/
        }
       	
		else
        {
            $this->load->model('categorymodel');
            
		$this->session->set_flashdata("error","category exist ! Please try again later");
        }

		redirect(base_url()."index.php/admin/category/managecategory");
		
	}
		
		public function managecategory(){
			$this->load->model("categorymodel");
			$res = $this->categorymodel->getcategorys();
			$data = array();
			$data ["skill"] = $res ;
			
			$this->load->view('admin/header');
			$this->load->view('admin/manage_category',$data);
			$this->load->view('admin/footer');
			
		}

		public function edit($id){
			$this->load->model("categorymodel");
			$res = $this->categorymodel->getcategorybyid($id);
			$data ["skill"] = $res ;
			$this->load->view('admin/header');
			$this->load->view('admin/edit_category',$data);
			$this->load->view('admin/footer');
			}
			
		public function update(){
			
			$this->load->model('categorymodel');
			$id = $_REQUEST["id"];
		$title = $_REQUEST["title"];
		$short_description = $_REQUEST["short_description"];
		$skill_per = $_REQUEST["skill_per"];
		
		
		$this->categorymodel->updatecategory($id,$title,$short_description,$skill_per);
		
		redirect(base_url()."index.php/admin/category/managecategory");
			}
	 public function delete($id){
		 		$this->load->model("categorymodel");
			 $this->categorymodel->deletecategory($id);
			 redirect(base_url()."index.php/admin/category/managecategory");
		 }
		 
}
