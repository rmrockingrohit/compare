<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Report extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	  public function __construct() 
    {
        parent::__construct();
     
        // load form and url helpers
        $this->load->helper(array('form', 'url'));
         $this->load->library('session'); 
         $this->load->library('email'); 
        // load form_validation library
        $this->load->library('form_validation');   	
		$this->load->helper('html');
		$this->load->model('reportmodel');	
	}  
	
	public function index()
	{
		$this->load->model('reportmodel');
		$this->load->model('skillmodel');
		$result = $this->reportmodel->getreport();
		$data ["report"] =$result;

		$this->load->view('admin/header');
		$this->load->view('admin/manage_report' , $data);
		$this->load->view('admin/footer');
	}
	
	public function update()
	{
	    $id = $this->uri->segment(4);
		$this->load->model('reportmodel');
		$this->load->model('skillmodel');
		
		$res = $this->reportmodel->getreportByid($id);
		$data["report"] = $res;
		$res1 = $this->skillmodel->getskills();
		$data["category"] = $res1;

		$this->load->view('admin/header');
		$this->load->view('admin/edit_report' , $data);
		$this->load->view('admin/footer');
	}

	public function correction()
	{
	    $id = $this->uri->segment(4);
		$this->load->model('reportmodel');
		$this->load->model('skillmodel');
		
		$res = $this->reportmodel->getreportByid($id);
		$data["report"] = $res;
		$res1 = $this->skillmodel->getskills();
		$data["category"] = $res1;
		$this->load->view('admin/header');
		$this->load->view('admin/correction_report' , $data);
		$this->load->view('admin/footer');
	}

	public function correctionreport(){
		$this->load->model('reportmodel');
		$this->load->model('skillmodel');
		$id = $_REQUEST['id'];
		$id = $_REQUEST['correction_update'];
		$status = "Unapproved";
		$this->reportmodel->correction_report($id,$correction,$status);
		redirect(base_url()."index.php/admin/report");
	}
	

    public function updatecorrectionreport(){
		$this->load->model('reportmodel');
		$this->load->model('skillmodel');
		$id = $_POST['id'];
		$status = "Unapproved";
		$report_corr = $_REQUEST['report_corr'];
		$this->reportmodel->correction_report($id,$status,$report_corr);
		$getAuthor = $this->reportmodel->getAuthorOfReportUpdate($id);
		 $this->data['data'] = '<h2>Hi !</h2>
            			 <p>Report Not Apporved By Site Administrator.</p>
		                 <p>Your Report Has <b> Not been Apporved </b> Please Correct Your Report With Suggested Field. <strong>'.$report_corr.'</strong></p>';
		
		$msg =  $this->load->view('admin/emailTemp',$this->data,true);
			
		// Send Email to administrator For Alert Of New Report Submittion
		$this->load->library('email');
        $this->email->from('noreply@compareinsight.com',"noreply@compareinsight.com");
        $this->email->to($getAuthor[0]->username);
        
        $this->email->set_header('MIME-Version', '1.0; charset=utf-8');
        $this->email->set_header('Content-type', 'text/html');

        $this->email->subject('Report Not Apporved By Site Administrator.');
        $this->email->message($msg);
        
        if($this->email->send()){
            echo "mail Sent";
        }
        
		redirect(base_url()."index.php/admin/report");
	}


	public function updatereport(){
		$this->load->model('reportmodel');
		$this->load->model('skillmodel');
		$id              = $_REQUEST['id'];
		$title           = $_REQUEST['report_name'];
		$project_link    = $_REQUEST['report_desc'];
		$report_price    = $_REQUEST['report_price'];
		$status          = "Inprogress";
		$category        = $_REQUEST['category'];
		$Publisher_date  = $this->input->post('Publisher_date');
	
		$image = FALSE;
		if(isset($_FILES["image"]["name"]) && ($_FILES["image"]["name"])){
			$physicalpath =  $_SERVER['DOCUMENT_ROOT']."/".basename(base_url())."/report_uploads/";
			$image = date("dmYGis").$_FILES["image"]["name"];
			move_uploaded_file($_FILES["image"]["tmp_name"],$physicalpath.$image);
		}
		 $this->reportmodel->updatereport($id,$title,$project_link,$category,$image,$report_price,$status,$Publisher_date);
		
		// Email Notification 
		$this->session->set_flashdata("success","Update Successfully");
			
    		// In cse of not admin
            $userMail           = $this->session->userdata('adminEmail');
            if($userMail != 'admin@admin.com'){
			    $getUserIfo   = $this->reportmodel->getUserInfoByUsername($id);
			    $this->data['data'] = '<h2>Hi Admin!,</h2>
            			 <p>You have A New Message From <strong>'.$this->session->userdata('adminName').'</strong>.</p>
            			 <p style="margin-top:30px;"><b>'.$this->session->userdata('adminName').'</b> Updated a report Named <b>'.$title.'</b> Today at '.date("H:i:s").'</p>';
            			 $to = 'vasuraghav01111@gmail.com';
            			 $from = $userMail;
            			 $frmTitle = 'noreply@coscode.com';
            }else{
                $getAuthor = $this->reportmodel->getAuthorOfReportUpdate($id);
                $this->data['data'] = '<h2>Hi '.$getAuthor[0]->username.'!,</h2>
            			 <p>Your Report  <strong>'.ucwords($getAuthor[0]->reportname).'</strong> has been Edited By Site Administrator. Check Your Posted Report Data if you need anything change contact to site administrator at vasuraghav01111@gmail.com. </p>';
            			 $from = 'noreply@compareinsight.com';//'vasuraghav01111@gmail.com';
            			 $to = $getAuthor[0]->username;
            			 $frmTitle = 'noreply@compareinsight.com';
            }
            			 
			$msg =  $this->load->view('admin/emailTemp',$this->data,true);
			
			// Send Email to administrator For Alert Of New Report Submittion
    			$this->load->library('email');
                $this->email->from($from,$fromTitle);
                $this->email->to($to);
                
                $this->email->set_header('MIME-Version', '1.0; charset=utf-8');
                $this->email->set_header('Content-type', 'text/html');

                $this->email->subject('New Report Submitted By '.$this->session->userdata("adminName"));
                $this->email->message($msg);
                
                $this->email->send();
		
		
		redirect(base_url()."index.php/admin/report");
	}
	
	public function addreport(){
		
		$this->load->view('admin/header');
		$this->load->model('skillmodel');
		$res = $this->skillmodel->getskills();
		$data = array();
		$data ["category"] = $res;
		$this->load->view('admin/add_report', $data );
		$this->load->view('admin/footer');
	}

public function insertreport()
	{
		$this->load->model('reportmodel');
		$this->load->model('skillmodel');
		
		
		$title              = $_REQUEST['report_name'];
		$project_link       = $_REQUEST['report_desc'];
		$project_price      = $_REQUEST['report_price'];
		$status             = "Inprogress";
		$category           = $_REQUEST['category'];
		$Publisher_date     = $_REQUEST['Publisher_date'];
		$Publisher_name     = $_REQUEST['Publisher_name'];
		$report_subcategory = $_REQUEST['report_subcategory'];
		$report_id          = $_REQUEST['report_id'];
		$report_cagr        = $_REQUEST['report_cagr'];
		$report_toc         = $_REQUEST['report_toc'];
		$reportforcastup    = $_REQUEST['reportforcastup'];
		$reportforcastto    = $_REQUEST['reportforcastto'];
		
		// In cse of not admin
        $userMail           = $this->session->userdata('adminEmail');
		

		$physicalpath  =  $_SERVER['DOCUMENT_ROOT']."/".basename(base_url())."/vender/uploads/'";

		$image = date("dmYGis").$_FILES["image"]["name"];
		if(move_uploaded_file($_FILES["image"]["tmp_name"],$physicalpath.$image)){
			$insertrid = $this->reportmodel->insreport($title,$project_link,$category,$image,$project_price,$status,$Publisher_date,$Publisher_name,$report_subcategory,$report_id,$report_cagr,$report_toc,$reportforcastup,$reportforcastto);
			 if($insertrid){
    			$this->session->set_flashdata("success","Inserted Successfully");
    			$getUserIfo   = $this->reportmodel->getUserInfoByUsername($insertrid);
			
			    $this->data['data'] = '<h2>Hi Admin!,</h2>
            			 <p>You have A New Message From <strong>'.$this->session->userdata('adminName').'</strong>.</p>
            			 <p style="margin-top:30px;"><b>'.$this->session->userdata('adminName').'</b> Posted a new report Named <b>'.$title.'</b> Today at '.date("H:i:s").'</p>';
            			 
            			 
			$msg =  $this->load->view('admin/emailTemp',$this->data,true);
			
			// Send Email to administrator For Alert Of New Report Submittion
    			$this->load->library('email');
                $this->email->from($userMail, 'noreply@compareinsight.com');
                $this->email->to('vasuraghav01111@gmail.com');
                
                $this->email->set_header('MIME-Version', '1.0; charset=utf-8');
                $this->email->set_header('Content-type', 'text/html');

                $this->email->subject('New Report Submitted By '.$this->session->userdata("adminName"));
                $this->email->message($msg);
                
                $this->email->send();
		}
		else
		{
			$this->session->set_flashdata("error","Server issue ! Please try again later");
		}
			redirect(base_url()."index.php/admin/report");
		}
	}

	public function delete()
	{
	    $id = $this->uri->segment(4);
		$this->load->model('reportmodel');
		$this->reportmodel->deletepro($id);
		redirect(base_url()."index.php/admin/report");	
	}
	
	public function approve()
	{
	    $id = $this->uri->segment(4);
		$this->load->model('reportmodel');
		$upd = $this->reportmodel->approve($id);
		if($upd){
		    $this->session->set_flashdata('success','Report Approved Successfuly');
		    $getAuthor = $this->reportmodel->getAuthorOfReportUpdate($id);
            $this->data['data'] = '<h2>Hi '.$getAuthor[0]->username.'!,</h2>
            			               <p>Your Report  <strong>'.ucwords($getAuthor[0]->reportname).'</strong> has been Approved By Site Administrator  Today at '.date("H:i:s").'. if you need anything change contact to site administrator at insight@coscode.com. </p>';
            			 
            			 
			$msg =  $this->load->view('admin/emailTemp',$this->data,true);
			
			// Send Email to administrator For Alert Of New Report Submittion
    			$this->load->library('email');
                $this->email->from('noreply@compareinsight.com', 'noreply@compareinsight.com');
                $this->email->to($getAuthor[0]->username);
                
                $this->email->set_header('MIME-Version', '1.0; charset=utf-8');
                $this->email->set_header('Content-type', 'text/html');

                $this->email->subject('Report Approved by insight@coscode.com');
                $this->email->message($msg);
                
                $this->email->send();
		}else{
		    $this->session->set_flashdata('error','Server Busy Try Later.');
		}
		redirect(base_url()."index.php/admin/report");	
	}
	
	
	 // Send Gmail to another user
    public function Send_Mail() {
        
        // Check for validation
            
            // Configure email library
            $config['protocol'] = 'smtp';
            $config['smtp_host'] = 'smtp.seisotech.org';
            $config['smtp_port'] = 80;
            $config['smtp_user'] = 'seisotec_wp851';
            $config['smtp_pass'] = 'market';

            // Load email library and passing configured values to email library 
            $this->load->library('email', $config);
            $this->email->set_newline("\r\n");
            
            // Sender email address
            $this->email->from('akshaym8677@gmail.com');
            // Receiver email address
            $this->email->to('akshaym8677@gmail.com');
            // Subject of email
            $this->email->subject('approval');
            // Message in email
            $this->email->message('this report is approved');

            if ($this->email->send()) {
                $data['message_display'] = 'Email Successfully Send !';
            } else {
                $data['message_display'] = '<p class="error_msg">Invalid Gmail Account or Password !</p>';
            }
           // $this->load->view('admin/manage_report', $data);
        }


        public function addBulk(){
        	$this->load->view('admin/header');
			$this->load->model('skillmodel');
			$res = $this->skillmodel->getskills();
			$data = array();
			$data ["category"] = $res;
			$data['page'] = 'bulk';
			$this->load->view('admin/add_report_bulk', $data );
			$this->load->view('admin/footer');
        }

        public function getExcelSheetForCategoryList(){
        	$this->load->library('excel');
        	$this->load->model('Categorymodel');
        	$getCategory = $this->Categorymodel->downloadCategory();

        	//var_dump($getCategory);

        
			    $filename = "Category_list.xls";
			    header("Content-Type: application/vnd.ms-excel");
			    header("Content-Disposition: attachment; filename=\"$filename\"");

				$isPrintHeader = false;
			    if (! empty($getCategory)) {
			        foreach ($getCategory as $row) {
			            if (! $isPrintHeader) {
			                echo implode("\t", array_keys($row)) . "\n";
			                $isPrintHeader = true;
			            }
			            echo implode("\t", array_values($row)) . "\n";
			        }
			    }
			    exit();
      
				
        }

        public function uploadBulkData(){
        	$files = $this->input->post('bulk');
        	$msg = '';
        	$saveId = array();
        	$uploadfile = base_url().'report_uploads/';

        	if($_FILES['bulk']['type'] == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'){
        		$this->load->library('excel');
				$file = $_FILES['bulk']['tmp_name'];

				 //read file from path
					$objPHPExcel = PHPExcel_IOFactory::load($file);
				//get only the Cell Collection
					$cell_collection = $objPHPExcel->getActiveSheet()->getCellCollection();
				//extract to a PHP readable array format
					$publisher_name = $objPHPExcel->getActiveSheet()->getCell("A1")->getValue();
					$report_title   = $objPHPExcel->getActiveSheet()->getCell("B1")->getValue();
					$report_desc    = $objPHPExcel->getActiveSheet()->getCell("C1")->getValue();
					$report_price   = $objPHPExcel->getActiveSheet()->getCell("D1")->getValue();
					$multi_prise    = $objPHPExcel->getActiveSheet()->getCell("E1")->getValue();
					$five_prise     = $objPHPExcel->getActiveSheet()->getCell("F1")->getValue();
					$enter_prise    = $objPHPExcel->getActiveSheet()->getCell("G1")->getValue();
					$published_on   = $objPHPExcel->getActiveSheet()->getCell("H1")->getValue();
					$category_id    = $objPHPExcel->getActiveSheet()->getCell("I1")->getValue();
					$report_id      = $objPHPExcel->getActiveSheet()->getCell("J1")->getValue();
					$cagr           = $objPHPExcel->getActiveSheet()->getCell("K1")->getValue();
					$toc            = $objPHPExcel->getActiveSheet()->getCell("L1")->getValue();
					$upload_path    = $objPHPExcel->getActiveSheet()->getCell("M1")->getValue();

				if(strtolower($publisher_name) != 'publisher name'){
					$msg .= '<p>Please Replace Your Excel Sheet Strings "<b>'.$publisher_name.'</b>" To - "<b>Publisher Name
</b>" .</P>';
				}
				if(strtolower($report_title) != 'report title'){
					$msg .= '<p>Please Replace Your Excel Sheet Strings "<b>'.$report_title.'</b>" To - "<b>Report Title
</b>" .</P>';
				}
				if(strtolower($report_desc) != 'report discription'){
					$msg .= '<p>Please Replace Your Excel Sheet Strings "<b>'.$report_desc.'</b>" To - "<b>Report Discription
</b>" .</P>';
				}
				if(strtolower($report_price) != 'report price'){
					$msg .= '<p>Please Replace Your Excel Sheet Strings "<b>'.$report_price.'</b>" To - "<b>Report Price
</b>" .</P>';
				}
				if(strtolower($published_on) != 'published date'){
					$msg .= '<p>Please Replace Your Excel Sheet Strings "<b>'.$published_on.'</b>" To - "<b>Published Date
</b>" .</P>';
				}

				if(strtolower($category_id) != 'report category'){
					$msg .= '<p>Please Replace Your Excel Sheet Strings "<b>'.$category_id.'</b>" To - "<b>Report Category
</b>" .</P>';
				}
				if(strtolower($report_id) != 'report id'){
					$msg .= '<p>Please Replace Your Excel Sheet Strings "<b>'.$report_id.'</b>" To - "<b>Report ID
</b>" .</P>';
				}
				if(strtolower($cagr) != 'cagr'){
					$msg .= '<p>Please Replace Your Excel Sheet Strings "<b>'.$cagr.'</b>" To - "<b>CAGR
</b>" .</P>';
				}
				if(strtolower($toc) != 'toc report'){
					$msg .= '<p>Please Replace Your Excel Sheet Strings "<b>'.$toc.'</b>" To - "<b>TOC Report
</b>" .</P>';
				}
				

    			if(!empty($msg)){
    				echo $msg;
    				exit;
    			}else{				
    			    $path = $file;
    			    $object = PHPExcel_IOFactory::load($path);
    			   	foreach($object->getWorksheetIterator() as $worksheet)
    			   	{
    				    $highestRow = $worksheet->getHighestRow();
    				    $highestColumn = $worksheet->getHighestColumn();
    				    for($row=2; $row<=$highestRow; $row++){
    				    	$publisher_namePHP = $worksheet->getCellByColumnAndRow(0, $row)->getValue();
    						$report_titlePHP   = $worksheet->getCellByColumnAndRow(1, $row)->getValue();
    						$report_descPHP    = $worksheet->getCellByColumnAndRow(2, $row)->getValue();
    						
    						$report_pricePHP   = $worksheet->getCellByColumnAndRow(3, $row)->getValue();
    						$multi_prisePHP    = $worksheet->getCellByColumnAndRow(4, $row)->getValue();
        					$five_prisePHP     = $worksheet->getCellByColumnAndRow(5, $row)->getValue();
        					$enter_prisePHP    = $worksheet->getCellByColumnAndRow(6, $row)->getValue();
        					
    						$published_onPHP   = $worksheet->getCellByColumnAndRow(7, $row)->getValue();
    						$category_idPHP    = $worksheet->getCellByColumnAndRow(8, $row)->getValue();
    						
    						$report_idPHP      = $worksheet->getCellByColumnAndRow(9, $row)->getValue();
    						$cagrPHP           = $worksheet->getCellByColumnAndRow(10, $row)->getValue();
    						$tocPHP            = $worksheet->getCellByColumnAndRow(11, $row)->getValue();
    						
    						if($publisher_namePHP == ''){
    						    	$msg .= '<p>PLEASE ENTER PUBLISHER NAME IN "<b> LINE NUMBER '.$row.'</b></P>';
    						}
    						
    						if($report_titlePHP == ''){
    						    $msg .= '<p>PLEASE ENTER REPORT TITLE IN "<b> LINE NUMBER '.$row.'</b></P>';
    						}
    						
    						if($report_descPHP == ''){
    						    	$msg .= '<p>PLEASE ENTER REPORT DESCRIPTION IN "<b> LINE NUMBER '.$row.'</b></P>';
    						}
    						
    						if($report_pricePHP == ''){
    						    $msg .= '<p>PLEASE ENTER REPORT SINGLE USER PRICE IN "<b> LINE NUMBER '.$row.'</b></P>';
    						}
    						
    						if($multi_prisePHP == ''){
    						    $msg .= '<p>PLEASE ENTER REPORT MULTI USER PRICE IN "<b> LINE NUMBER '.$row.'</b></P>';
    						}
    						
    						if($five_prisePHP == ''){
    						    $msg .= '<p>PLEASE ENTER REPORT FIVE USER PRICE IN "<b> LINE NUMBER '.$row.'</b></P>';
    						}
    						
    						if($enter_prisePHP == ''){
    						    $msg .= '<p>PLEASE ENTER REPORT ENTERPRISE USER PRICE IN "<b> LINE NUMBER '.$row.'</b></P>';
    						}
    						
    						if($published_onPHP == ''){
    						    $msg .= '<p>PLEASE ENTER REPORT PUBLISHED DATE IN "<b> LINE NUMBER '.$row.'</b></P>';
    						}
    						
    						if($category_idPHP == ''){
    						    $msg .= '<p>PLEASE ENTER REPORT CATEGORY IN "<b> LINE NUMBER '.$row.'</b></P>';
    						}
    				    }
    				    
    				    if(!empty($msg)){
    				        echo $msg;
    				        exit;
    				    }else{
    				    
        				    for($row=2; $row<=$highestRow; $row++){
        				    
        					
        						$timeSTMP =  ($published_onPHP - 25569) * 86400;
        						$published_onPHP = date('Y-m-d',$timeSTMP);
    					       
    					        
        						// Creating Data Variables
        						   $data = array(
        						   					  'publisher_name'  => $publisher_namePHP,
        										      'reportname'      => $report_titlePHP,
        										      'reportdesc'   	=> $report_descPHP,
        										      'price'      	    => $report_pricePHP,
        										      'project_pricemulti'=>$multi_prisePHP,
        										      'project_pricefive' => $five_prisePHP,
        										      'project_priceenterp' => $enter_prisePHP,
        										      'publisher_date'  => $published_onPHP,
        										      'category'        => $category_idPHP,
        										      'report_id'       => $report_idPHP,
        										      'report_cagr'     => $cagrPHP,
        										      'report_toc'      => $tocPHP,
        										      'reportdoc'       => '',
        										      'status'          => 'Unapproved', 
        										      'reportcol'       =>'',
        										      'is_deleted'      => '',										      
        										      'reportcol'       => '',
        										      'report_corr'     => '',
        										      'username'		=> $this->session->userdata('adminEmail'),
        										      'report_subcategory'=>''
        										   );
        						$save = $this->reportmodel->insertBulk($data);	
        						array_push($saveId,$save);		
        				    }
        				    
    				    }
    				}	
    				$arrayData = array();
    				foreach($saveId as $li){
    					$get = $this->reportmodel->getreportByid($li);
    					array_push($arrayData, $get[0]);
    				}
    				$data['uploadID'] = $arrayData;
    				$this->load->view('admin/header');
    				$this->load->view('admin/bulk_upload', $data);
    				$this->load->view('admin/footer');
    			}
        	}else{
        		redirect(base_url()."index.php/admin/report/addBulk");
        	}
        }

        public function uploadFileBulk(){
        	$reportID = $this->input->post('reportID');
        	for($i =0; $i<count($reportID);$i++){        		
        			$config['upload_path']          = './report_uploads/';
	                $config['allowed_types']        = '*';
	                $config['max_size']             = 102400;
	                $config['max_width']            = 102400;
	                $config['max_height']           = 76800;

	                $this->load->library('upload', $config);
	                if ( ! $this->upload->do_upload('report_file'.$reportID[$i])){
                        $error = array('error' => $this->upload->display_errors());                
                       
                	}else{
                        $success = array('upload_data' => $this->upload->data());
               		}

               		// Update Sql File To upload name
               			$img_file = $success['upload_data']['file_name'];
               			$save = $this->reportmodel->updateReportFile($img_file,$reportID[$i]);
        	}

        	redirect(base_url()."index.php/admin/report/saveUpload");

        	
        }

        public function saveUpload(){
        	$this->load->view('admin/header');
			$this->load->view('admin/save_upload');
			$this->load->view('admin/footer');
        }
	
}
