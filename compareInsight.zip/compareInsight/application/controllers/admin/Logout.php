<?php if(!defined('BASEPATH')) exit('no direct access script allowed');

class Logout extends CI_Controller {

	public function __construct() {
		
		parent::__construct(); 
		$this->load->helper('url');
		$this->load->library('session');		
		$this->load->helper('html');	
	}  
		
	public function index() {
		
		$this->session->unset_userdata('adminType');
		
		$this->session->unset_userdata('adminID');
		$this->session->unset_userdata('adminName');
		$this->session->unset_userdata('adminType');
		$this->session->unset_userdata('adminEmail');
		redirect(base_url().'admin/Login');
	}

}