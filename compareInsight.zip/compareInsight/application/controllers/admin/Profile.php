<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 public function __construct(){
		parent::__construct();		
		$this->load->helper(array('url','form'));	
		$this->load->helper('html');	
	}  
	
	public function index()
	
	{
		$this->load->model('approvedmodel');
		$email = $this->session->userdata('adminEmail');
		$data['userInfo'] = $this->approvedmodel->getUSerInfoByEmail($email);
		$this->load->view('admin/header',$data);
		$this->load->view('admin/manage_profile');
		$this->load->view('admin/footer');
	}
	
	public function updateUser(){
	    $name = $this->input->post('name');
	    $pass = $this->input->post('password');
	    $id   = $this->input->post('userId');
	    $this->load->model('approvedmodel');
	    $save = $this->approvedmodel->updateUserProfileById($name,$pass,$id);
	    if($save>0){
	        $this->session->set_flashdata('success',$name.' Updated Successfuly.');
	        $email = $this->session->userdata('adminEmail');
    		$data['userInfo'] = $this->approvedmodel->getUSerInfoByEmail($email);
    		$this->load->view('admin/header',$data);
    		$this->load->view('admin/manage_profile');
    		$this->load->view('admin/footer');
	    }else{
	        $this->session->set_flashdata('error','Server Busy .');
	        $email = $this->session->userdata('adminEmail');
    		$data['userInfo'] = $this->approvedmodel->getUSerInfoByEmail($email);
    		$this->load->view('admin/header',$data);
    		$this->load->view('admin/manage_profile');
    		$this->load->view('admin/footer');
	    }
	}

}