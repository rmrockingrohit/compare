<?php 
class WebModal extends CI_Model{

	
	function getNavData(){
		$get = $this->db->select('*')
						->from('skills')
						->get();
		return $get->result_array();
	}

	function getAllSliderData(){
		$get = $this->db->select('*')
						->from('report')
						->get();
		return $get->result_array();
	}

	function cartCount($ip){
		$get = $this->db->select('*')
						->from('cartitem')
						->where('systemIP',$ip)
						->get();
		return $get->result_array();
	}

	function GetAllIdRelatedSkillData($id){
		$get = $this->db->select('*')
						->from('skills')
						->where('id',$id)
						->get();
		return $get->result_array();
	}

	function getIdRelatedReportData($id){
		$get = $this->db->select('*')
						->from('report')
						//->where('id',$id)
						->where('category',$id)
						->where('status','Approve')
						->get();
		return $get->result_array();
	}
	function getIdRelatedReportDataForReport($id){
		$get = $this->db->select('*')
						->from('report')
						->where('id',$id)
						->where('status','Approve')
						->get();
		return $get->result_array();
	}

	

	function getNavDataByTXT($txt){
		$get = $this->db->select('*')
						->from('report')
						->like('reportname',$txt)
						->where('status','Approve')
						->get();
		return $get->result_array();
	}

	function getSearchReletedDataByIdOrTXT($id,$txt){
		$get = $this->db->select('*')
						->from('report')
						->where('id',$id)
						->or_where('reportdesc',$txt)
						->where('status','Approve')
						->get();
		return $get->result_array();
	}

	function get_reportDetail_byID($r_id){
		$get = $this->db->select('*')
						->from('report')
						->where('id',$r_id)						
						->get();
		return $get->result_array();
	}

	function getCartItems($ip){
		$get = $this->db->select('*')
						->from('report')
						->where('cartitem.systemIP',$ip)
						->join('cartitem','cartitem.reportId = report.id','left')						
						->get();
		return $get->result_array();
	}

	function getBuyItemData($id){
		$get = $this->db->select('*')
						->from('report')
						->where('id',$id)
						//->join('cartitem','cartitem.reportId = report.id','left')						
						->get();
		return $get->result_array();
	}

	function getAllPublisherName(){
		
        $query = $this->db->select("*")
        				  ->from('report')
        				  ->order_by('publisher_name','ASC')
        				  ->get();
 
        return $query->result_array();
	}

	function getAllPublisherReportsBYBuplisherName($name){
		$query = $this->db->select("*")
        				  ->from('report')
        				  ->where('publisher_name',$name)
        				  ->get();
 
        return $query->result_array();
	}

	function addCartByIp($id,$ip){
		$arr  = array(
						'reportId'   =>  $id,
						'systemIP'   => $ip
					 ) ;
		$save = $this->db->insert('cartitem',$arr);
	    return $this->db->insert_id();
	}

	function getCartItemCount($ip){
		$get = $this->db->select('*')
						->from('cartitem')
						->where('systemIP',$ip)
						->get();
		return $get->result_array();
	}

	function deleteCart($ip,$id){


		$del = $this->db->query("delete from cartitem where reportId=".$id);
		return $this->db->affected_rows();
	}
    

/*public function deletepro($id){	
		$this->db->query("delete from report where id=".$id);
		return true;
	}
	*/












    function getReportById($id){
        $get = $this->db->select('report.*,skills.title')
						->from('report')
						->where('report.id',$id)
						->join('skills','skills.id = report.category','left')
						->get();
		return $get->result_array();
    }
    function allReports(){
    	if( $this->session->userdata('adminType') != 'admin' ) {
	        $username = $this->session->userdata('adminEmail');
	        $get = $this->db->select('*')
	                        ->from('report')
	                        ->where('username',$username)
	                        ->get();
	        return $get->result_array();
	    }else{
	    	$get = $this->db->select('*')
	                        ->from('report')
	                        ->get();
	        return $get->result_array();
	    }
    }
    
    function successReports(){
    	if( $this->session->userdata('adminType') != 'admin' ) {
	        $username = $this->session->userdata('adminEmail');
	        $get = $this->db->select('*')
	                        ->from('report')
	                        ->where('username',$username)
	                        ->where('status','Approve')
	                        ->get();
	        return $get->result_array();
	    }else{
	    	$get = $this->db->select('*')
	                        ->from('report')
	                        ->where('status','Approve')
	                        ->get();
	        return $get->result_array();
	    }
        
    }
    
    function warningReports(){
    	if( $this->session->userdata('adminType') != 'admin' ) {
	        $username = $this->session->userdata('adminEmail');
	        $get = $this->db->select('*')
	                        ->from('report')
	                        ->where('username',$username)
	                        ->where('status','Inprogress')
	                        ->get();
	        return $get->result_array();
	    }else{
	    	$get = $this->db->select('*')
	                        ->from('report')
	                        ->where('status','Inprogress')
	                        ->get();
	        return $get->result_array();
	    }
        
    }
    
    function dangerReports(){
    	if( $this->session->userdata('adminType') != 'admin' ) {
	        $username = $this->session->userdata('adminEmail');
	        $get = $this->db->select('*')
	                        ->from('report')
	                        ->where('username',$username)
	                        ->where('status','Unapproved')
	                        ->get();
	        return $get->result_array();
	    }else{
	    	$get = $this->db->select('*')
	                        ->from('report')
	                        ->where('status','Unapproved')
	                        ->get();
	        return $get->result_array();
	    }
    }

    
    function getCompareReportByID($id){
    	 $get = $this->db->select('report.*,skills.title')
						->from('report')
						->where('report.id',$id)
						->join('skills','skills.id = report.category','left')
						->get();
		return $get->result_array();
    }

    function resetCartItems($ip){
    	$reset = $this->db->where('systemIP',$ip)
    					  ->delete('cartitem');
    	return $this->db->affected_rows();
    }

    function updateCartPrice($price,$type,$id){
    	$item = array(
    					'reportType'  => $type,
    					'reportPrice' =>$price
    				 );
    	$upd = $this->db->where('cartId',$id)
    					->update('cartitem',$item);
    	return $this->db->affected_rows();
    }

    function saveTransactionData($country,$first_name,$last_name,$address,$city,$state,$zip_code,$email_address,$phone_number){
    	$item = array(
    					'country'=>$country,
    					'first_name'=>$first_name,
    					'last_name'=>$last_name,
    					'address'=>$address,
    					'city'=>$city,
    					'state'=>$state,
    					'zip_code'=>$zip_code,
    					'email_address'=>$email_address,
    					'phone_number'=>$phone_number
    				);
    	$set = $this->db->insert('transaction',$item);
    	return $this->db->insert_id();
    }

    function setSaleCart($cartArray,$tr_id){
    	//
    	foreach($cartArray as $row){
    		$arr = array(
    						'report_ID'     => $row['id'],
    						'report_price'  => $row['reportPrice'],
    						'tr_ID'         => $tr_id
    					);
    		$set = $this->db->insert('buydata',$arr);
    	}
    	 return $this->db->affected_rows();
    }

    function setSaleCartBuy($cartArray){
    	$set = $this->db->insert('buydata',$cartArray);    	
    	 return $this->db->insert_id();
    }

    function deleteTempCartDataBYIP($ip){
    	$delete = $this->db->where('systemIP',$ip)
    					   ->delete('cartitem');
    	return $this->db->affected_rows();
    }


    function getNewbyer(){
    	$get = $this->db->select('*')
    					->from('buydata')
    					->join('transaction','transaction.id = buydata.tr_ID')
    					->join('report','report.id = buydata.report_ID')
    					->group_by('transaction.id')
    					->get();

    	return $get->result();
    }










}