<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reportmodel extends CI_Model {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
    
    public function getUserInfoByUsername($username){
        $get = $this->db->select('*')
                        ->from('user')
                        ->where('email',$username)
                        ->get();
        return $get->result();
    }
    
	public function getreport(){
	    $where = '';
	    
	    if( $this->session->userdata('adminType') != 'admin' ) {
	        $username = $this->session->userdata('adminEmail');
	        $where = "where username = '". $username ."'";
	        $query = $this->db->select('report.*,skills.title')
						  ->from('report')						 
						  ->join('skills','skills.id = report.category','left')					
						  ->where('username',$username)					
						  ->get();	
	    }else{
		//$query = $this->db->query( "select * from report ".$where );
		$query = $this->db->select('report.*,skills.title')
						  ->from('report')						 
						  ->join('skills','skills.id = report.category','left')					
						  ->get();
		}	
		$result = $query->result_array();
		return $result ;
	}
	
	public function getreportdesc(){
	    $where = '';
	    
	    if( $this->session->userdata('adminType') != 'admin' ) {
	        $username = $this->session->userdata('adminEmail');
	        $where = "where username = '". $username ."'";
	        $query = $this->db->select('*')
						  ->from('report')						 
						  ->join('skills','skills.id = report.category','left')					
						  ->where($where)
						  ->order_by('report.id','DESC')					
						  ->get();	
	    }else{
		//$query = $this->db->query( "select * from report ".$where );
		$query = $this->db->select('*')
						  ->from('report')						 
						  ->join('skills','skills.id = report.category','left')					
						  ->order_by('report.id','desc')					
						  ->get();
		}	
		$result = $query->result_array();
		return $result ;
	}
	
	
	public function getreportByusername($username){
		$query = $this->db->query( "select * from report where username=".$email );
		$result = $query->row_array();
		return $result ;
	}
	
	
	
	public function getreportByid($id){
		$query = $this->db->select('*')
		                   ->from('report')
		                   ->where('id',$id)
		                   ->get();
		$result = $query->result_array();
		return $result ;
	}
	
	public function approve($id){
		//$this->db->query("UPDATE report SET status='Approve' WHERE id=".$id);
		$set = array('status'=> 'Approve');
		$upd = $this->db->set($set)
		                ->where('id',$id)
		                ->update('report');
		return $this->db->affected_rows();
	}
	
	public function updatereport($id,$title,$reportdesc,$category,$image,$price,$status){
		$instr="";
		if($image)
			$instr = " , reportdoc = '".$image."'";
		$this->db->query("update report set reportname='".$title."',price='".$price."',status='".$status."',reportdesc='".$reportdesc."',category='".$category."' ".$instr." where id=".$id);
		return true;
	}

	public function correction_report($id,$status,$report_corr){
		$this->db->query("update report set status='".$status."',report_corr='".$report_corr."' where id=".$id);
		return true;
	}
	
	public function insreport($title,$reportdesc,$category,$image,$price,$status,$Publisher_date,$Publisher_name,$report_subcategory,$report_id,$report_cagr,$report_toc,$reportforcastup,$reportforcastto){
	    $username = $this->session->userdata('adminEmail');
		$this->db->query("insert into report set reportname='".$title."',price='".$price."',username='".$username."',status='".$status."',reportdesc='".$reportdesc."',category='".$category."',Publisher_date='".$Publisher_date."',Publisher_name='".$Publisher_name."',report_subcategory='".$report_subcategory."',report_id='".$report_id."',report_cagr='".$report_cagr."',report_toc='".$report_toc."',reportdoc='".$image."' ,reportforcastup='".$reportforcastup."',reportforcastto='".$reportforcastto."'");
		return true;
	}

	public function deletepro($id){	
		$this->db->query("delete from report where id=".$id);
		return true;
	}
	
	function getAuthorOfReportUpdate($id){
	    $get = $this->db->select('reportname,username')
	                    ->from('report')
	                    ->where('id',$id)
	                    ->get();
	   return $get->result();
	}
	
	function getReportByvenderName($vender){
	   
	   if( $this->session->userdata('adminType') == 'admin' ) {
	        $get = $this->db->select("report.*,skills.title")
            	            ->from("report")
            	            ->where('username',$vender)
            	            ->join('skills','skills.id = report.category','left')
        	                ->get();
        	   return $get->result_array();                
	    }else{
	        $get = $this->db->select("report.*,skills.title")
            	            ->from("report")
            	            ->where('username',$vender)
            	            ->where('username',$this->session->userdata('adminEmail'))
            	            ->join('skills','skills.id = report.category','left')
        	                ->get();
        	return $get->result_array();
	    }
	}
	
	function getReportBytype($type){
	    if( $this->session->userdata('adminType') == 'admin' ) {
	        $get = $this->db->select("report.*,skills.title")
            	            ->from("report")
            	            ->where('status',$type)
            	            ->join('skills','skills.id = report.category','left')
        	                ->get();
        	   return $get->result_array();                
	    }else{
	        $get = $this->db->select("report.*,skills.title")
            	            ->from("report")
            	            ->where('status',$type)
            	            ->where('username',$this->session->userdata('adminEmail'))
            	            ->join('skills','skills.id = report.category','left')
        	                ->get();
        	return $get->result_array();
	    }
	    
	}

	public function insertBulk($data){
		$set = $this->db->insert('report',$data);
		return $this->db->insert_id();
	}

	function updateReportFile($uploadFile,$id){
		$upd = $this->db->set('reportdoc',$uploadFile)
						->where('id',$id)
						->update('report');
		return $this->db->affected_rows();
	}
}
