<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Primusermodel extends CI_Model {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 

public function insertpriuser ($country,$first_name,$last_name,$address,$city,$state,$zip_code,$email_address,$phone_number)

{


	 $this->db->query("insert into transaction set country='".$country."',first_name='".$first_name."',last_name='".$last_name."

	 	',address='".$address."',city='".$city."',state='".$state."',zip_code='".$zip_code."',email_address='".$email_address."

	 	',phone_number='".$phone_number."'  ");


	 return true;


	}
	
			
}
