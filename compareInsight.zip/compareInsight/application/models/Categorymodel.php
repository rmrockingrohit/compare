<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Categorymodel extends CI_Model {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	
	
	public function getcategorys(){
		//$query = $this->db->query(" select * from product as p,category as c where(p.c_id = c.c_id)");
		$query = $this->db->query("select * from skills ");
		$result = $query->result_array();
		return $result;
	}

	public function downloadCategory(){
		//$query = $this->db->query(" select * from product as p,category as c where(p.c_id = c.c_id)");
		$query = $this->db->query("select id,title from skills ");
		$result = $query->result_array();
		return $result;
	}
		
	public function insertcategory($title,$short_description){
	 $this->db->query("insert into skills set title='".$title."',short_description='".$short_description."'");
	 return true;
	}
	
	public function getcategorybyid($id){
	$query = $this->db->query(" select * from skills where id = ".$id);
	$result = $query->row_array();
	return $result;
	
	}
	
	public function updatecategory($id,$title,$short_description){	
		$this->db->query("update skills set title='".$title."',short_description='".$short_description."' where id=".$id);
	 	return true;
	}
	
	public function deletecategory($id){
		$this->db->query("delete from  skills where id= ".$id);
	 	return true;
	}
	
}
